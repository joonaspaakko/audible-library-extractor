import './assets/background.js.Dq5WUY2d.js';
