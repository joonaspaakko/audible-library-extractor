(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.23fed4da.js")
    );
  })().catch(console.error);

})();
