(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.cc9f7b9f.js")
    );
  })().catch(console.error);

})();
