(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.4bdd3625.js")
    );
  })().catch(console.error);

})();
