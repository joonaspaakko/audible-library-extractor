(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.fb74065f.js")
    );
  })().catch(console.error);

})();
