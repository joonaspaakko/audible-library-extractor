(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.4ee2c1f7.js")
    );
  })().catch(console.error);

})();
