(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.d8a71690.js")
    );
  })().catch(console.error);

})();
