(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.3f6823d7.js")
    );
  })().catch(console.error);

})();
