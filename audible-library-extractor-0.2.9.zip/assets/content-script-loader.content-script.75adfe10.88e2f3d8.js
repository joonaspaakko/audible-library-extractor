(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.75adfe10.js")
    );
  })().catch(console.error);

})();
