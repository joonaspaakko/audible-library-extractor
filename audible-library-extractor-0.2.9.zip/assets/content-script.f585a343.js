import { $ as $$1 } from "./jquery.050764e9.js";
import { o as openBlock, c as createElementBlock, a as createBaseVNode, _ as _export_sfc, d as createVNode, g as normalizeClass, q as renderSlot, b as resolveDirective, h as withModifiers, t as toDisplayString, k as withCtx, bd as Transition, x as createTextVNode, e as createCommentVNode, w as withDirectives, i as createBlock, n as normalizeStyle, v as vShow, p as pushScopeId, f as popScopeId, F as Fragment, j as renderList, u as vModelCheckbox, s as createStaticVNode, I as h, bl as render$a, z as _$1, M as createApp } from "./lodash.1321b47a.js";
import { h as helpers, U as Url$1 } from "./content-script-helpers.e49fc91b.js";
import { e as enUS, F as FileSaver_min } from "./FileSaver.min.6c61b11e.js";
import Fuse from "./fuse.esm.0271f478.js";
import { t as timeStringToSeconds } from "./gallery-timeStringToSeconds.9aa0cb6a.js";
import { s as secondsToTimeString } from "./gallery-secondsToTimeString.0a6fc9ec.js";
import { c as createStore, m as mitt, V as VueTippy } from "./tippy.82bfa66a.js";
function bind(fn, thisArg) {
  return function wrap2() {
    return fn.apply(thisArg, arguments);
  };
}
const { toString } = Object.prototype;
const { getPrototypeOf: getPrototypeOf$1 } = Object;
const kindOf = ((cache) => (thing) => {
  const str = toString.call(thing);
  return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
})(/* @__PURE__ */ Object.create(null));
const kindOfTest = (type) => {
  type = type.toLowerCase();
  return (thing) => kindOf(thing) === type;
};
const typeOfTest = (type) => (thing) => typeof thing === type;
const { isArray } = Array;
const isUndefined = typeOfTest("undefined");
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction(val.constructor.isBuffer) && val.constructor.isBuffer(val);
}
const isArrayBuffer = kindOfTest("ArrayBuffer");
function isArrayBufferView(val) {
  let result;
  if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
    result = ArrayBuffer.isView(val);
  } else {
    result = val && val.buffer && isArrayBuffer(val.buffer);
  }
  return result;
}
const isString = typeOfTest("string");
const isFunction = typeOfTest("function");
const isNumber = typeOfTest("number");
const isObject = (thing) => thing !== null && typeof thing === "object";
const isBoolean = (thing) => thing === true || thing === false;
const isPlainObject = (val) => {
  if (kindOf(val) !== "object") {
    return false;
  }
  const prototype2 = getPrototypeOf$1(val);
  return (prototype2 === null || prototype2 === Object.prototype || Object.getPrototypeOf(prototype2) === null) && !(Symbol.toStringTag in val) && !(Symbol.iterator in val);
};
const isDate$1 = kindOfTest("Date");
const isFile = kindOfTest("File");
const isBlob = kindOfTest("Blob");
const isFileList = kindOfTest("FileList");
const isStream = (val) => isObject(val) && isFunction(val.pipe);
const isFormData = (thing) => {
  const pattern = "[object FormData]";
  return thing && (typeof FormData === "function" && thing instanceof FormData || toString.call(thing) === pattern || isFunction(thing.toString) && thing.toString() === pattern);
};
const isURLSearchParams = kindOfTest("URLSearchParams");
const trim = (str) => str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
function forEach(obj, fn, { allOwnKeys = false } = {}) {
  if (obj === null || typeof obj === "undefined") {
    return;
  }
  let i2;
  let l;
  if (typeof obj !== "object") {
    obj = [obj];
  }
  if (isArray(obj)) {
    for (i2 = 0, l = obj.length; i2 < l; i2++) {
      fn.call(null, obj[i2], i2, obj);
    }
  } else {
    const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
    const len = keys.length;
    let key;
    for (i2 = 0; i2 < len; i2++) {
      key = keys[i2];
      fn.call(null, obj[key], key, obj);
    }
  }
}
function findKey(obj, key) {
  key = key.toLowerCase();
  const keys = Object.keys(obj);
  let i2 = keys.length;
  let _key;
  while (i2-- > 0) {
    _key = keys[i2];
    if (key === _key.toLowerCase()) {
      return _key;
    }
  }
  return null;
}
const _global = typeof self === "undefined" ? typeof global === "undefined" ? globalThis : global : self;
const isContextDefined = (context) => !isUndefined(context) && context !== _global;
function merge() {
  const { caseless } = isContextDefined(this) && this || {};
  const result = {};
  const assignValue = (val, key) => {
    const targetKey = caseless && findKey(result, key) || key;
    if (isPlainObject(result[targetKey]) && isPlainObject(val)) {
      result[targetKey] = merge(result[targetKey], val);
    } else if (isPlainObject(val)) {
      result[targetKey] = merge({}, val);
    } else if (isArray(val)) {
      result[targetKey] = val.slice();
    } else {
      result[targetKey] = val;
    }
  };
  for (let i2 = 0, l = arguments.length; i2 < l; i2++) {
    arguments[i2] && forEach(arguments[i2], assignValue);
  }
  return result;
}
const extend = (a3, b2, thisArg, { allOwnKeys } = {}) => {
  forEach(b2, (val, key) => {
    if (thisArg && isFunction(val)) {
      a3[key] = bind(val, thisArg);
    } else {
      a3[key] = val;
    }
  }, { allOwnKeys });
  return a3;
};
const stripBOM = (content) => {
  if (content.charCodeAt(0) === 65279) {
    content = content.slice(1);
  }
  return content;
};
const inherits = (constructor, superConstructor, props, descriptors2) => {
  constructor.prototype = Object.create(superConstructor.prototype, descriptors2);
  constructor.prototype.constructor = constructor;
  Object.defineProperty(constructor, "super", {
    value: superConstructor.prototype
  });
  props && Object.assign(constructor.prototype, props);
};
const toFlatObject = (sourceObj, destObj, filter2, propFilter) => {
  let props;
  let i2;
  let prop;
  const merged = {};
  destObj = destObj || {};
  if (sourceObj == null)
    return destObj;
  do {
    props = Object.getOwnPropertyNames(sourceObj);
    i2 = props.length;
    while (i2-- > 0) {
      prop = props[i2];
      if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
        destObj[prop] = sourceObj[prop];
        merged[prop] = true;
      }
    }
    sourceObj = filter2 !== false && getPrototypeOf$1(sourceObj);
  } while (sourceObj && (!filter2 || filter2(sourceObj, destObj)) && sourceObj !== Object.prototype);
  return destObj;
};
const endsWith = (str, searchString, position) => {
  str = String(str);
  if (position === void 0 || position > str.length) {
    position = str.length;
  }
  position -= searchString.length;
  const lastIndex = str.indexOf(searchString, position);
  return lastIndex !== -1 && lastIndex === position;
};
const toArray = (thing) => {
  if (!thing)
    return null;
  if (isArray(thing))
    return thing;
  let i2 = thing.length;
  if (!isNumber(i2))
    return null;
  const arr = new Array(i2);
  while (i2-- > 0) {
    arr[i2] = thing[i2];
  }
  return arr;
};
const isTypedArray = ((TypedArray) => {
  return (thing) => {
    return TypedArray && thing instanceof TypedArray;
  };
})(typeof Uint8Array !== "undefined" && getPrototypeOf$1(Uint8Array));
const forEachEntry = (obj, fn) => {
  const generator = obj && obj[Symbol.iterator];
  const iterator = generator.call(obj);
  let result;
  while ((result = iterator.next()) && !result.done) {
    const pair = result.value;
    fn.call(obj, pair[0], pair[1]);
  }
};
const matchAll = (regExp, str) => {
  let matches;
  const arr = [];
  while ((matches = regExp.exec(str)) !== null) {
    arr.push(matches);
  }
  return arr;
};
const isHTMLForm = kindOfTest("HTMLFormElement");
const toCamelCase = (str) => {
  return str.toLowerCase().replace(
    /[_-\s]([a-z\d])(\w*)/g,
    function replacer(m3, p1, p2) {
      return p1.toUpperCase() + p2;
    }
  );
};
const hasOwnProperty$1 = (({ hasOwnProperty: hasOwnProperty2 }) => (obj, prop) => hasOwnProperty2.call(obj, prop))(Object.prototype);
const isRegExp = kindOfTest("RegExp");
const reduceDescriptors = (obj, reducer) => {
  const descriptors2 = Object.getOwnPropertyDescriptors(obj);
  const reducedDescriptors = {};
  forEach(descriptors2, (descriptor, name) => {
    if (reducer(descriptor, name, obj) !== false) {
      reducedDescriptors[name] = descriptor;
    }
  });
  Object.defineProperties(obj, reducedDescriptors);
};
const freezeMethods = (obj) => {
  reduceDescriptors(obj, (descriptor, name) => {
    if (isFunction(obj) && ["arguments", "caller", "callee"].indexOf(name) !== -1) {
      return false;
    }
    const value = obj[name];
    if (!isFunction(value))
      return;
    descriptor.enumerable = false;
    if ("writable" in descriptor) {
      descriptor.writable = false;
      return;
    }
    if (!descriptor.set) {
      descriptor.set = () => {
        throw Error("Can not rewrite read-only method '" + name + "'");
      };
    }
  });
};
const toObjectSet = (arrayOrString, delimiter) => {
  const obj = {};
  const define = (arr) => {
    arr.forEach((value) => {
      obj[value] = true;
    });
  };
  isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
  return obj;
};
const noop = () => {
};
const toFiniteNumber = (value, defaultValue) => {
  value = +value;
  return Number.isFinite(value) ? value : defaultValue;
};
const toJSONObject = (obj) => {
  const stack = new Array(10);
  const visit = (source, i2) => {
    if (isObject(source)) {
      if (stack.indexOf(source) >= 0) {
        return;
      }
      if (!("toJSON" in source)) {
        stack[i2] = source;
        const target = isArray(source) ? [] : {};
        forEach(source, (value, key) => {
          const reducedValue = visit(value, i2 + 1);
          !isUndefined(reducedValue) && (target[key] = reducedValue);
        });
        stack[i2] = void 0;
        return target;
      }
    }
    return source;
  };
  return visit(obj, 0);
};
var utils = {
  isArray,
  isArrayBuffer,
  isBuffer,
  isFormData,
  isArrayBufferView,
  isString,
  isNumber,
  isBoolean,
  isObject,
  isPlainObject,
  isUndefined,
  isDate: isDate$1,
  isFile,
  isBlob,
  isRegExp,
  isFunction,
  isStream,
  isURLSearchParams,
  isTypedArray,
  isFileList,
  forEach,
  merge,
  extend,
  trim,
  stripBOM,
  inherits,
  toFlatObject,
  kindOf,
  kindOfTest,
  endsWith,
  toArray,
  forEachEntry,
  matchAll,
  isHTMLForm,
  hasOwnProperty: hasOwnProperty$1,
  hasOwnProp: hasOwnProperty$1,
  reduceDescriptors,
  freezeMethods,
  toObjectSet,
  toCamelCase,
  noop,
  toFiniteNumber,
  findKey,
  global: _global,
  isContextDefined,
  toJSONObject
};
function AxiosError(message, code, config, request, response) {
  Error.call(this);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, this.constructor);
  } else {
    this.stack = new Error().stack;
  }
  this.message = message;
  this.name = "AxiosError";
  code && (this.code = code);
  config && (this.config = config);
  request && (this.request = request);
  response && (this.response = response);
}
utils.inherits(AxiosError, Error, {
  toJSON: function toJSON() {
    return {
      message: this.message,
      name: this.name,
      description: this.description,
      number: this.number,
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      config: utils.toJSONObject(this.config),
      code: this.code,
      status: this.response && this.response.status ? this.response.status : null
    };
  }
});
const prototype$1 = AxiosError.prototype;
const descriptors = {};
[
  "ERR_BAD_OPTION_VALUE",
  "ERR_BAD_OPTION",
  "ECONNABORTED",
  "ETIMEDOUT",
  "ERR_NETWORK",
  "ERR_FR_TOO_MANY_REDIRECTS",
  "ERR_DEPRECATED",
  "ERR_BAD_RESPONSE",
  "ERR_BAD_REQUEST",
  "ERR_CANCELED",
  "ERR_NOT_SUPPORT",
  "ERR_INVALID_URL"
].forEach((code) => {
  descriptors[code] = { value: code };
});
Object.defineProperties(AxiosError, descriptors);
Object.defineProperty(prototype$1, "isAxiosError", { value: true });
AxiosError.from = (error, code, config, request, response, customProps) => {
  const axiosError = Object.create(prototype$1);
  utils.toFlatObject(error, axiosError, function filter2(obj) {
    return obj !== Error.prototype;
  }, (prop) => {
    return prop !== "isAxiosError";
  });
  AxiosError.call(axiosError, error.message, code, config, request, response);
  axiosError.cause = error;
  axiosError.name = error.name;
  customProps && Object.assign(axiosError, customProps);
  return axiosError;
};
var browser = typeof self == "object" ? self.FormData : window.FormData;
var FormData$2 = browser;
function isVisitable(thing) {
  return utils.isPlainObject(thing) || utils.isArray(thing);
}
function removeBrackets(key) {
  return utils.endsWith(key, "[]") ? key.slice(0, -2) : key;
}
function renderKey(path, key, dots) {
  if (!path)
    return key;
  return path.concat(key).map(function each2(token, i2) {
    token = removeBrackets(token);
    return !dots && i2 ? "[" + token + "]" : token;
  }).join(dots ? "." : "");
}
function isFlatArray(arr) {
  return utils.isArray(arr) && !arr.some(isVisitable);
}
const predicates = utils.toFlatObject(utils, {}, null, function filter(prop) {
  return /^is[A-Z]/.test(prop);
});
function isSpecCompliant(thing) {
  return thing && utils.isFunction(thing.append) && thing[Symbol.toStringTag] === "FormData" && thing[Symbol.iterator];
}
function toFormData(obj, formData, options) {
  if (!utils.isObject(obj)) {
    throw new TypeError("target must be an object");
  }
  formData = formData || new (FormData$2 || FormData)();
  options = utils.toFlatObject(options, {
    metaTokens: true,
    dots: false,
    indexes: false
  }, false, function defined(option, source) {
    return !utils.isUndefined(source[option]);
  });
  const metaTokens = options.metaTokens;
  const visitor = options.visitor || defaultVisitor;
  const dots = options.dots;
  const indexes = options.indexes;
  const _Blob = options.Blob || typeof Blob !== "undefined" && Blob;
  const useBlob = _Blob && isSpecCompliant(formData);
  if (!utils.isFunction(visitor)) {
    throw new TypeError("visitor must be a function");
  }
  function convertValue(value) {
    if (value === null)
      return "";
    if (utils.isDate(value)) {
      return value.toISOString();
    }
    if (!useBlob && utils.isBlob(value)) {
      throw new AxiosError("Blob is not supported. Use a Buffer instead.");
    }
    if (utils.isArrayBuffer(value) || utils.isTypedArray(value)) {
      return useBlob && typeof Blob === "function" ? new Blob([value]) : Buffer.from(value);
    }
    return value;
  }
  function defaultVisitor(value, key, path) {
    let arr = value;
    if (value && !path && typeof value === "object") {
      if (utils.endsWith(key, "{}")) {
        key = metaTokens ? key : key.slice(0, -2);
        value = JSON.stringify(value);
      } else if (utils.isArray(value) && isFlatArray(value) || (utils.isFileList(value) || utils.endsWith(key, "[]") && (arr = utils.toArray(value)))) {
        key = removeBrackets(key);
        arr.forEach(function each2(el, index) {
          !(utils.isUndefined(el) || el === null) && formData.append(
            indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]",
            convertValue(el)
          );
        });
        return false;
      }
    }
    if (isVisitable(value)) {
      return true;
    }
    formData.append(renderKey(path, key, dots), convertValue(value));
    return false;
  }
  const stack = [];
  const exposedHelpers = Object.assign(predicates, {
    defaultVisitor,
    convertValue,
    isVisitable
  });
  function build(value, path) {
    if (utils.isUndefined(value))
      return;
    if (stack.indexOf(value) !== -1) {
      throw Error("Circular reference detected in " + path.join("."));
    }
    stack.push(value);
    utils.forEach(value, function each2(el, key) {
      const result = !(utils.isUndefined(el) || el === null) && visitor.call(
        formData,
        el,
        utils.isString(key) ? key.trim() : key,
        path,
        exposedHelpers
      );
      if (result === true) {
        build(el, path ? path.concat(key) : [key]);
      }
    });
    stack.pop();
  }
  if (!utils.isObject(obj)) {
    throw new TypeError("data must be an object");
  }
  build(obj);
  return formData;
}
function encode$1(str) {
  const charMap = {
    "!": "%21",
    "'": "%27",
    "(": "%28",
    ")": "%29",
    "~": "%7E",
    "%20": "+",
    "%00": "\0"
  };
  return encodeURIComponent(str).replace(/[!'()~]|%20|%00/g, function replacer(match) {
    return charMap[match];
  });
}
function AxiosURLSearchParams(params, options) {
  this._pairs = [];
  params && toFormData(params, this, options);
}
const prototype = AxiosURLSearchParams.prototype;
prototype.append = function append(name, value) {
  this._pairs.push([name, value]);
};
prototype.toString = function toString2(encoder) {
  const _encode = encoder ? function(value) {
    return encoder.call(this, value, encode$1);
  } : encode$1;
  return this._pairs.map(function each2(pair) {
    return _encode(pair[0]) + "=" + _encode(pair[1]);
  }, "").join("&");
};
function encode(val) {
  return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
function buildURL(url, params, options) {
  if (!params) {
    return url;
  }
  const _encode = options && options.encode || encode;
  const serializeFn = options && options.serialize;
  let serializedParams;
  if (serializeFn) {
    serializedParams = serializeFn(params, options);
  } else {
    serializedParams = utils.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, options).toString(_encode);
  }
  if (serializedParams) {
    const hashmarkIndex = url.indexOf("#");
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }
    url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
  }
  return url;
}
class InterceptorManager {
  constructor() {
    this.handlers = [];
  }
  use(fulfilled, rejected, options) {
    this.handlers.push({
      fulfilled,
      rejected,
      synchronous: options ? options.synchronous : false,
      runWhen: options ? options.runWhen : null
    });
    return this.handlers.length - 1;
  }
  eject(id) {
    if (this.handlers[id]) {
      this.handlers[id] = null;
    }
  }
  clear() {
    if (this.handlers) {
      this.handlers = [];
    }
  }
  forEach(fn) {
    utils.forEach(this.handlers, function forEachHandler(h4) {
      if (h4 !== null) {
        fn(h4);
      }
    });
  }
}
var InterceptorManager$1 = InterceptorManager;
var transitionalDefaults = {
  silentJSONParsing: true,
  forcedJSONParsing: true,
  clarifyTimeoutError: false
};
var URLSearchParams$1 = typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams;
var FormData$1 = FormData;
const isStandardBrowserEnv = (() => {
  let product;
  if (typeof navigator !== "undefined" && ((product = navigator.product) === "ReactNative" || product === "NativeScript" || product === "NS")) {
    return false;
  }
  return typeof window !== "undefined" && typeof document !== "undefined";
})();
const isStandardBrowserWebWorkerEnv = (() => {
  return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
})();
var platform = {
  isBrowser: true,
  classes: {
    URLSearchParams: URLSearchParams$1,
    FormData: FormData$1,
    Blob
  },
  isStandardBrowserEnv,
  isStandardBrowserWebWorkerEnv,
  protocols: ["http", "https", "file", "blob", "url", "data"]
};
function toURLEncodedForm(data, options) {
  return toFormData(data, new platform.classes.URLSearchParams(), Object.assign({
    visitor: function(value, key, path, helpers2) {
      if (platform.isNode && utils.isBuffer(value)) {
        this.append(key, value.toString("base64"));
        return false;
      }
      return helpers2.defaultVisitor.apply(this, arguments);
    }
  }, options));
}
function parsePropPath(name) {
  return utils.matchAll(/\w+|\[(\w*)]/g, name).map((match) => {
    return match[0] === "[]" ? "" : match[1] || match[0];
  });
}
function arrayToObject(arr) {
  const obj = {};
  const keys = Object.keys(arr);
  let i2;
  const len = keys.length;
  let key;
  for (i2 = 0; i2 < len; i2++) {
    key = keys[i2];
    obj[key] = arr[key];
  }
  return obj;
}
function formDataToJSON(formData) {
  function buildPath(path, value, target, index) {
    let name = path[index++];
    const isNumericKey = Number.isFinite(+name);
    const isLast = index >= path.length;
    name = !name && utils.isArray(target) ? target.length : name;
    if (isLast) {
      if (utils.hasOwnProp(target, name)) {
        target[name] = [target[name], value];
      } else {
        target[name] = value;
      }
      return !isNumericKey;
    }
    if (!target[name] || !utils.isObject(target[name])) {
      target[name] = [];
    }
    const result = buildPath(path, value, target[name], index);
    if (result && utils.isArray(target[name])) {
      target[name] = arrayToObject(target[name]);
    }
    return !isNumericKey;
  }
  if (utils.isFormData(formData) && utils.isFunction(formData.entries)) {
    const obj = {};
    utils.forEachEntry(formData, (name, value) => {
      buildPath(parsePropPath(name), value, obj, 0);
    });
    return obj;
  }
  return null;
}
const DEFAULT_CONTENT_TYPE = {
  "Content-Type": void 0
};
function stringifySafely(rawValue, parser, encoder) {
  if (utils.isString(rawValue)) {
    try {
      (parser || JSON.parse)(rawValue);
      return utils.trim(rawValue);
    } catch (e2) {
      if (e2.name !== "SyntaxError") {
        throw e2;
      }
    }
  }
  return (encoder || JSON.stringify)(rawValue);
}
const defaults = {
  transitional: transitionalDefaults,
  adapter: ["xhr", "http"],
  transformRequest: [function transformRequest(data, headers) {
    const contentType = headers.getContentType() || "";
    const hasJSONContentType = contentType.indexOf("application/json") > -1;
    const isObjectPayload = utils.isObject(data);
    if (isObjectPayload && utils.isHTMLForm(data)) {
      data = new FormData(data);
    }
    const isFormData2 = utils.isFormData(data);
    if (isFormData2) {
      if (!hasJSONContentType) {
        return data;
      }
      return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
    }
    if (utils.isArrayBuffer(data) || utils.isBuffer(data) || utils.isStream(data) || utils.isFile(data) || utils.isBlob(data)) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
      return data.toString();
    }
    let isFileList2;
    if (isObjectPayload) {
      if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
        return toURLEncodedForm(data, this.formSerializer).toString();
      }
      if ((isFileList2 = utils.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
        const _FormData = this.env && this.env.FormData;
        return toFormData(
          isFileList2 ? { "files[]": data } : data,
          _FormData && new _FormData(),
          this.formSerializer
        );
      }
    }
    if (isObjectPayload || hasJSONContentType) {
      headers.setContentType("application/json", false);
      return stringifySafely(data);
    }
    return data;
  }],
  transformResponse: [function transformResponse(data) {
    const transitional2 = this.transitional || defaults.transitional;
    const forcedJSONParsing = transitional2 && transitional2.forcedJSONParsing;
    const JSONRequested = this.responseType === "json";
    if (data && utils.isString(data) && (forcedJSONParsing && !this.responseType || JSONRequested)) {
      const silentJSONParsing = transitional2 && transitional2.silentJSONParsing;
      const strictJSONParsing = !silentJSONParsing && JSONRequested;
      try {
        return JSON.parse(data);
      } catch (e2) {
        if (strictJSONParsing) {
          if (e2.name === "SyntaxError") {
            throw AxiosError.from(e2, AxiosError.ERR_BAD_RESPONSE, this, null, this.response);
          }
          throw e2;
        }
      }
    }
    return data;
  }],
  timeout: 0,
  xsrfCookieName: "XSRF-TOKEN",
  xsrfHeaderName: "X-XSRF-TOKEN",
  maxContentLength: -1,
  maxBodyLength: -1,
  env: {
    FormData: platform.classes.FormData,
    Blob: platform.classes.Blob
  },
  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  },
  headers: {
    common: {
      "Accept": "application/json, text/plain, */*"
    }
  }
};
utils.forEach(["delete", "get", "head"], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});
utils.forEach(["post", "put", "patch"], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});
var defaults$1 = defaults;
const ignoreDuplicateOf = utils.toObjectSet([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "user-agent"
]);
var parseHeaders = (rawHeaders) => {
  const parsed = {};
  let key;
  let val;
  let i2;
  rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
    i2 = line.indexOf(":");
    key = line.substring(0, i2).trim().toLowerCase();
    val = line.substring(i2 + 1).trim();
    if (!key || parsed[key] && ignoreDuplicateOf[key]) {
      return;
    }
    if (key === "set-cookie") {
      if (parsed[key]) {
        parsed[key].push(val);
      } else {
        parsed[key] = [val];
      }
    } else {
      parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
    }
  });
  return parsed;
};
const $internals = Symbol("internals");
function normalizeHeader(header) {
  return header && String(header).trim().toLowerCase();
}
function normalizeValue(value) {
  if (value === false || value == null) {
    return value;
  }
  return utils.isArray(value) ? value.map(normalizeValue) : String(value);
}
function parseTokens(str) {
  const tokens = /* @__PURE__ */ Object.create(null);
  const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
  let match;
  while (match = tokensRE.exec(str)) {
    tokens[match[1]] = match[2];
  }
  return tokens;
}
function isValidHeaderName(str) {
  return /^[-_a-zA-Z]+$/.test(str.trim());
}
function matchHeaderValue(context, value, header, filter2) {
  if (utils.isFunction(filter2)) {
    return filter2.call(this, value, header);
  }
  if (!utils.isString(value))
    return;
  if (utils.isString(filter2)) {
    return value.indexOf(filter2) !== -1;
  }
  if (utils.isRegExp(filter2)) {
    return filter2.test(value);
  }
}
function formatHeader(header) {
  return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w2, char, str) => {
    return char.toUpperCase() + str;
  });
}
function buildAccessors(obj, header) {
  const accessorName = utils.toCamelCase(" " + header);
  ["get", "set", "has"].forEach((methodName) => {
    Object.defineProperty(obj, methodName + accessorName, {
      value: function(arg1, arg2, arg3) {
        return this[methodName].call(this, header, arg1, arg2, arg3);
      },
      configurable: true
    });
  });
}
class AxiosHeaders {
  constructor(headers) {
    headers && this.set(headers);
  }
  set(header, valueOrRewrite, rewrite) {
    const self2 = this;
    function setHeader(_value, _header, _rewrite) {
      const lHeader = normalizeHeader(_header);
      if (!lHeader) {
        throw new Error("header name must be a non-empty string");
      }
      const key = utils.findKey(self2, lHeader);
      if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
        self2[key || _header] = normalizeValue(_value);
      }
    }
    const setHeaders = (headers, _rewrite) => utils.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
    if (utils.isPlainObject(header) || header instanceof this.constructor) {
      setHeaders(header, valueOrRewrite);
    } else if (utils.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
      setHeaders(parseHeaders(header), valueOrRewrite);
    } else {
      header != null && setHeader(valueOrRewrite, header, rewrite);
    }
    return this;
  }
  get(header, parser) {
    header = normalizeHeader(header);
    if (header) {
      const key = utils.findKey(this, header);
      if (key) {
        const value = this[key];
        if (!parser) {
          return value;
        }
        if (parser === true) {
          return parseTokens(value);
        }
        if (utils.isFunction(parser)) {
          return parser.call(this, value, key);
        }
        if (utils.isRegExp(parser)) {
          return parser.exec(value);
        }
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(header, matcher) {
    header = normalizeHeader(header);
    if (header) {
      const key = utils.findKey(this, header);
      return !!(key && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
    }
    return false;
  }
  delete(header, matcher) {
    const self2 = this;
    let deleted = false;
    function deleteHeader(_header) {
      _header = normalizeHeader(_header);
      if (_header) {
        const key = utils.findKey(self2, _header);
        if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
          delete self2[key];
          deleted = true;
        }
      }
    }
    if (utils.isArray(header)) {
      header.forEach(deleteHeader);
    } else {
      deleteHeader(header);
    }
    return deleted;
  }
  clear() {
    return Object.keys(this).forEach(this.delete.bind(this));
  }
  normalize(format2) {
    const self2 = this;
    const headers = {};
    utils.forEach(this, (value, header) => {
      const key = utils.findKey(headers, header);
      if (key) {
        self2[key] = normalizeValue(value);
        delete self2[header];
        return;
      }
      const normalized = format2 ? formatHeader(header) : String(header).trim();
      if (normalized !== header) {
        delete self2[header];
      }
      self2[normalized] = normalizeValue(value);
      headers[normalized] = true;
    });
    return this;
  }
  concat(...targets) {
    return this.constructor.concat(this, ...targets);
  }
  toJSON(asStrings) {
    const obj = /* @__PURE__ */ Object.create(null);
    utils.forEach(this, (value, header) => {
      value != null && value !== false && (obj[header] = asStrings && utils.isArray(value) ? value.join(", ") : value);
    });
    return obj;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(thing) {
    return thing instanceof this ? thing : new this(thing);
  }
  static concat(first, ...targets) {
    const computed = new this(first);
    targets.forEach((target) => computed.set(target));
    return computed;
  }
  static accessor(header) {
    const internals = this[$internals] = this[$internals] = {
      accessors: {}
    };
    const accessors = internals.accessors;
    const prototype2 = this.prototype;
    function defineAccessor(_header) {
      const lHeader = normalizeHeader(_header);
      if (!accessors[lHeader]) {
        buildAccessors(prototype2, _header);
        accessors[lHeader] = true;
      }
    }
    utils.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
    return this;
  }
}
AxiosHeaders.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent"]);
utils.freezeMethods(AxiosHeaders.prototype);
utils.freezeMethods(AxiosHeaders);
var AxiosHeaders$1 = AxiosHeaders;
function transformData(fns, response) {
  const config = this || defaults$1;
  const context = response || config;
  const headers = AxiosHeaders$1.from(context.headers);
  let data = context.data;
  utils.forEach(fns, function transform(fn) {
    data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
  });
  headers.normalize();
  return data;
}
function isCancel(value) {
  return !!(value && value.__CANCEL__);
}
function CanceledError(message, config, request) {
  AxiosError.call(this, message == null ? "canceled" : message, AxiosError.ERR_CANCELED, config, request);
  this.name = "CanceledError";
}
utils.inherits(CanceledError, AxiosError, {
  __CANCEL__: true
});
var httpAdapter = null;
function settle(resolve, reject, response) {
  const validateStatus2 = response.config.validateStatus;
  if (!response.status || !validateStatus2 || validateStatus2(response.status)) {
    resolve(response);
  } else {
    reject(new AxiosError(
      "Request failed with status code " + response.status,
      [AxiosError.ERR_BAD_REQUEST, AxiosError.ERR_BAD_RESPONSE][Math.floor(response.status / 100) - 4],
      response.config,
      response.request,
      response
    ));
  }
}
var cookies = platform.isStandardBrowserEnv ? function standardBrowserEnv() {
  return {
    write: function write(name, value, expires, path, domain, secure) {
      const cookie = [];
      cookie.push(name + "=" + encodeURIComponent(value));
      if (utils.isNumber(expires)) {
        cookie.push("expires=" + new Date(expires).toGMTString());
      }
      if (utils.isString(path)) {
        cookie.push("path=" + path);
      }
      if (utils.isString(domain)) {
        cookie.push("domain=" + domain);
      }
      if (secure === true) {
        cookie.push("secure");
      }
      document.cookie = cookie.join("; ");
    },
    read: function read(name) {
      const match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
      return match ? decodeURIComponent(match[3]) : null;
    },
    remove: function remove(name) {
      this.write(name, "", Date.now() - 864e5);
    }
  };
}() : function nonStandardBrowserEnv() {
  return {
    write: function write() {
    },
    read: function read() {
      return null;
    },
    remove: function remove() {
    }
  };
}();
function isAbsoluteURL(url) {
  return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
}
function combineURLs(baseURL, relativeURL) {
  return relativeURL ? baseURL.replace(/\/+$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
}
function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
}
var isURLSameOrigin = platform.isStandardBrowserEnv ? function standardBrowserEnv2() {
  const msie = /(msie|trident)/i.test(navigator.userAgent);
  const urlParsingNode = document.createElement("a");
  let originURL;
  function resolveURL(url) {
    let href = url;
    if (msie) {
      urlParsingNode.setAttribute("href", href);
      href = urlParsingNode.href;
    }
    urlParsingNode.setAttribute("href", href);
    return {
      href: urlParsingNode.href,
      protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, "") : "",
      host: urlParsingNode.host,
      search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, "") : "",
      hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, "") : "",
      hostname: urlParsingNode.hostname,
      port: urlParsingNode.port,
      pathname: urlParsingNode.pathname.charAt(0) === "/" ? urlParsingNode.pathname : "/" + urlParsingNode.pathname
    };
  }
  originURL = resolveURL(window.location.href);
  return function isURLSameOrigin2(requestURL2) {
    const parsed = utils.isString(requestURL2) ? resolveURL(requestURL2) : requestURL2;
    return parsed.protocol === originURL.protocol && parsed.host === originURL.host;
  };
}() : function nonStandardBrowserEnv2() {
  return function isURLSameOrigin2() {
    return true;
  };
}();
function parseProtocol(url) {
  const match = /^([-+\w]{1,25})(:?\/\/|:)/.exec(url);
  return match && match[1] || "";
}
function speedometer(samplesCount, min) {
  samplesCount = samplesCount || 10;
  const bytes = new Array(samplesCount);
  const timestamps = new Array(samplesCount);
  let head = 0;
  let tail = 0;
  let firstSampleTS;
  min = min !== void 0 ? min : 1e3;
  return function push(chunkLength) {
    const now = Date.now();
    const startedAt = timestamps[tail];
    if (!firstSampleTS) {
      firstSampleTS = now;
    }
    bytes[head] = chunkLength;
    timestamps[head] = now;
    let i2 = tail;
    let bytesCount = 0;
    while (i2 !== head) {
      bytesCount += bytes[i2++];
      i2 = i2 % samplesCount;
    }
    head = (head + 1) % samplesCount;
    if (head === tail) {
      tail = (tail + 1) % samplesCount;
    }
    if (now - firstSampleTS < min) {
      return;
    }
    const passed = startedAt && now - startedAt;
    return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
  };
}
function progressEventReducer(listener, isDownloadStream) {
  let bytesNotified = 0;
  const _speedometer = speedometer(50, 250);
  return (e2) => {
    const loaded = e2.loaded;
    const total = e2.lengthComputable ? e2.total : void 0;
    const progressBytes = loaded - bytesNotified;
    const rate = _speedometer(progressBytes);
    const inRange = loaded <= total;
    bytesNotified = loaded;
    const data = {
      loaded,
      total,
      progress: total ? loaded / total : void 0,
      bytes: progressBytes,
      rate: rate ? rate : void 0,
      estimated: rate && total && inRange ? (total - loaded) / rate : void 0,
      event: e2
    };
    data[isDownloadStream ? "download" : "upload"] = true;
    listener(data);
  };
}
const isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
var xhrAdapter = isXHRAdapterSupported && function(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    let requestData = config.data;
    const requestHeaders = AxiosHeaders$1.from(config.headers).normalize();
    const responseType = config.responseType;
    let onCanceled;
    function done() {
      if (config.cancelToken) {
        config.cancelToken.unsubscribe(onCanceled);
      }
      if (config.signal) {
        config.signal.removeEventListener("abort", onCanceled);
      }
    }
    if (utils.isFormData(requestData) && (platform.isStandardBrowserEnv || platform.isStandardBrowserWebWorkerEnv)) {
      requestHeaders.setContentType(false);
    }
    let request = new XMLHttpRequest();
    if (config.auth) {
      const username = config.auth.username || "";
      const password = config.auth.password ? unescape(encodeURIComponent(config.auth.password)) : "";
      requestHeaders.set("Authorization", "Basic " + btoa(username + ":" + password));
    }
    const fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);
    request.timeout = config.timeout;
    function onloadend() {
      if (!request) {
        return;
      }
      const responseHeaders = AxiosHeaders$1.from(
        "getAllResponseHeaders" in request && request.getAllResponseHeaders()
      );
      const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
      const response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config,
        request
      };
      settle(function _resolve(value) {
        resolve(value);
        done();
      }, function _reject(err) {
        reject(err);
        done();
      }, response);
      request = null;
    }
    if ("onloadend" in request) {
      request.onloadend = onloadend;
    } else {
      request.onreadystatechange = function handleLoad() {
        if (!request || request.readyState !== 4) {
          return;
        }
        if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf("file:") === 0)) {
          return;
        }
        setTimeout(onloadend);
      };
    }
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }
      reject(new AxiosError("Request aborted", AxiosError.ECONNABORTED, config, request));
      request = null;
    };
    request.onerror = function handleError() {
      reject(new AxiosError("Network Error", AxiosError.ERR_NETWORK, config, request));
      request = null;
    };
    request.ontimeout = function handleTimeout() {
      let timeoutErrorMessage = config.timeout ? "timeout of " + config.timeout + "ms exceeded" : "timeout exceeded";
      const transitional2 = config.transitional || transitionalDefaults;
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(new AxiosError(
        timeoutErrorMessage,
        transitional2.clarifyTimeoutError ? AxiosError.ETIMEDOUT : AxiosError.ECONNABORTED,
        config,
        request
      ));
      request = null;
    };
    if (platform.isStandardBrowserEnv) {
      const xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName && cookies.read(config.xsrfCookieName);
      if (xsrfValue) {
        requestHeaders.set(config.xsrfHeaderName, xsrfValue);
      }
    }
    requestData === void 0 && requestHeaders.setContentType(null);
    if ("setRequestHeader" in request) {
      utils.forEach(requestHeaders.toJSON(), function setRequestHeader(val, key) {
        request.setRequestHeader(key, val);
      });
    }
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }
    if (responseType && responseType !== "json") {
      request.responseType = config.responseType;
    }
    if (typeof config.onDownloadProgress === "function") {
      request.addEventListener("progress", progressEventReducer(config.onDownloadProgress, true));
    }
    if (typeof config.onUploadProgress === "function" && request.upload) {
      request.upload.addEventListener("progress", progressEventReducer(config.onUploadProgress));
    }
    if (config.cancelToken || config.signal) {
      onCanceled = (cancel) => {
        if (!request) {
          return;
        }
        reject(!cancel || cancel.type ? new CanceledError(null, config, request) : cancel);
        request.abort();
        request = null;
      };
      config.cancelToken && config.cancelToken.subscribe(onCanceled);
      if (config.signal) {
        config.signal.aborted ? onCanceled() : config.signal.addEventListener("abort", onCanceled);
      }
    }
    const protocol = parseProtocol(fullPath);
    if (protocol && platform.protocols.indexOf(protocol) === -1) {
      reject(new AxiosError("Unsupported protocol " + protocol + ":", AxiosError.ERR_BAD_REQUEST, config));
      return;
    }
    request.send(requestData || null);
  });
};
const knownAdapters = {
  http: httpAdapter,
  xhr: xhrAdapter
};
utils.forEach(knownAdapters, (fn, value) => {
  if (fn) {
    try {
      Object.defineProperty(fn, "name", { value });
    } catch (e2) {
    }
    Object.defineProperty(fn, "adapterName", { value });
  }
});
var adapters = {
  getAdapter: (adapters2) => {
    adapters2 = utils.isArray(adapters2) ? adapters2 : [adapters2];
    const { length } = adapters2;
    let nameOrAdapter;
    let adapter;
    for (let i2 = 0; i2 < length; i2++) {
      nameOrAdapter = adapters2[i2];
      if (adapter = utils.isString(nameOrAdapter) ? knownAdapters[nameOrAdapter.toLowerCase()] : nameOrAdapter) {
        break;
      }
    }
    if (!adapter) {
      if (adapter === false) {
        throw new AxiosError(
          `Adapter ${nameOrAdapter} is not supported by the environment`,
          "ERR_NOT_SUPPORT"
        );
      }
      throw new Error(
        utils.hasOwnProp(knownAdapters, nameOrAdapter) ? `Adapter '${nameOrAdapter}' is not available in the build` : `Unknown adapter '${nameOrAdapter}'`
      );
    }
    if (!utils.isFunction(adapter)) {
      throw new TypeError("adapter is not a function");
    }
    return adapter;
  },
  adapters: knownAdapters
};
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }
  if (config.signal && config.signal.aborted) {
    throw new CanceledError(null, config);
  }
}
function dispatchRequest(config) {
  throwIfCancellationRequested(config);
  config.headers = AxiosHeaders$1.from(config.headers);
  config.data = transformData.call(
    config,
    config.transformRequest
  );
  if (["post", "put", "patch"].indexOf(config.method) !== -1) {
    config.headers.setContentType("application/x-www-form-urlencoded", false);
  }
  const adapter = adapters.getAdapter(config.adapter || defaults$1.adapter);
  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);
    response.data = transformData.call(
      config,
      config.transformResponse,
      response
    );
    response.headers = AxiosHeaders$1.from(response.headers);
    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);
      if (reason && reason.response) {
        reason.response.data = transformData.call(
          config,
          config.transformResponse,
          reason.response
        );
        reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
      }
    }
    return Promise.reject(reason);
  });
}
const headersToObject = (thing) => thing instanceof AxiosHeaders$1 ? thing.toJSON() : thing;
function mergeConfig(config1, config2) {
  config2 = config2 || {};
  const config = {};
  function getMergedValue(target, source, caseless) {
    if (utils.isPlainObject(target) && utils.isPlainObject(source)) {
      return utils.merge.call({ caseless }, target, source);
    } else if (utils.isPlainObject(source)) {
      return utils.merge({}, source);
    } else if (utils.isArray(source)) {
      return source.slice();
    }
    return source;
  }
  function mergeDeepProperties(a3, b2, caseless) {
    if (!utils.isUndefined(b2)) {
      return getMergedValue(a3, b2, caseless);
    } else if (!utils.isUndefined(a3)) {
      return getMergedValue(void 0, a3, caseless);
    }
  }
  function valueFromConfig2(a3, b2) {
    if (!utils.isUndefined(b2)) {
      return getMergedValue(void 0, b2);
    }
  }
  function defaultToConfig2(a3, b2) {
    if (!utils.isUndefined(b2)) {
      return getMergedValue(void 0, b2);
    } else if (!utils.isUndefined(a3)) {
      return getMergedValue(void 0, a3);
    }
  }
  function mergeDirectKeys(a3, b2, prop) {
    if (prop in config2) {
      return getMergedValue(a3, b2);
    } else if (prop in config1) {
      return getMergedValue(void 0, a3);
    }
  }
  const mergeMap = {
    url: valueFromConfig2,
    method: valueFromConfig2,
    data: valueFromConfig2,
    baseURL: defaultToConfig2,
    transformRequest: defaultToConfig2,
    transformResponse: defaultToConfig2,
    paramsSerializer: defaultToConfig2,
    timeout: defaultToConfig2,
    timeoutMessage: defaultToConfig2,
    withCredentials: defaultToConfig2,
    adapter: defaultToConfig2,
    responseType: defaultToConfig2,
    xsrfCookieName: defaultToConfig2,
    xsrfHeaderName: defaultToConfig2,
    onUploadProgress: defaultToConfig2,
    onDownloadProgress: defaultToConfig2,
    decompress: defaultToConfig2,
    maxContentLength: defaultToConfig2,
    maxBodyLength: defaultToConfig2,
    beforeRedirect: defaultToConfig2,
    transport: defaultToConfig2,
    httpAgent: defaultToConfig2,
    httpsAgent: defaultToConfig2,
    cancelToken: defaultToConfig2,
    socketPath: defaultToConfig2,
    responseEncoding: defaultToConfig2,
    validateStatus: mergeDirectKeys,
    headers: (a3, b2) => mergeDeepProperties(headersToObject(a3), headersToObject(b2), true)
  };
  utils.forEach(Object.keys(config1).concat(Object.keys(config2)), function computeConfigValue(prop) {
    const merge2 = mergeMap[prop] || mergeDeepProperties;
    const configValue = merge2(config1[prop], config2[prop], prop);
    utils.isUndefined(configValue) && merge2 !== mergeDirectKeys || (config[prop] = configValue);
  });
  return config;
}
const VERSION = "1.2.1";
const validators$1 = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i2) => {
  validators$1[type] = function validator2(thing) {
    return typeof thing === type || "a" + (i2 < 1 ? "n " : " ") + type;
  };
});
const deprecatedWarnings = {};
validators$1.transitional = function transitional(validator2, version, message) {
  function formatMessage(opt, desc) {
    return "[Axios v" + VERSION + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
  }
  return (value, opt, opts) => {
    if (validator2 === false) {
      throw new AxiosError(
        formatMessage(opt, " has been removed" + (version ? " in " + version : "")),
        AxiosError.ERR_DEPRECATED
      );
    }
    if (version && !deprecatedWarnings[opt]) {
      deprecatedWarnings[opt] = true;
      console.warn(
        formatMessage(
          opt,
          " has been deprecated since v" + version + " and will be removed in the near future"
        )
      );
    }
    return validator2 ? validator2(value, opt, opts) : true;
  };
};
function assertOptions(options, schema, allowUnknown) {
  if (typeof options !== "object") {
    throw new AxiosError("options must be an object", AxiosError.ERR_BAD_OPTION_VALUE);
  }
  const keys = Object.keys(options);
  let i2 = keys.length;
  while (i2-- > 0) {
    const opt = keys[i2];
    const validator2 = schema[opt];
    if (validator2) {
      const value = options[opt];
      const result = value === void 0 || validator2(value, opt, options);
      if (result !== true) {
        throw new AxiosError("option " + opt + " must be " + result, AxiosError.ERR_BAD_OPTION_VALUE);
      }
      continue;
    }
    if (allowUnknown !== true) {
      throw new AxiosError("Unknown option " + opt, AxiosError.ERR_BAD_OPTION);
    }
  }
}
var validator = {
  assertOptions,
  validators: validators$1
};
const validators = validator.validators;
class Axios {
  constructor(instanceConfig) {
    this.defaults = instanceConfig;
    this.interceptors = {
      request: new InterceptorManager$1(),
      response: new InterceptorManager$1()
    };
  }
  request(configOrUrl, config) {
    if (typeof configOrUrl === "string") {
      config = config || {};
      config.url = configOrUrl;
    } else {
      config = configOrUrl || {};
    }
    config = mergeConfig(this.defaults, config);
    const { transitional: transitional2, paramsSerializer, headers } = config;
    if (transitional2 !== void 0) {
      validator.assertOptions(transitional2, {
        silentJSONParsing: validators.transitional(validators.boolean),
        forcedJSONParsing: validators.transitional(validators.boolean),
        clarifyTimeoutError: validators.transitional(validators.boolean)
      }, false);
    }
    if (paramsSerializer !== void 0) {
      validator.assertOptions(paramsSerializer, {
        encode: validators.function,
        serialize: validators.function
      }, true);
    }
    config.method = (config.method || this.defaults.method || "get").toLowerCase();
    let contextHeaders;
    contextHeaders = headers && utils.merge(
      headers.common,
      headers[config.method]
    );
    contextHeaders && utils.forEach(
      ["delete", "get", "head", "post", "put", "patch", "common"],
      (method) => {
        delete headers[method];
      }
    );
    config.headers = AxiosHeaders$1.concat(contextHeaders, headers);
    const requestInterceptorChain = [];
    let synchronousRequestInterceptors = true;
    this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
      if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) {
        return;
      }
      synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
      requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
    });
    const responseInterceptorChain = [];
    this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
      responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
    });
    let promise;
    let i2 = 0;
    let len;
    if (!synchronousRequestInterceptors) {
      const chain = [dispatchRequest.bind(this), void 0];
      chain.unshift.apply(chain, requestInterceptorChain);
      chain.push.apply(chain, responseInterceptorChain);
      len = chain.length;
      promise = Promise.resolve(config);
      while (i2 < len) {
        promise = promise.then(chain[i2++], chain[i2++]);
      }
      return promise;
    }
    len = requestInterceptorChain.length;
    let newConfig = config;
    i2 = 0;
    while (i2 < len) {
      const onFulfilled = requestInterceptorChain[i2++];
      const onRejected = requestInterceptorChain[i2++];
      try {
        newConfig = onFulfilled(newConfig);
      } catch (error) {
        onRejected.call(this, error);
        break;
      }
    }
    try {
      promise = dispatchRequest.call(this, newConfig);
    } catch (error) {
      return Promise.reject(error);
    }
    i2 = 0;
    len = responseInterceptorChain.length;
    while (i2 < len) {
      promise = promise.then(responseInterceptorChain[i2++], responseInterceptorChain[i2++]);
    }
    return promise;
  }
  getUri(config) {
    config = mergeConfig(this.defaults, config);
    const fullPath = buildFullPath(config.baseURL, config.url);
    return buildURL(fullPath, config.params, config.paramsSerializer);
  }
}
utils.forEach(["delete", "get", "head", "options"], function forEachMethodNoData2(method) {
  Axios.prototype[method] = function(url, config) {
    return this.request(mergeConfig(config || {}, {
      method,
      url,
      data: (config || {}).data
    }));
  };
});
utils.forEach(["post", "put", "patch"], function forEachMethodWithData2(method) {
  function generateHTTPMethod(isForm) {
    return function httpMethod(url, data, config) {
      return this.request(mergeConfig(config || {}, {
        method,
        headers: isForm ? {
          "Content-Type": "multipart/form-data"
        } : {},
        url,
        data
      }));
    };
  }
  Axios.prototype[method] = generateHTTPMethod();
  Axios.prototype[method + "Form"] = generateHTTPMethod(true);
});
var Axios$1 = Axios;
class CancelToken {
  constructor(executor) {
    if (typeof executor !== "function") {
      throw new TypeError("executor must be a function.");
    }
    let resolvePromise;
    this.promise = new Promise(function promiseExecutor(resolve) {
      resolvePromise = resolve;
    });
    const token = this;
    this.promise.then((cancel) => {
      if (!token._listeners)
        return;
      let i2 = token._listeners.length;
      while (i2-- > 0) {
        token._listeners[i2](cancel);
      }
      token._listeners = null;
    });
    this.promise.then = (onfulfilled) => {
      let _resolve;
      const promise = new Promise((resolve) => {
        token.subscribe(resolve);
        _resolve = resolve;
      }).then(onfulfilled);
      promise.cancel = function reject() {
        token.unsubscribe(_resolve);
      };
      return promise;
    };
    executor(function cancel(message, config, request) {
      if (token.reason) {
        return;
      }
      token.reason = new CanceledError(message, config, request);
      resolvePromise(token.reason);
    });
  }
  throwIfRequested() {
    if (this.reason) {
      throw this.reason;
    }
  }
  subscribe(listener) {
    if (this.reason) {
      listener(this.reason);
      return;
    }
    if (this._listeners) {
      this._listeners.push(listener);
    } else {
      this._listeners = [listener];
    }
  }
  unsubscribe(listener) {
    if (!this._listeners) {
      return;
    }
    const index = this._listeners.indexOf(listener);
    if (index !== -1) {
      this._listeners.splice(index, 1);
    }
  }
  static source() {
    let cancel;
    const token = new CancelToken(function executor(c2) {
      cancel = c2;
    });
    return {
      token,
      cancel
    };
  }
}
var CancelToken$1 = CancelToken;
function spread(callback) {
  return function wrap2(arr) {
    return callback.apply(null, arr);
  };
}
function isAxiosError(payload) {
  return utils.isObject(payload) && payload.isAxiosError === true;
}
function createInstance(defaultConfig) {
  const context = new Axios$1(defaultConfig);
  const instance = bind(Axios$1.prototype.request, context);
  utils.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
  utils.extend(instance, context, null, { allOwnKeys: true });
  instance.create = function create2(instanceConfig) {
    return createInstance(mergeConfig(defaultConfig, instanceConfig));
  };
  return instance;
}
const axios$1 = createInstance(defaults$1);
axios$1.Axios = Axios$1;
axios$1.CanceledError = CanceledError;
axios$1.CancelToken = CancelToken$1;
axios$1.isCancel = isCancel;
axios$1.VERSION = VERSION;
axios$1.toFormData = toFormData;
axios$1.AxiosError = AxiosError;
axios$1.Cancel = axios$1.CanceledError;
axios$1.all = function all(promises) {
  return Promise.all(promises);
};
axios$1.spread = spread;
axios$1.isAxiosError = isAxiosError;
axios$1.mergeConfig = mergeConfig;
axios$1.AxiosHeaders = AxiosHeaders$1;
axios$1.formToJSON = (thing) => formDataToJSON(utils.isHTMLForm(thing) ? new FormData(thing) : thing);
axios$1.default = axios$1;
var axios$2 = axios$1;
const denyList = /* @__PURE__ */ new Set([
  "ENOTFOUND",
  "ENETUNREACH",
  "UNABLE_TO_GET_ISSUER_CERT",
  "UNABLE_TO_GET_CRL",
  "UNABLE_TO_DECRYPT_CERT_SIGNATURE",
  "UNABLE_TO_DECRYPT_CRL_SIGNATURE",
  "UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY",
  "CERT_SIGNATURE_FAILURE",
  "CRL_SIGNATURE_FAILURE",
  "CERT_NOT_YET_VALID",
  "CERT_HAS_EXPIRED",
  "CRL_NOT_YET_VALID",
  "CRL_HAS_EXPIRED",
  "ERROR_IN_CERT_NOT_BEFORE_FIELD",
  "ERROR_IN_CERT_NOT_AFTER_FIELD",
  "ERROR_IN_CRL_LAST_UPDATE_FIELD",
  "ERROR_IN_CRL_NEXT_UPDATE_FIELD",
  "OUT_OF_MEM",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
  "CERT_CHAIN_TOO_LONG",
  "CERT_REVOKED",
  "INVALID_CA",
  "PATH_LENGTH_EXCEEDED",
  "INVALID_PURPOSE",
  "CERT_UNTRUSTED",
  "CERT_REJECTED",
  "HOSTNAME_MISMATCH"
]);
var isRetryAllowed = (error) => !denyList.has(error && error.code);
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function() {
    var self2 = this, args = arguments;
    return new Promise(function(resolve, reject) {
      var gen = fn.apply(self2, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(void 0);
    });
  };
}
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) {
      symbols = symbols.filter(function(sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    }
    keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread(target) {
  for (var i2 = 1; i2 < arguments.length; i2++) {
    var source = arguments[i2] != null ? arguments[i2] : {};
    if (i2 % 2) {
      ownKeys(Object(source), true).forEach(function(key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function(key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }
  return target;
}
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
var namespace = "axios-retry";
function isNetworkError(error) {
  return !error.response && Boolean(error.code) && error.code !== "ECONNABORTED" && isRetryAllowed(error);
}
var SAFE_HTTP_METHODS = ["get", "head", "options"];
var IDEMPOTENT_HTTP_METHODS = SAFE_HTTP_METHODS.concat(["put", "delete"]);
function isRetryableError(error) {
  return error.code !== "ECONNABORTED" && (!error.response || error.response.status >= 500 && error.response.status <= 599);
}
function isSafeRequestError(error) {
  if (!error.config) {
    return false;
  }
  return isRetryableError(error) && SAFE_HTTP_METHODS.indexOf(error.config.method) !== -1;
}
function isIdempotentRequestError(error) {
  if (!error.config) {
    return false;
  }
  return isRetryableError(error) && IDEMPOTENT_HTTP_METHODS.indexOf(error.config.method) !== -1;
}
function isNetworkOrIdempotentRequestError(error) {
  return isNetworkError(error) || isIdempotentRequestError(error);
}
function noDelay() {
  return 0;
}
function exponentialDelay() {
  var retryNumber = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
  var delay = Math.pow(2, retryNumber) * 100;
  var randomSum = delay * 0.2 * Math.random();
  return delay + randomSum;
}
function getCurrentState(config) {
  var currentState = config[namespace] || {};
  currentState.retryCount = currentState.retryCount || 0;
  config[namespace] = currentState;
  return currentState;
}
function getRequestOptions(config, defaultOptions2) {
  return _objectSpread(_objectSpread({}, defaultOptions2), config[namespace]);
}
function fixConfig(axios2, config) {
  if (axios2.defaults.agent === config.agent) {
    delete config.agent;
  }
  if (axios2.defaults.httpAgent === config.httpAgent) {
    delete config.httpAgent;
  }
  if (axios2.defaults.httpsAgent === config.httpsAgent) {
    delete config.httpsAgent;
  }
}
function shouldRetry(_x, _x2, _x3, _x4) {
  return _shouldRetry.apply(this, arguments);
}
function _shouldRetry() {
  _shouldRetry = _asyncToGenerator(function* (retries, retryCondition, currentState, error) {
    var shouldRetryOrPromise = currentState.retryCount < retries && retryCondition(error);
    if (typeof shouldRetryOrPromise === "object") {
      try {
        var shouldRetryPromiseResult = yield shouldRetryOrPromise;
        return shouldRetryPromiseResult !== false;
      } catch (_err) {
        return false;
      }
    }
    return shouldRetryOrPromise;
  });
  return _shouldRetry.apply(this, arguments);
}
function axiosRetry$1(axios2, defaultOptions2) {
  axios2.interceptors.request.use((config) => {
    var currentState = getCurrentState(config);
    currentState.lastRequestTime = Date.now();
    return config;
  });
  axios2.interceptors.response.use(null, /* @__PURE__ */ function() {
    var _ref2 = _asyncToGenerator(function* (error) {
      var {
        config
      } = error;
      if (!config) {
        return Promise.reject(error);
      }
      var {
        retries = 3,
        retryCondition = isNetworkOrIdempotentRequestError,
        retryDelay = noDelay,
        shouldResetTimeout = false,
        onRetry = () => {
        }
      } = getRequestOptions(config, defaultOptions2);
      var currentState = getCurrentState(config);
      if (yield shouldRetry(retries, retryCondition, currentState, error)) {
        currentState.retryCount += 1;
        var delay = retryDelay(currentState.retryCount, error);
        fixConfig(axios2, config);
        if (!shouldResetTimeout && config.timeout && currentState.lastRequestTime) {
          var lastRequestDuration = Date.now() - currentState.lastRequestTime;
          config.timeout = Math.max(config.timeout - lastRequestDuration - delay, 1);
        }
        config.transformRequest = [(data) => data];
        onRetry(currentState.retryCount, error, config);
        return new Promise((resolve) => setTimeout(() => resolve(axios2(config)), delay));
      }
      return Promise.reject(error);
    });
    return function(_x5) {
      return _ref2.apply(this, arguments);
    };
  }());
}
axiosRetry$1.isNetworkError = isNetworkError;
axiosRetry$1.isSafeRequestError = isSafeRequestError;
axiosRetry$1.isIdempotentRequestError = isIdempotentRequestError;
axiosRetry$1.isNetworkOrIdempotentRequestError = isNetworkOrIdempotentRequestError;
axiosRetry$1.exponentialDelay = exponentialDelay;
axiosRetry$1.isRetryableError = isRetryableError;
function toInteger(dirtyNumber) {
  if (dirtyNumber === null || dirtyNumber === true || dirtyNumber === false) {
    return NaN;
  }
  var number = Number(dirtyNumber);
  if (isNaN(number)) {
    return number;
  }
  return number < 0 ? Math.ceil(number) : Math.floor(number);
}
function requiredArgs(required, args) {
  if (args.length < required) {
    throw new TypeError(required + " argument" + (required > 1 ? "s" : "") + " required, but only " + args.length + " present");
  }
}
function _typeof$2(obj) {
  "@babel/helpers - typeof";
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof$2 = function _typeof2(obj2) {
      return typeof obj2;
    };
  } else {
    _typeof$2 = function _typeof2(obj2) {
      return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
    };
  }
  return _typeof$2(obj);
}
function toDate(argument) {
  requiredArgs(1, arguments);
  var argStr = Object.prototype.toString.call(argument);
  if (argument instanceof Date || _typeof$2(argument) === "object" && argStr === "[object Date]") {
    return new Date(argument.getTime());
  } else if (typeof argument === "number" || argStr === "[object Number]") {
    return new Date(argument);
  } else {
    if ((typeof argument === "string" || argStr === "[object String]") && typeof console !== "undefined") {
      console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments");
      console.warn(new Error().stack);
    }
    return new Date(NaN);
  }
}
function addMilliseconds(dirtyDate, dirtyAmount) {
  requiredArgs(2, arguments);
  var timestamp = toDate(dirtyDate).getTime();
  var amount = toInteger(dirtyAmount);
  return new Date(timestamp + amount);
}
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function getTimezoneOffsetInMilliseconds(date) {
  var utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds()));
  utcDate.setUTCFullYear(date.getFullYear());
  return date.getTime() - utcDate.getTime();
}
function _typeof$1(obj) {
  "@babel/helpers - typeof";
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof$1 = function _typeof2(obj2) {
      return typeof obj2;
    };
  } else {
    _typeof$1 = function _typeof2(obj2) {
      return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
    };
  }
  return _typeof$1(obj);
}
function isDate(value) {
  requiredArgs(1, arguments);
  return value instanceof Date || _typeof$1(value) === "object" && Object.prototype.toString.call(value) === "[object Date]";
}
function isValid(dirtyDate) {
  requiredArgs(1, arguments);
  if (!isDate(dirtyDate) && typeof dirtyDate !== "number") {
    return false;
  }
  var date = toDate(dirtyDate);
  return !isNaN(Number(date));
}
function subMilliseconds(dirtyDate, dirtyAmount) {
  requiredArgs(2, arguments);
  var amount = toInteger(dirtyAmount);
  return addMilliseconds(dirtyDate, -amount);
}
var MILLISECONDS_IN_DAY = 864e5;
function getUTCDayOfYear(dirtyDate) {
  requiredArgs(1, arguments);
  var date = toDate(dirtyDate);
  var timestamp = date.getTime();
  date.setUTCMonth(0, 1);
  date.setUTCHours(0, 0, 0, 0);
  var startOfYearTimestamp = date.getTime();
  var difference = timestamp - startOfYearTimestamp;
  return Math.floor(difference / MILLISECONDS_IN_DAY) + 1;
}
function startOfUTCISOWeek(dirtyDate) {
  requiredArgs(1, arguments);
  var weekStartsOn = 1;
  var date = toDate(dirtyDate);
  var day = date.getUTCDay();
  var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
  date.setUTCDate(date.getUTCDate() - diff);
  date.setUTCHours(0, 0, 0, 0);
  return date;
}
function getUTCISOWeekYear(dirtyDate) {
  requiredArgs(1, arguments);
  var date = toDate(dirtyDate);
  var year = date.getUTCFullYear();
  var fourthOfJanuaryOfNextYear = new Date(0);
  fourthOfJanuaryOfNextYear.setUTCFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setUTCHours(0, 0, 0, 0);
  var startOfNextYear = startOfUTCISOWeek(fourthOfJanuaryOfNextYear);
  var fourthOfJanuaryOfThisYear = new Date(0);
  fourthOfJanuaryOfThisYear.setUTCFullYear(year, 0, 4);
  fourthOfJanuaryOfThisYear.setUTCHours(0, 0, 0, 0);
  var startOfThisYear = startOfUTCISOWeek(fourthOfJanuaryOfThisYear);
  if (date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
function startOfUTCISOWeekYear(dirtyDate) {
  requiredArgs(1, arguments);
  var year = getUTCISOWeekYear(dirtyDate);
  var fourthOfJanuary = new Date(0);
  fourthOfJanuary.setUTCFullYear(year, 0, 4);
  fourthOfJanuary.setUTCHours(0, 0, 0, 0);
  var date = startOfUTCISOWeek(fourthOfJanuary);
  return date;
}
var MILLISECONDS_IN_WEEK$1 = 6048e5;
function getUTCISOWeek(dirtyDate) {
  requiredArgs(1, arguments);
  var date = toDate(dirtyDate);
  var diff = startOfUTCISOWeek(date).getTime() - startOfUTCISOWeekYear(date).getTime();
  return Math.round(diff / MILLISECONDS_IN_WEEK$1) + 1;
}
function startOfUTCWeek(dirtyDate, options) {
  var _ref2, _ref22, _ref3, _options$weekStartsOn, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
  requiredArgs(1, arguments);
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = toInteger((_ref2 = (_ref22 = (_ref3 = (_options$weekStartsOn = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options === null || options === void 0 ? void 0 : (_options$locale = options.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.weekStartsOn) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions2.weekStartsOn) !== null && _ref22 !== void 0 ? _ref22 : (_defaultOptions$local = defaultOptions2.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.weekStartsOn) !== null && _ref2 !== void 0 ? _ref2 : 0);
  if (!(weekStartsOn >= 0 && weekStartsOn <= 6)) {
    throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
  }
  var date = toDate(dirtyDate);
  var day = date.getUTCDay();
  var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
  date.setUTCDate(date.getUTCDate() - diff);
  date.setUTCHours(0, 0, 0, 0);
  return date;
}
function getUTCWeekYear(dirtyDate, options) {
  var _ref2, _ref22, _ref3, _options$firstWeekCon, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
  requiredArgs(1, arguments);
  var date = toDate(dirtyDate);
  var year = date.getUTCFullYear();
  var defaultOptions2 = getDefaultOptions();
  var firstWeekContainsDate = toInteger((_ref2 = (_ref22 = (_ref3 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 ? void 0 : (_options$locale = options.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions2.firstWeekContainsDate) !== null && _ref22 !== void 0 ? _ref22 : (_defaultOptions$local = defaultOptions2.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : 1);
  if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
    throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
  }
  var firstWeekOfNextYear = new Date(0);
  firstWeekOfNextYear.setUTCFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setUTCHours(0, 0, 0, 0);
  var startOfNextYear = startOfUTCWeek(firstWeekOfNextYear, options);
  var firstWeekOfThisYear = new Date(0);
  firstWeekOfThisYear.setUTCFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setUTCHours(0, 0, 0, 0);
  var startOfThisYear = startOfUTCWeek(firstWeekOfThisYear, options);
  if (date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
function startOfUTCWeekYear(dirtyDate, options) {
  var _ref2, _ref22, _ref3, _options$firstWeekCon, _options$locale, _options$locale$optio, _defaultOptions$local, _defaultOptions$local2;
  requiredArgs(1, arguments);
  var defaultOptions2 = getDefaultOptions();
  var firstWeekContainsDate = toInteger((_ref2 = (_ref22 = (_ref3 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 ? void 0 : (_options$locale = options.locale) === null || _options$locale === void 0 ? void 0 : (_options$locale$optio = _options$locale.options) === null || _options$locale$optio === void 0 ? void 0 : _options$locale$optio.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions2.firstWeekContainsDate) !== null && _ref22 !== void 0 ? _ref22 : (_defaultOptions$local = defaultOptions2.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref2 !== void 0 ? _ref2 : 1);
  var year = getUTCWeekYear(dirtyDate, options);
  var firstWeek = new Date(0);
  firstWeek.setUTCFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setUTCHours(0, 0, 0, 0);
  var date = startOfUTCWeek(firstWeek, options);
  return date;
}
var MILLISECONDS_IN_WEEK = 6048e5;
function getUTCWeek(dirtyDate, options) {
  requiredArgs(1, arguments);
  var date = toDate(dirtyDate);
  var diff = startOfUTCWeek(date, options).getTime() - startOfUTCWeekYear(date, options).getTime();
  return Math.round(diff / MILLISECONDS_IN_WEEK) + 1;
}
function addLeadingZeros(number, targetLength) {
  var sign = number < 0 ? "-" : "";
  var output = Math.abs(number).toString();
  while (output.length < targetLength) {
    output = "0" + output;
  }
  return sign + output;
}
var formatters$2 = {
  y: function y(date, token) {
    var signedYear = date.getUTCFullYear();
    var year = signedYear > 0 ? signedYear : 1 - signedYear;
    return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
  },
  M: function M(date, token) {
    var month = date.getUTCMonth();
    return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
  },
  d: function d(date, token) {
    return addLeadingZeros(date.getUTCDate(), token.length);
  },
  a: function a(date, token) {
    var dayPeriodEnumValue = date.getUTCHours() / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return dayPeriodEnumValue.toUpperCase();
      case "aaa":
        return dayPeriodEnumValue;
      case "aaaaa":
        return dayPeriodEnumValue[0];
      case "aaaa":
      default:
        return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
    }
  },
  h: function h2(date, token) {
    return addLeadingZeros(date.getUTCHours() % 12 || 12, token.length);
  },
  H: function H(date, token) {
    return addLeadingZeros(date.getUTCHours(), token.length);
  },
  m: function m(date, token) {
    return addLeadingZeros(date.getUTCMinutes(), token.length);
  },
  s: function s(date, token) {
    return addLeadingZeros(date.getUTCSeconds(), token.length);
  },
  S: function S(date, token) {
    var numberOfDigits = token.length;
    var milliseconds = date.getUTCMilliseconds();
    var fractionalSeconds = Math.floor(milliseconds * Math.pow(10, numberOfDigits - 3));
    return addLeadingZeros(fractionalSeconds, token.length);
  }
};
var formatters$3 = formatters$2;
var dayPeriodEnum = {
  am: "am",
  pm: "pm",
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night"
};
var formatters = {
  G: function G(date, token, localize) {
    var era = date.getUTCFullYear() > 0 ? 1 : 0;
    switch (token) {
      case "G":
      case "GG":
      case "GGG":
        return localize.era(era, {
          width: "abbreviated"
        });
      case "GGGGG":
        return localize.era(era, {
          width: "narrow"
        });
      case "GGGG":
      default:
        return localize.era(era, {
          width: "wide"
        });
    }
  },
  y: function y2(date, token, localize) {
    if (token === "yo") {
      var signedYear = date.getUTCFullYear();
      var year = signedYear > 0 ? signedYear : 1 - signedYear;
      return localize.ordinalNumber(year, {
        unit: "year"
      });
    }
    return formatters$3.y(date, token);
  },
  Y: function Y(date, token, localize, options) {
    var signedWeekYear = getUTCWeekYear(date, options);
    var weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;
    if (token === "YY") {
      var twoDigitYear = weekYear % 100;
      return addLeadingZeros(twoDigitYear, 2);
    }
    if (token === "Yo") {
      return localize.ordinalNumber(weekYear, {
        unit: "year"
      });
    }
    return addLeadingZeros(weekYear, token.length);
  },
  R: function R(date, token) {
    var isoWeekYear = getUTCISOWeekYear(date);
    return addLeadingZeros(isoWeekYear, token.length);
  },
  u: function u(date, token) {
    var year = date.getUTCFullYear();
    return addLeadingZeros(year, token.length);
  },
  Q: function Q(date, token, localize) {
    var quarter = Math.ceil((date.getUTCMonth() + 1) / 3);
    switch (token) {
      case "Q":
        return String(quarter);
      case "QQ":
        return addLeadingZeros(quarter, 2);
      case "Qo":
        return localize.ordinalNumber(quarter, {
          unit: "quarter"
        });
      case "QQQ":
        return localize.quarter(quarter, {
          width: "abbreviated",
          context: "formatting"
        });
      case "QQQQQ":
        return localize.quarter(quarter, {
          width: "narrow",
          context: "formatting"
        });
      case "QQQQ":
      default:
        return localize.quarter(quarter, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  q: function q(date, token, localize) {
    var quarter = Math.ceil((date.getUTCMonth() + 1) / 3);
    switch (token) {
      case "q":
        return String(quarter);
      case "qq":
        return addLeadingZeros(quarter, 2);
      case "qo":
        return localize.ordinalNumber(quarter, {
          unit: "quarter"
        });
      case "qqq":
        return localize.quarter(quarter, {
          width: "abbreviated",
          context: "standalone"
        });
      case "qqqqq":
        return localize.quarter(quarter, {
          width: "narrow",
          context: "standalone"
        });
      case "qqqq":
      default:
        return localize.quarter(quarter, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  M: function M2(date, token, localize) {
    var month = date.getUTCMonth();
    switch (token) {
      case "M":
      case "MM":
        return formatters$3.M(date, token);
      case "Mo":
        return localize.ordinalNumber(month + 1, {
          unit: "month"
        });
      case "MMM":
        return localize.month(month, {
          width: "abbreviated",
          context: "formatting"
        });
      case "MMMMM":
        return localize.month(month, {
          width: "narrow",
          context: "formatting"
        });
      case "MMMM":
      default:
        return localize.month(month, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  L: function L(date, token, localize) {
    var month = date.getUTCMonth();
    switch (token) {
      case "L":
        return String(month + 1);
      case "LL":
        return addLeadingZeros(month + 1, 2);
      case "Lo":
        return localize.ordinalNumber(month + 1, {
          unit: "month"
        });
      case "LLL":
        return localize.month(month, {
          width: "abbreviated",
          context: "standalone"
        });
      case "LLLLL":
        return localize.month(month, {
          width: "narrow",
          context: "standalone"
        });
      case "LLLL":
      default:
        return localize.month(month, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  w: function w(date, token, localize, options) {
    var week = getUTCWeek(date, options);
    if (token === "wo") {
      return localize.ordinalNumber(week, {
        unit: "week"
      });
    }
    return addLeadingZeros(week, token.length);
  },
  I: function I(date, token, localize) {
    var isoWeek = getUTCISOWeek(date);
    if (token === "Io") {
      return localize.ordinalNumber(isoWeek, {
        unit: "week"
      });
    }
    return addLeadingZeros(isoWeek, token.length);
  },
  d: function d2(date, token, localize) {
    if (token === "do") {
      return localize.ordinalNumber(date.getUTCDate(), {
        unit: "date"
      });
    }
    return formatters$3.d(date, token);
  },
  D: function D(date, token, localize) {
    var dayOfYear = getUTCDayOfYear(date);
    if (token === "Do") {
      return localize.ordinalNumber(dayOfYear, {
        unit: "dayOfYear"
      });
    }
    return addLeadingZeros(dayOfYear, token.length);
  },
  E: function E(date, token, localize) {
    var dayOfWeek = date.getUTCDay();
    switch (token) {
      case "E":
      case "EE":
      case "EEE":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "EEEEE":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "EEEEEE":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "EEEE":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  e: function e(date, token, localize, options) {
    var dayOfWeek = date.getUTCDay();
    var localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "e":
        return String(localDayOfWeek);
      case "ee":
        return addLeadingZeros(localDayOfWeek, 2);
      case "eo":
        return localize.ordinalNumber(localDayOfWeek, {
          unit: "day"
        });
      case "eee":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "eeeee":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "eeeeee":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "eeee":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  c: function c(date, token, localize, options) {
    var dayOfWeek = date.getUTCDay();
    var localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "c":
        return String(localDayOfWeek);
      case "cc":
        return addLeadingZeros(localDayOfWeek, token.length);
      case "co":
        return localize.ordinalNumber(localDayOfWeek, {
          unit: "day"
        });
      case "ccc":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "standalone"
        });
      case "ccccc":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "standalone"
        });
      case "cccccc":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "standalone"
        });
      case "cccc":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  i: function i(date, token, localize) {
    var dayOfWeek = date.getUTCDay();
    var isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
    switch (token) {
      case "i":
        return String(isoDayOfWeek);
      case "ii":
        return addLeadingZeros(isoDayOfWeek, token.length);
      case "io":
        return localize.ordinalNumber(isoDayOfWeek, {
          unit: "day"
        });
      case "iii":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "iiiii":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "iiiiii":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "iiii":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  a: function a2(date, token, localize) {
    var hours = date.getUTCHours();
    var dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "aaa":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "aaaaa":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "aaaa":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  b: function b(date, token, localize) {
    var hours = date.getUTCHours();
    var dayPeriodEnumValue;
    if (hours === 12) {
      dayPeriodEnumValue = dayPeriodEnum.noon;
    } else if (hours === 0) {
      dayPeriodEnumValue = dayPeriodEnum.midnight;
    } else {
      dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    }
    switch (token) {
      case "b":
      case "bb":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "bbb":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "bbbbb":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "bbbb":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  B: function B(date, token, localize) {
    var hours = date.getUTCHours();
    var dayPeriodEnumValue;
    if (hours >= 17) {
      dayPeriodEnumValue = dayPeriodEnum.evening;
    } else if (hours >= 12) {
      dayPeriodEnumValue = dayPeriodEnum.afternoon;
    } else if (hours >= 4) {
      dayPeriodEnumValue = dayPeriodEnum.morning;
    } else {
      dayPeriodEnumValue = dayPeriodEnum.night;
    }
    switch (token) {
      case "B":
      case "BB":
      case "BBB":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "BBBBB":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "BBBB":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  h: function h3(date, token, localize) {
    if (token === "ho") {
      var hours = date.getUTCHours() % 12;
      if (hours === 0)
        hours = 12;
      return localize.ordinalNumber(hours, {
        unit: "hour"
      });
    }
    return formatters$3.h(date, token);
  },
  H: function H2(date, token, localize) {
    if (token === "Ho") {
      return localize.ordinalNumber(date.getUTCHours(), {
        unit: "hour"
      });
    }
    return formatters$3.H(date, token);
  },
  K: function K(date, token, localize) {
    var hours = date.getUTCHours() % 12;
    if (token === "Ko") {
      return localize.ordinalNumber(hours, {
        unit: "hour"
      });
    }
    return addLeadingZeros(hours, token.length);
  },
  k: function k(date, token, localize) {
    var hours = date.getUTCHours();
    if (hours === 0)
      hours = 24;
    if (token === "ko") {
      return localize.ordinalNumber(hours, {
        unit: "hour"
      });
    }
    return addLeadingZeros(hours, token.length);
  },
  m: function m2(date, token, localize) {
    if (token === "mo") {
      return localize.ordinalNumber(date.getUTCMinutes(), {
        unit: "minute"
      });
    }
    return formatters$3.m(date, token);
  },
  s: function s2(date, token, localize) {
    if (token === "so") {
      return localize.ordinalNumber(date.getUTCSeconds(), {
        unit: "second"
      });
    }
    return formatters$3.s(date, token);
  },
  S: function S2(date, token) {
    return formatters$3.S(date, token);
  },
  X: function X(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timezoneOffset = originalDate.getTimezoneOffset();
    if (timezoneOffset === 0) {
      return "Z";
    }
    switch (token) {
      case "X":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "XXXX":
      case "XX":
        return formatTimezone(timezoneOffset);
      case "XXXXX":
      case "XXX":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  x: function x(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timezoneOffset = originalDate.getTimezoneOffset();
    switch (token) {
      case "x":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "xxxx":
      case "xx":
        return formatTimezone(timezoneOffset);
      case "xxxxx":
      case "xxx":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  O: function O(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timezoneOffset = originalDate.getTimezoneOffset();
    switch (token) {
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "OOOO":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  z: function z(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timezoneOffset = originalDate.getTimezoneOffset();
    switch (token) {
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "zzzz":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  t: function t(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timestamp = Math.floor(originalDate.getTime() / 1e3);
    return addLeadingZeros(timestamp, token.length);
  },
  T: function T(date, token, _localize, options) {
    var originalDate = options._originalDate || date;
    var timestamp = originalDate.getTime();
    return addLeadingZeros(timestamp, token.length);
  }
};
function formatTimezoneShort(offset, dirtyDelimiter) {
  var sign = offset > 0 ? "-" : "+";
  var absOffset = Math.abs(offset);
  var hours = Math.floor(absOffset / 60);
  var minutes = absOffset % 60;
  if (minutes === 0) {
    return sign + String(hours);
  }
  var delimiter = dirtyDelimiter || "";
  return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
}
function formatTimezoneWithOptionalMinutes(offset, dirtyDelimiter) {
  if (offset % 60 === 0) {
    var sign = offset > 0 ? "-" : "+";
    return sign + addLeadingZeros(Math.abs(offset) / 60, 2);
  }
  return formatTimezone(offset, dirtyDelimiter);
}
function formatTimezone(offset, dirtyDelimiter) {
  var delimiter = dirtyDelimiter || "";
  var sign = offset > 0 ? "-" : "+";
  var absOffset = Math.abs(offset);
  var hours = addLeadingZeros(Math.floor(absOffset / 60), 2);
  var minutes = addLeadingZeros(absOffset % 60, 2);
  return sign + hours + delimiter + minutes;
}
var formatters$1 = formatters;
var dateLongFormatter = function dateLongFormatter2(pattern, formatLong) {
  switch (pattern) {
    case "P":
      return formatLong.date({
        width: "short"
      });
    case "PP":
      return formatLong.date({
        width: "medium"
      });
    case "PPP":
      return formatLong.date({
        width: "long"
      });
    case "PPPP":
    default:
      return formatLong.date({
        width: "full"
      });
  }
};
var timeLongFormatter = function timeLongFormatter2(pattern, formatLong) {
  switch (pattern) {
    case "p":
      return formatLong.time({
        width: "short"
      });
    case "pp":
      return formatLong.time({
        width: "medium"
      });
    case "ppp":
      return formatLong.time({
        width: "long"
      });
    case "pppp":
    default:
      return formatLong.time({
        width: "full"
      });
  }
};
var dateTimeLongFormatter = function dateTimeLongFormatter2(pattern, formatLong) {
  var matchResult = pattern.match(/(P+)(p+)?/) || [];
  var datePattern = matchResult[1];
  var timePattern = matchResult[2];
  if (!timePattern) {
    return dateLongFormatter(pattern, formatLong);
  }
  var dateTimeFormat;
  switch (datePattern) {
    case "P":
      dateTimeFormat = formatLong.dateTime({
        width: "short"
      });
      break;
    case "PP":
      dateTimeFormat = formatLong.dateTime({
        width: "medium"
      });
      break;
    case "PPP":
      dateTimeFormat = formatLong.dateTime({
        width: "long"
      });
      break;
    case "PPPP":
    default:
      dateTimeFormat = formatLong.dateTime({
        width: "full"
      });
      break;
  }
  return dateTimeFormat.replace("{{date}}", dateLongFormatter(datePattern, formatLong)).replace("{{time}}", timeLongFormatter(timePattern, formatLong));
};
var longFormatters = {
  p: timeLongFormatter,
  P: dateTimeLongFormatter
};
var longFormatters$1 = longFormatters;
var protectedDayOfYearTokens = ["D", "DD"];
var protectedWeekYearTokens = ["YY", "YYYY"];
function isProtectedDayOfYearToken(token) {
  return protectedDayOfYearTokens.indexOf(token) !== -1;
}
function isProtectedWeekYearToken(token) {
  return protectedWeekYearTokens.indexOf(token) !== -1;
}
function throwProtectedError(token, format2, input) {
  if (token === "YYYY") {
    throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(format2, "`) for formatting years to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
  } else if (token === "YY") {
    throw new RangeError("Use `yy` instead of `YY` (in `".concat(format2, "`) for formatting years to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
  } else if (token === "D") {
    throw new RangeError("Use `d` instead of `D` (in `".concat(format2, "`) for formatting days of the month to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
  } else if (token === "DD") {
    throw new RangeError("Use `dd` instead of `DD` (in `".concat(format2, "`) for formatting days of the month to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));
  }
}
var formattingTokensRegExp = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
var longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
var escapedStringRegExp = /^'([^]*?)'?$/;
var doubleQuoteRegExp = /''/g;
var unescapedLatinCharacterRegExp = /[a-zA-Z]/;
function format(dirtyDate, dirtyFormatStr, options) {
  var _ref2, _options$locale, _ref22, _ref3, _ref4, _options$firstWeekCon, _options$locale2, _options$locale2$opti, _defaultOptions$local, _defaultOptions$local2, _ref5, _ref6, _ref7, _options$weekStartsOn, _options$locale3, _options$locale3$opti, _defaultOptions$local3, _defaultOptions$local4;
  requiredArgs(2, arguments);
  var formatStr = String(dirtyFormatStr);
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref2 = (_options$locale = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale !== void 0 ? _options$locale : defaultOptions2.locale) !== null && _ref2 !== void 0 ? _ref2 : enUS;
  var firstWeekContainsDate = toInteger((_ref22 = (_ref3 = (_ref4 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 ? void 0 : (_options$locale2 = options.locale) === null || _options$locale2 === void 0 ? void 0 : (_options$locale2$opti = _options$locale2.options) === null || _options$locale2$opti === void 0 ? void 0 : _options$locale2$opti.firstWeekContainsDate) !== null && _ref4 !== void 0 ? _ref4 : defaultOptions2.firstWeekContainsDate) !== null && _ref3 !== void 0 ? _ref3 : (_defaultOptions$local = defaultOptions2.locale) === null || _defaultOptions$local === void 0 ? void 0 : (_defaultOptions$local2 = _defaultOptions$local.options) === null || _defaultOptions$local2 === void 0 ? void 0 : _defaultOptions$local2.firstWeekContainsDate) !== null && _ref22 !== void 0 ? _ref22 : 1);
  if (!(firstWeekContainsDate >= 1 && firstWeekContainsDate <= 7)) {
    throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
  }
  var weekStartsOn = toInteger((_ref5 = (_ref6 = (_ref7 = (_options$weekStartsOn = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options === null || options === void 0 ? void 0 : (_options$locale3 = options.locale) === null || _options$locale3 === void 0 ? void 0 : (_options$locale3$opti = _options$locale3.options) === null || _options$locale3$opti === void 0 ? void 0 : _options$locale3$opti.weekStartsOn) !== null && _ref7 !== void 0 ? _ref7 : defaultOptions2.weekStartsOn) !== null && _ref6 !== void 0 ? _ref6 : (_defaultOptions$local3 = defaultOptions2.locale) === null || _defaultOptions$local3 === void 0 ? void 0 : (_defaultOptions$local4 = _defaultOptions$local3.options) === null || _defaultOptions$local4 === void 0 ? void 0 : _defaultOptions$local4.weekStartsOn) !== null && _ref5 !== void 0 ? _ref5 : 0);
  if (!(weekStartsOn >= 0 && weekStartsOn <= 6)) {
    throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
  }
  if (!locale.localize) {
    throw new RangeError("locale must contain localize property");
  }
  if (!locale.formatLong) {
    throw new RangeError("locale must contain formatLong property");
  }
  var originalDate = toDate(dirtyDate);
  if (!isValid(originalDate)) {
    throw new RangeError("Invalid time value");
  }
  var timezoneOffset = getTimezoneOffsetInMilliseconds(originalDate);
  var utcDate = subMilliseconds(originalDate, timezoneOffset);
  var formatterOptions = {
    firstWeekContainsDate,
    weekStartsOn,
    locale,
    _originalDate: originalDate
  };
  var result = formatStr.match(longFormattingTokensRegExp).map(function(substring) {
    var firstCharacter = substring[0];
    if (firstCharacter === "p" || firstCharacter === "P") {
      var longFormatter = longFormatters$1[firstCharacter];
      return longFormatter(substring, locale.formatLong);
    }
    return substring;
  }).join("").match(formattingTokensRegExp).map(function(substring) {
    if (substring === "''") {
      return "'";
    }
    var firstCharacter = substring[0];
    if (firstCharacter === "'") {
      return cleanEscapedString(substring);
    }
    var formatter = formatters$1[firstCharacter];
    if (formatter) {
      if (!(options !== null && options !== void 0 && options.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(substring)) {
        throwProtectedError(substring, dirtyFormatStr, String(dirtyDate));
      }
      if (!(options !== null && options !== void 0 && options.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(substring)) {
        throwProtectedError(substring, dirtyFormatStr, String(dirtyDate));
      }
      return formatter(utcDate, substring, locale.localize, formatterOptions);
    }
    if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
      throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
    }
    return substring;
  }).join("");
  return result;
}
function cleanEscapedString(input) {
  var matched = input.match(escapedStringRegExp);
  if (!matched) {
    return input;
  }
  return matched[1].replace(doubleQuoteRegExp, "'");
}
/*! @license DOMPurify 2.4.0 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/2.4.0/LICENSE */
function _typeof(obj) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
}
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e2) {
    return false;
  }
}
function _construct(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct2(Parent2, args2, Class2) {
      var a3 = [null];
      a3.push.apply(a3, args2);
      var Constructor = Function.bind.apply(Parent2, a3);
      var instance = new Constructor();
      if (Class2)
        _setPrototypeOf(instance, Class2.prototype);
      return instance;
    };
  }
  return _construct.apply(null, arguments);
}
function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr))
    return _arrayLikeToArray(arr);
}
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
    return Array.from(iter);
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o)
    return;
  if (typeof o === "string")
    return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor)
    n = o.constructor.name;
  if (n === "Map" || n === "Set")
    return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
    return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length)
    len = arr.length;
  for (var i2 = 0, arr2 = new Array(len); i2 < len; i2++)
    arr2[i2] = arr[i2];
  return arr2;
}
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
var hasOwnProperty = Object.hasOwnProperty, setPrototypeOf = Object.setPrototypeOf, isFrozen = Object.isFrozen, getPrototypeOf = Object.getPrototypeOf, getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var freeze = Object.freeze, seal = Object.seal, create = Object.create;
var _ref = typeof Reflect !== "undefined" && Reflect, apply = _ref.apply, construct = _ref.construct;
if (!apply) {
  apply = function apply2(fun, thisValue, args) {
    return fun.apply(thisValue, args);
  };
}
if (!freeze) {
  freeze = function freeze2(x2) {
    return x2;
  };
}
if (!seal) {
  seal = function seal2(x2) {
    return x2;
  };
}
if (!construct) {
  construct = function construct2(Func, args) {
    return _construct(Func, _toConsumableArray(args));
  };
}
var arrayForEach = unapply(Array.prototype.forEach);
var arrayPop = unapply(Array.prototype.pop);
var arrayPush = unapply(Array.prototype.push);
var stringToLowerCase = unapply(String.prototype.toLowerCase);
var stringMatch = unapply(String.prototype.match);
var stringReplace = unapply(String.prototype.replace);
var stringIndexOf = unapply(String.prototype.indexOf);
var stringTrim = unapply(String.prototype.trim);
var regExpTest = unapply(RegExp.prototype.test);
var typeErrorCreate = unconstruct(TypeError);
function unapply(func) {
  return function(thisArg) {
    for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }
    return apply(func, thisArg, args);
  };
}
function unconstruct(func) {
  return function() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    return construct(func, args);
  };
}
function addToSet(set, array, transformCaseFunc) {
  transformCaseFunc = transformCaseFunc ? transformCaseFunc : stringToLowerCase;
  if (setPrototypeOf) {
    setPrototypeOf(set, null);
  }
  var l = array.length;
  while (l--) {
    var element = array[l];
    if (typeof element === "string") {
      var lcElement = transformCaseFunc(element);
      if (lcElement !== element) {
        if (!isFrozen(array)) {
          array[l] = lcElement;
        }
        element = lcElement;
      }
    }
    set[element] = true;
  }
  return set;
}
function clone(object) {
  var newObject = create(null);
  var property;
  for (property in object) {
    if (apply(hasOwnProperty, object, [property])) {
      newObject[property] = object[property];
    }
  }
  return newObject;
}
function lookupGetter(object, prop) {
  while (object !== null) {
    var desc = getOwnPropertyDescriptor(object, prop);
    if (desc) {
      if (desc.get) {
        return unapply(desc.get);
      }
      if (typeof desc.value === "function") {
        return unapply(desc.value);
      }
    }
    object = getPrototypeOf(object);
  }
  function fallbackValue(element) {
    console.warn("fallback value for", element);
    return null;
  }
  return fallbackValue;
}
var html$1 = freeze(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]);
var svg$1 = freeze(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]);
var svgFilters = freeze(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]);
var svgDisallowed = freeze(["animate", "color-profile", "cursor", "discard", "fedropshadow", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]);
var mathMl$1 = freeze(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover"]);
var mathMlDisallowed = freeze(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]);
var text = freeze(["#text"]);
var html = freeze(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "xmlns", "slot"]);
var svg = freeze(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]);
var mathMl = freeze(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]);
var xml = freeze(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]);
var MUSTACHE_EXPR = seal(/\{\{[\w\W]*|[\w\W]*\}\}/gm);
var ERB_EXPR = seal(/<%[\w\W]*|[\w\W]*%>/gm);
var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]/);
var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
var IS_ALLOWED_URI = seal(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
);
var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
var ATTR_WHITESPACE = seal(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
);
var DOCTYPE_NAME = seal(/^html$/i);
var getGlobal = function getGlobal2() {
  return typeof window === "undefined" ? null : window;
};
var _createTrustedTypesPolicy = function _createTrustedTypesPolicy2(trustedTypes, document2) {
  if (_typeof(trustedTypes) !== "object" || typeof trustedTypes.createPolicy !== "function") {
    return null;
  }
  var suffix = null;
  var ATTR_NAME = "data-tt-policy-suffix";
  if (document2.currentScript && document2.currentScript.hasAttribute(ATTR_NAME)) {
    suffix = document2.currentScript.getAttribute(ATTR_NAME);
  }
  var policyName = "dompurify" + (suffix ? "#" + suffix : "");
  try {
    return trustedTypes.createPolicy(policyName, {
      createHTML: function createHTML(html2) {
        return html2;
      },
      createScriptURL: function createScriptURL(scriptUrl) {
        return scriptUrl;
      }
    });
  } catch (_2) {
    console.warn("TrustedTypes policy " + policyName + " could not be created.");
    return null;
  }
};
function createDOMPurify() {
  var window2 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
  var DOMPurify2 = function DOMPurify3(root) {
    return createDOMPurify(root);
  };
  DOMPurify2.version = "2.4.0";
  DOMPurify2.removed = [];
  if (!window2 || !window2.document || window2.document.nodeType !== 9) {
    DOMPurify2.isSupported = false;
    return DOMPurify2;
  }
  var originalDocument = window2.document;
  var document2 = window2.document;
  var DocumentFragment = window2.DocumentFragment, HTMLTemplateElement = window2.HTMLTemplateElement, Node = window2.Node, Element = window2.Element, NodeFilter = window2.NodeFilter, _window$NamedNodeMap = window2.NamedNodeMap, NamedNodeMap = _window$NamedNodeMap === void 0 ? window2.NamedNodeMap || window2.MozNamedAttrMap : _window$NamedNodeMap, HTMLFormElement = window2.HTMLFormElement, DOMParser = window2.DOMParser, trustedTypes = window2.trustedTypes;
  var ElementPrototype = Element.prototype;
  var cloneNode = lookupGetter(ElementPrototype, "cloneNode");
  var getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
  var getChildNodes = lookupGetter(ElementPrototype, "childNodes");
  var getParentNode = lookupGetter(ElementPrototype, "parentNode");
  if (typeof HTMLTemplateElement === "function") {
    var template = document2.createElement("template");
    if (template.content && template.content.ownerDocument) {
      document2 = template.content.ownerDocument;
    }
  }
  var trustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, originalDocument);
  var emptyHTML = trustedTypesPolicy ? trustedTypesPolicy.createHTML("") : "";
  var _document = document2, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
  var importNode = originalDocument.importNode;
  var documentMode = {};
  try {
    documentMode = clone(document2).documentMode ? document2.documentMode : {};
  } catch (_2) {
  }
  var hooks = {};
  DOMPurify2.isSupported = typeof getParentNode === "function" && implementation && typeof implementation.createHTMLDocument !== "undefined" && documentMode !== 9;
  var MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE;
  var IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
  var ALLOWED_TAGS = null;
  var DEFAULT_ALLOWED_TAGS = addToSet({}, [].concat(_toConsumableArray(html$1), _toConsumableArray(svg$1), _toConsumableArray(svgFilters), _toConsumableArray(mathMl$1), _toConsumableArray(text)));
  var ALLOWED_ATTR = null;
  var DEFAULT_ALLOWED_ATTR = addToSet({}, [].concat(_toConsumableArray(html), _toConsumableArray(svg), _toConsumableArray(mathMl), _toConsumableArray(xml)));
  var CUSTOM_ELEMENT_HANDLING = Object.seal(Object.create(null, {
    tagNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    attributeNameCheck: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: true,
      configurable: false,
      enumerable: true,
      value: false
    }
  }));
  var FORBID_TAGS = null;
  var FORBID_ATTR = null;
  var ALLOW_ARIA_ATTR = true;
  var ALLOW_DATA_ATTR = true;
  var ALLOW_UNKNOWN_PROTOCOLS = false;
  var SAFE_FOR_TEMPLATES = false;
  var WHOLE_DOCUMENT = false;
  var SET_CONFIG = false;
  var FORCE_BODY = false;
  var RETURN_DOM = false;
  var RETURN_DOM_FRAGMENT = false;
  var RETURN_TRUSTED_TYPE = false;
  var SANITIZE_DOM = true;
  var SANITIZE_NAMED_PROPS = false;
  var SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
  var KEEP_CONTENT = true;
  var IN_PLACE = false;
  var USE_PROFILES = {};
  var FORBID_CONTENTS = null;
  var DEFAULT_FORBID_CONTENTS = addToSet({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  var DATA_URI_TAGS = null;
  var DEFAULT_DATA_URI_TAGS = addToSet({}, ["audio", "video", "img", "source", "image", "track"]);
  var URI_SAFE_ATTRIBUTES = null;
  var DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]);
  var MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
  var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
  var HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
  var NAMESPACE = HTML_NAMESPACE;
  var IS_EMPTY_INPUT = false;
  var PARSER_MEDIA_TYPE;
  var SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
  var DEFAULT_PARSER_MEDIA_TYPE = "text/html";
  var transformCaseFunc;
  var CONFIG = null;
  var formElement = document2.createElement("form");
  var isRegexOrFunction = function isRegexOrFunction2(testValue) {
    return testValue instanceof RegExp || testValue instanceof Function;
  };
  var _parseConfig = function _parseConfig2(cfg) {
    if (CONFIG && CONFIG === cfg) {
      return;
    }
    if (!cfg || _typeof(cfg) !== "object") {
      cfg = {};
    }
    cfg = clone(cfg);
    PARSER_MEDIA_TYPE = SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? PARSER_MEDIA_TYPE = DEFAULT_PARSER_MEDIA_TYPE : PARSER_MEDIA_TYPE = cfg.PARSER_MEDIA_TYPE;
    transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? function(x2) {
      return x2;
    } : stringToLowerCase;
    ALLOWED_TAGS = "ALLOWED_TAGS" in cfg ? addToSet({}, cfg.ALLOWED_TAGS, transformCaseFunc) : DEFAULT_ALLOWED_TAGS;
    ALLOWED_ATTR = "ALLOWED_ATTR" in cfg ? addToSet({}, cfg.ALLOWED_ATTR, transformCaseFunc) : DEFAULT_ALLOWED_ATTR;
    URI_SAFE_ATTRIBUTES = "ADD_URI_SAFE_ATTR" in cfg ? addToSet(
      clone(DEFAULT_URI_SAFE_ATTRIBUTES),
      cfg.ADD_URI_SAFE_ATTR,
      transformCaseFunc
    ) : DEFAULT_URI_SAFE_ATTRIBUTES;
    DATA_URI_TAGS = "ADD_DATA_URI_TAGS" in cfg ? addToSet(
      clone(DEFAULT_DATA_URI_TAGS),
      cfg.ADD_DATA_URI_TAGS,
      transformCaseFunc
    ) : DEFAULT_DATA_URI_TAGS;
    FORBID_CONTENTS = "FORBID_CONTENTS" in cfg ? addToSet({}, cfg.FORBID_CONTENTS, transformCaseFunc) : DEFAULT_FORBID_CONTENTS;
    FORBID_TAGS = "FORBID_TAGS" in cfg ? addToSet({}, cfg.FORBID_TAGS, transformCaseFunc) : {};
    FORBID_ATTR = "FORBID_ATTR" in cfg ? addToSet({}, cfg.FORBID_ATTR, transformCaseFunc) : {};
    USE_PROFILES = "USE_PROFILES" in cfg ? cfg.USE_PROFILES : false;
    ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
    ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
    ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
    SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
    WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
    RETURN_DOM = cfg.RETURN_DOM || false;
    RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
    RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
    FORCE_BODY = cfg.FORCE_BODY || false;
    SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
    SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
    KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
    IN_PLACE = cfg.IN_PLACE || false;
    IS_ALLOWED_URI$1 = cfg.ALLOWED_URI_REGEXP || IS_ALLOWED_URI$1;
    NAMESPACE = cfg.NAMESPACE || HTML_NAMESPACE;
    if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck)) {
      CUSTOM_ELEMENT_HANDLING.tagNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck;
    }
    if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)) {
      CUSTOM_ELEMENT_HANDLING.attributeNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck;
    }
    if (cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements === "boolean") {
      CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements;
    }
    if (SAFE_FOR_TEMPLATES) {
      ALLOW_DATA_ATTR = false;
    }
    if (RETURN_DOM_FRAGMENT) {
      RETURN_DOM = true;
    }
    if (USE_PROFILES) {
      ALLOWED_TAGS = addToSet({}, _toConsumableArray(text));
      ALLOWED_ATTR = [];
      if (USE_PROFILES.html === true) {
        addToSet(ALLOWED_TAGS, html$1);
        addToSet(ALLOWED_ATTR, html);
      }
      if (USE_PROFILES.svg === true) {
        addToSet(ALLOWED_TAGS, svg$1);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.svgFilters === true) {
        addToSet(ALLOWED_TAGS, svgFilters);
        addToSet(ALLOWED_ATTR, svg);
        addToSet(ALLOWED_ATTR, xml);
      }
      if (USE_PROFILES.mathMl === true) {
        addToSet(ALLOWED_TAGS, mathMl$1);
        addToSet(ALLOWED_ATTR, mathMl);
        addToSet(ALLOWED_ATTR, xml);
      }
    }
    if (cfg.ADD_TAGS) {
      if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) {
        ALLOWED_TAGS = clone(ALLOWED_TAGS);
      }
      addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
    }
    if (cfg.ADD_ATTR) {
      if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
        ALLOWED_ATTR = clone(ALLOWED_ATTR);
      }
      addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
    }
    if (cfg.ADD_URI_SAFE_ATTR) {
      addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
    }
    if (cfg.FORBID_CONTENTS) {
      if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
        FORBID_CONTENTS = clone(FORBID_CONTENTS);
      }
      addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
    }
    if (KEEP_CONTENT) {
      ALLOWED_TAGS["#text"] = true;
    }
    if (WHOLE_DOCUMENT) {
      addToSet(ALLOWED_TAGS, ["html", "head", "body"]);
    }
    if (ALLOWED_TAGS.table) {
      addToSet(ALLOWED_TAGS, ["tbody"]);
      delete FORBID_TAGS.tbody;
    }
    if (freeze) {
      freeze(cfg);
    }
    CONFIG = cfg;
  };
  var MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, ["mi", "mo", "mn", "ms", "mtext"]);
  var HTML_INTEGRATION_POINTS = addToSet({}, ["foreignobject", "desc", "title", "annotation-xml"]);
  var COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, ["title", "style", "font", "a", "script"]);
  var ALL_SVG_TAGS = addToSet({}, svg$1);
  addToSet(ALL_SVG_TAGS, svgFilters);
  addToSet(ALL_SVG_TAGS, svgDisallowed);
  var ALL_MATHML_TAGS = addToSet({}, mathMl$1);
  addToSet(ALL_MATHML_TAGS, mathMlDisallowed);
  var _checkValidNamespace = function _checkValidNamespace2(element) {
    var parent = getParentNode(element);
    if (!parent || !parent.tagName) {
      parent = {
        namespaceURI: HTML_NAMESPACE,
        tagName: "template"
      };
    }
    var tagName = stringToLowerCase(element.tagName);
    var parentTagName = stringToLowerCase(parent.tagName);
    if (element.namespaceURI === SVG_NAMESPACE) {
      if (parent.namespaceURI === HTML_NAMESPACE) {
        return tagName === "svg";
      }
      if (parent.namespaceURI === MATHML_NAMESPACE) {
        return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
      }
      return Boolean(ALL_SVG_TAGS[tagName]);
    }
    if (element.namespaceURI === MATHML_NAMESPACE) {
      if (parent.namespaceURI === HTML_NAMESPACE) {
        return tagName === "math";
      }
      if (parent.namespaceURI === SVG_NAMESPACE) {
        return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
      }
      return Boolean(ALL_MATHML_TAGS[tagName]);
    }
    if (element.namespaceURI === HTML_NAMESPACE) {
      if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
    }
    return false;
  };
  var _forceRemove = function _forceRemove2(node) {
    arrayPush(DOMPurify2.removed, {
      element: node
    });
    try {
      node.parentNode.removeChild(node);
    } catch (_2) {
      try {
        node.outerHTML = emptyHTML;
      } catch (_3) {
        node.remove();
      }
    }
  };
  var _removeAttribute = function _removeAttribute2(name, node) {
    try {
      arrayPush(DOMPurify2.removed, {
        attribute: node.getAttributeNode(name),
        from: node
      });
    } catch (_2) {
      arrayPush(DOMPurify2.removed, {
        attribute: null,
        from: node
      });
    }
    node.removeAttribute(name);
    if (name === "is" && !ALLOWED_ATTR[name]) {
      if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
        try {
          _forceRemove(node);
        } catch (_2) {
        }
      } else {
        try {
          node.setAttribute(name, "");
        } catch (_2) {
        }
      }
    }
  };
  var _initDocument = function _initDocument2(dirty) {
    var doc;
    var leadingWhitespace;
    if (FORCE_BODY) {
      dirty = "<remove></remove>" + dirty;
    } else {
      var matches = stringMatch(dirty, /^[\r\n\t ]+/);
      leadingWhitespace = matches && matches[0];
    }
    if (PARSER_MEDIA_TYPE === "application/xhtml+xml") {
      dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + "</body></html>";
    }
    var dirtyPayload = trustedTypesPolicy ? trustedTypesPolicy.createHTML(dirty) : dirty;
    if (NAMESPACE === HTML_NAMESPACE) {
      try {
        doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
      } catch (_2) {
      }
    }
    if (!doc || !doc.documentElement) {
      doc = implementation.createDocument(NAMESPACE, "template", null);
      try {
        doc.documentElement.innerHTML = IS_EMPTY_INPUT ? "" : dirtyPayload;
      } catch (_2) {
      }
    }
    var body = doc.body || doc.documentElement;
    if (dirty && leadingWhitespace) {
      body.insertBefore(document2.createTextNode(leadingWhitespace), body.childNodes[0] || null);
    }
    if (NAMESPACE === HTML_NAMESPACE) {
      return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
    }
    return WHOLE_DOCUMENT ? doc.documentElement : body;
  };
  var _createIterator = function _createIterator2(root) {
    return createNodeIterator.call(
      root.ownerDocument || root,
      root,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT,
      null,
      false
    );
  };
  var _isClobbered = function _isClobbered2(elm) {
    return elm instanceof HTMLFormElement && (typeof elm.nodeName !== "string" || typeof elm.textContent !== "string" || typeof elm.removeChild !== "function" || !(elm.attributes instanceof NamedNodeMap) || typeof elm.removeAttribute !== "function" || typeof elm.setAttribute !== "function" || typeof elm.namespaceURI !== "string" || typeof elm.insertBefore !== "function");
  };
  var _isNode = function _isNode2(object) {
    return _typeof(Node) === "object" ? object instanceof Node : object && _typeof(object) === "object" && typeof object.nodeType === "number" && typeof object.nodeName === "string";
  };
  var _executeHook = function _executeHook2(entryPoint, currentNode, data) {
    if (!hooks[entryPoint]) {
      return;
    }
    arrayForEach(hooks[entryPoint], function(hook) {
      hook.call(DOMPurify2, currentNode, data, CONFIG);
    });
  };
  var _sanitizeElements = function _sanitizeElements2(currentNode) {
    var content;
    _executeHook("beforeSanitizeElements", currentNode, null);
    if (_isClobbered(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    if (regExpTest(/[\u0080-\uFFFF]/, currentNode.nodeName)) {
      _forceRemove(currentNode);
      return true;
    }
    var tagName = transformCaseFunc(currentNode.nodeName);
    _executeHook("uponSanitizeElement", currentNode, {
      tagName,
      allowedTags: ALLOWED_TAGS
    });
    if (currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && (!_isNode(currentNode.content) || !_isNode(currentNode.content.firstElementChild)) && regExpTest(/<[/\w]/g, currentNode.innerHTML) && regExpTest(/<[/\w]/g, currentNode.textContent)) {
      _forceRemove(currentNode);
      return true;
    }
    if (tagName === "select" && regExpTest(/<template/i, currentNode.innerHTML)) {
      _forceRemove(currentNode);
      return true;
    }
    if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
      if (!FORBID_TAGS[tagName] && _basicCustomElementTest(tagName)) {
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName))
          return false;
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName))
          return false;
      }
      if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
        var parentNode = getParentNode(currentNode) || currentNode.parentNode;
        var childNodes = getChildNodes(currentNode) || currentNode.childNodes;
        if (childNodes && parentNode) {
          var childCount = childNodes.length;
          for (var i2 = childCount - 1; i2 >= 0; --i2) {
            parentNode.insertBefore(cloneNode(childNodes[i2], true), getNextSibling(currentNode));
          }
        }
      }
      _forceRemove(currentNode);
      return true;
    }
    if (currentNode instanceof Element && !_checkValidNamespace(currentNode)) {
      _forceRemove(currentNode);
      return true;
    }
    if ((tagName === "noscript" || tagName === "noembed") && regExpTest(/<\/no(script|embed)/i, currentNode.innerHTML)) {
      _forceRemove(currentNode);
      return true;
    }
    if (SAFE_FOR_TEMPLATES && currentNode.nodeType === 3) {
      content = currentNode.textContent;
      content = stringReplace(content, MUSTACHE_EXPR$1, " ");
      content = stringReplace(content, ERB_EXPR$1, " ");
      if (currentNode.textContent !== content) {
        arrayPush(DOMPurify2.removed, {
          element: currentNode.cloneNode()
        });
        currentNode.textContent = content;
      }
    }
    _executeHook("afterSanitizeElements", currentNode, null);
    return false;
  };
  var _isValidAttribute = function _isValidAttribute2(lcTag, lcName, value) {
    if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document2 || value in formElement)) {
      return false;
    }
    if (ALLOW_DATA_ATTR && !FORBID_ATTR[lcName] && regExpTest(DATA_ATTR$1, lcName))
      ;
    else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName))
      ;
    else if (!ALLOWED_ATTR[lcName] || FORBID_ATTR[lcName]) {
      if (_basicCustomElementTest(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName)) || lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value)))
        ;
      else {
        return false;
      }
    } else if (URI_SAFE_ATTRIBUTES[lcName])
      ;
    else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, "")))
      ;
    else if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag])
      ;
    else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, "")))
      ;
    else if (!value)
      ;
    else {
      return false;
    }
    return true;
  };
  var _basicCustomElementTest = function _basicCustomElementTest2(tagName) {
    return tagName.indexOf("-") > 0;
  };
  var _sanitizeAttributes = function _sanitizeAttributes2(currentNode) {
    var attr;
    var value;
    var lcName;
    var l;
    _executeHook("beforeSanitizeAttributes", currentNode, null);
    var attributes = currentNode.attributes;
    if (!attributes) {
      return;
    }
    var hookEvent = {
      attrName: "",
      attrValue: "",
      keepAttr: true,
      allowedAttributes: ALLOWED_ATTR
    };
    l = attributes.length;
    while (l--) {
      attr = attributes[l];
      var _attr = attr, name = _attr.name, namespaceURI = _attr.namespaceURI;
      value = name === "value" ? attr.value : stringTrim(attr.value);
      lcName = transformCaseFunc(name);
      hookEvent.attrName = lcName;
      hookEvent.attrValue = value;
      hookEvent.keepAttr = true;
      hookEvent.forceKeepAttr = void 0;
      _executeHook("uponSanitizeAttribute", currentNode, hookEvent);
      value = hookEvent.attrValue;
      if (hookEvent.forceKeepAttr) {
        continue;
      }
      _removeAttribute(name, currentNode);
      if (!hookEvent.keepAttr) {
        continue;
      }
      if (regExpTest(/\/>/i, value)) {
        _removeAttribute(name, currentNode);
        continue;
      }
      if (SAFE_FOR_TEMPLATES) {
        value = stringReplace(value, MUSTACHE_EXPR$1, " ");
        value = stringReplace(value, ERB_EXPR$1, " ");
      }
      var lcTag = transformCaseFunc(currentNode.nodeName);
      if (!_isValidAttribute(lcTag, lcName, value)) {
        continue;
      }
      if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name")) {
        _removeAttribute(name, currentNode);
        value = SANITIZE_NAMED_PROPS_PREFIX + value;
      }
      if (trustedTypesPolicy && _typeof(trustedTypes) === "object" && typeof trustedTypes.getAttributeType === "function") {
        if (namespaceURI)
          ;
        else {
          switch (trustedTypes.getAttributeType(lcTag, lcName)) {
            case "TrustedHTML":
              value = trustedTypesPolicy.createHTML(value);
              break;
            case "TrustedScriptURL":
              value = trustedTypesPolicy.createScriptURL(value);
              break;
          }
        }
      }
      try {
        if (namespaceURI) {
          currentNode.setAttributeNS(namespaceURI, name, value);
        } else {
          currentNode.setAttribute(name, value);
        }
        arrayPop(DOMPurify2.removed);
      } catch (_2) {
      }
    }
    _executeHook("afterSanitizeAttributes", currentNode, null);
  };
  var _sanitizeShadowDOM = function _sanitizeShadowDOM2(fragment) {
    var shadowNode;
    var shadowIterator = _createIterator(fragment);
    _executeHook("beforeSanitizeShadowDOM", fragment, null);
    while (shadowNode = shadowIterator.nextNode()) {
      _executeHook("uponSanitizeShadowNode", shadowNode, null);
      if (_sanitizeElements(shadowNode)) {
        continue;
      }
      if (shadowNode.content instanceof DocumentFragment) {
        _sanitizeShadowDOM2(shadowNode.content);
      }
      _sanitizeAttributes(shadowNode);
    }
    _executeHook("afterSanitizeShadowDOM", fragment, null);
  };
  DOMPurify2.sanitize = function(dirty) {
    var cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var body;
    var importedNode;
    var currentNode;
    var oldNode;
    var returnNode;
    IS_EMPTY_INPUT = !dirty;
    if (IS_EMPTY_INPUT) {
      dirty = "<!-->";
    }
    if (typeof dirty !== "string" && !_isNode(dirty)) {
      if (typeof dirty.toString !== "function") {
        throw typeErrorCreate("toString is not a function");
      } else {
        dirty = dirty.toString();
        if (typeof dirty !== "string") {
          throw typeErrorCreate("dirty is not a string, aborting");
        }
      }
    }
    if (!DOMPurify2.isSupported) {
      if (_typeof(window2.toStaticHTML) === "object" || typeof window2.toStaticHTML === "function") {
        if (typeof dirty === "string") {
          return window2.toStaticHTML(dirty);
        }
        if (_isNode(dirty)) {
          return window2.toStaticHTML(dirty.outerHTML);
        }
      }
      return dirty;
    }
    if (!SET_CONFIG) {
      _parseConfig(cfg);
    }
    DOMPurify2.removed = [];
    if (typeof dirty === "string") {
      IN_PLACE = false;
    }
    if (IN_PLACE) {
      if (dirty.nodeName) {
        var tagName = transformCaseFunc(dirty.nodeName);
        if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
          throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
        }
      }
    } else if (dirty instanceof Node) {
      body = _initDocument("<!---->");
      importedNode = body.ownerDocument.importNode(dirty, true);
      if (importedNode.nodeType === 1 && importedNode.nodeName === "BODY") {
        body = importedNode;
      } else if (importedNode.nodeName === "HTML") {
        body = importedNode;
      } else {
        body.appendChild(importedNode);
      }
    } else {
      if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && dirty.indexOf("<") === -1) {
        return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(dirty) : dirty;
      }
      body = _initDocument(dirty);
      if (!body) {
        return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
      }
    }
    if (body && FORCE_BODY) {
      _forceRemove(body.firstChild);
    }
    var nodeIterator = _createIterator(IN_PLACE ? dirty : body);
    while (currentNode = nodeIterator.nextNode()) {
      if (currentNode.nodeType === 3 && currentNode === oldNode) {
        continue;
      }
      if (_sanitizeElements(currentNode)) {
        continue;
      }
      if (currentNode.content instanceof DocumentFragment) {
        _sanitizeShadowDOM(currentNode.content);
      }
      _sanitizeAttributes(currentNode);
      oldNode = currentNode;
    }
    oldNode = null;
    if (IN_PLACE) {
      return dirty;
    }
    if (RETURN_DOM) {
      if (RETURN_DOM_FRAGMENT) {
        returnNode = createDocumentFragment.call(body.ownerDocument);
        while (body.firstChild) {
          returnNode.appendChild(body.firstChild);
        }
      } else {
        returnNode = body;
      }
      if (ALLOWED_ATTR.shadowroot) {
        returnNode = importNode.call(originalDocument, returnNode, true);
      }
      return returnNode;
    }
    var serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
    if (WHOLE_DOCUMENT && ALLOWED_TAGS["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
      serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
    }
    if (SAFE_FOR_TEMPLATES) {
      serializedHTML = stringReplace(serializedHTML, MUSTACHE_EXPR$1, " ");
      serializedHTML = stringReplace(serializedHTML, ERB_EXPR$1, " ");
    }
    return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(serializedHTML) : serializedHTML;
  };
  DOMPurify2.setConfig = function(cfg) {
    _parseConfig(cfg);
    SET_CONFIG = true;
  };
  DOMPurify2.clearConfig = function() {
    CONFIG = null;
    SET_CONFIG = false;
  };
  DOMPurify2.isValidAttribute = function(tag, attr, value) {
    if (!CONFIG) {
      _parseConfig({});
    }
    var lcTag = transformCaseFunc(tag);
    var lcName = transformCaseFunc(attr);
    return _isValidAttribute(lcTag, lcName, value);
  };
  DOMPurify2.addHook = function(entryPoint, hookFunction) {
    if (typeof hookFunction !== "function") {
      return;
    }
    hooks[entryPoint] = hooks[entryPoint] || [];
    arrayPush(hooks[entryPoint], hookFunction);
  };
  DOMPurify2.removeHook = function(entryPoint) {
    if (hooks[entryPoint]) {
      return arrayPop(hooks[entryPoint]);
    }
  };
  DOMPurify2.removeHooks = function(entryPoint) {
    if (hooks[entryPoint]) {
      hooks[entryPoint] = [];
    }
  };
  DOMPurify2.removeAllHooks = function() {
    hooks = {};
  };
  return DOMPurify2;
}
var purify = createDOMPurify();
function initialParams(fn) {
  return function(...args) {
    var callback = args.pop();
    return fn.call(this, args, callback);
  };
}
var hasQueueMicrotask = typeof queueMicrotask === "function" && queueMicrotask;
var hasSetImmediate = typeof setImmediate === "function" && setImmediate;
var hasNextTick = typeof process === "object" && typeof process.nextTick === "function";
function fallback(fn) {
  setTimeout(fn, 0);
}
function wrap(defer) {
  return (fn, ...args) => defer(() => fn(...args));
}
var _defer;
if (hasQueueMicrotask) {
  _defer = queueMicrotask;
} else if (hasSetImmediate) {
  _defer = setImmediate;
} else if (hasNextTick) {
  _defer = process.nextTick;
} else {
  _defer = fallback;
}
var setImmediate$1 = wrap(_defer);
function asyncify(func) {
  if (isAsync(func)) {
    return function(...args) {
      const callback = args.pop();
      const promise = func.apply(this, args);
      return handlePromise(promise, callback);
    };
  }
  return initialParams(function(args, callback) {
    var result;
    try {
      result = func.apply(this, args);
    } catch (e2) {
      return callback(e2);
    }
    if (result && typeof result.then === "function") {
      return handlePromise(result, callback);
    } else {
      callback(null, result);
    }
  });
}
function handlePromise(promise, callback) {
  return promise.then((value) => {
    invokeCallback(callback, null, value);
  }, (err) => {
    invokeCallback(callback, err && err.message ? err : new Error(err));
  });
}
function invokeCallback(callback, error, value) {
  try {
    callback(error, value);
  } catch (err) {
    setImmediate$1((e2) => {
      throw e2;
    }, err);
  }
}
function isAsync(fn) {
  return fn[Symbol.toStringTag] === "AsyncFunction";
}
function isAsyncGenerator(fn) {
  return fn[Symbol.toStringTag] === "AsyncGenerator";
}
function isAsyncIterable(obj) {
  return typeof obj[Symbol.asyncIterator] === "function";
}
function wrapAsync(asyncFn) {
  if (typeof asyncFn !== "function")
    throw new Error("expected a function");
  return isAsync(asyncFn) ? asyncify(asyncFn) : asyncFn;
}
function _asyncMap(eachfn, arr, iteratee, callback) {
  arr = arr || [];
  var results = [];
  var counter = 0;
  var _iteratee = wrapAsync(iteratee);
  return eachfn(arr, (value, _2, iterCb) => {
    var index = counter++;
    _iteratee(value, (err, v) => {
      results[index] = v;
      iterCb(err);
    });
  }, (err) => {
    callback(err, results);
  });
}
function isArrayLike(value) {
  return value && typeof value.length === "number" && value.length >= 0 && value.length % 1 === 0;
}
const breakLoop = {};
var breakLoop$1 = breakLoop;
function once(fn) {
  function wrapper(...args) {
    if (fn === null)
      return;
    var callFn = fn;
    fn = null;
    callFn.apply(this, args);
  }
  Object.assign(wrapper, fn);
  return wrapper;
}
function getIterator(coll) {
  return coll[Symbol.iterator] && coll[Symbol.iterator]();
}
function createArrayIterator(coll) {
  var i2 = -1;
  var len = coll.length;
  return function next() {
    return ++i2 < len ? { value: coll[i2], key: i2 } : null;
  };
}
function createES2015Iterator(iterator) {
  var i2 = -1;
  return function next() {
    var item = iterator.next();
    if (item.done)
      return null;
    i2++;
    return { value: item.value, key: i2 };
  };
}
function createObjectIterator(obj) {
  var okeys = obj ? Object.keys(obj) : [];
  var i2 = -1;
  var len = okeys.length;
  return function next() {
    var key = okeys[++i2];
    if (key === "__proto__") {
      return next();
    }
    return i2 < len ? { value: obj[key], key } : null;
  };
}
function createIterator(coll) {
  if (isArrayLike(coll)) {
    return createArrayIterator(coll);
  }
  var iterator = getIterator(coll);
  return iterator ? createES2015Iterator(iterator) : createObjectIterator(coll);
}
function onlyOnce(fn) {
  return function(...args) {
    if (fn === null)
      throw new Error("Callback was already called.");
    var callFn = fn;
    fn = null;
    callFn.apply(this, args);
  };
}
function asyncEachOfLimit(generator, limit, iteratee, callback) {
  let done = false;
  let canceled = false;
  let awaiting = false;
  let running = 0;
  let idx = 0;
  function replenish() {
    if (running >= limit || awaiting || done)
      return;
    awaiting = true;
    generator.next().then(({ value, done: iterDone }) => {
      if (canceled || done)
        return;
      awaiting = false;
      if (iterDone) {
        done = true;
        if (running <= 0) {
          callback(null);
        }
        return;
      }
      running++;
      iteratee(value, idx, iterateeCallback);
      idx++;
      replenish();
    }).catch(handleError);
  }
  function iterateeCallback(err, result) {
    running -= 1;
    if (canceled)
      return;
    if (err)
      return handleError(err);
    if (err === false) {
      done = true;
      canceled = true;
      return;
    }
    if (result === breakLoop$1 || done && running <= 0) {
      done = true;
      return callback(null);
    }
    replenish();
  }
  function handleError(err) {
    if (canceled)
      return;
    awaiting = false;
    done = true;
    callback(err);
  }
  replenish();
}
var eachOfLimit$2 = (limit) => {
  return (obj, iteratee, callback) => {
    callback = once(callback);
    if (limit <= 0) {
      throw new RangeError("concurrency limit cannot be less than 1");
    }
    if (!obj) {
      return callback(null);
    }
    if (isAsyncGenerator(obj)) {
      return asyncEachOfLimit(obj, limit, iteratee, callback);
    }
    if (isAsyncIterable(obj)) {
      return asyncEachOfLimit(obj[Symbol.asyncIterator](), limit, iteratee, callback);
    }
    var nextElem = createIterator(obj);
    var done = false;
    var canceled = false;
    var running = 0;
    var looping = false;
    function iterateeCallback(err, value) {
      if (canceled)
        return;
      running -= 1;
      if (err) {
        done = true;
        callback(err);
      } else if (err === false) {
        done = true;
        canceled = true;
      } else if (value === breakLoop$1 || done && running <= 0) {
        done = true;
        return callback(null);
      } else if (!looping) {
        replenish();
      }
    }
    function replenish() {
      looping = true;
      while (running < limit && !done) {
        var elem = nextElem();
        if (elem === null) {
          done = true;
          if (running <= 0) {
            callback(null);
          }
          return;
        }
        running += 1;
        iteratee(elem.value, elem.key, onlyOnce(iterateeCallback));
      }
      looping = false;
    }
    replenish();
  };
};
function awaitify(asyncFn, arity = asyncFn.length) {
  if (!arity)
    throw new Error("arity is undefined");
  function awaitable(...args) {
    if (typeof args[arity - 1] === "function") {
      return asyncFn.apply(this, args);
    }
    return new Promise((resolve, reject) => {
      args[arity - 1] = (err, ...cbArgs) => {
        if (err)
          return reject(err);
        resolve(cbArgs.length > 1 ? cbArgs : cbArgs[0]);
      };
      asyncFn.apply(this, args);
    });
  }
  return awaitable;
}
function eachOfLimit(coll, limit, iteratee, callback) {
  return eachOfLimit$2(limit)(coll, wrapAsync(iteratee), callback);
}
var eachOfLimit$1 = awaitify(eachOfLimit, 4);
function eachOfArrayLike(coll, iteratee, callback) {
  callback = once(callback);
  var index = 0, completed = 0, { length } = coll, canceled = false;
  if (length === 0) {
    callback(null);
  }
  function iteratorCallback(err, value) {
    if (err === false) {
      canceled = true;
    }
    if (canceled === true)
      return;
    if (err) {
      callback(err);
    } else if (++completed === length || value === breakLoop$1) {
      callback(null);
    }
  }
  for (; index < length; index++) {
    iteratee(coll[index], index, onlyOnce(iteratorCallback));
  }
}
function eachOfGeneric(coll, iteratee, callback) {
  return eachOfLimit$1(coll, Infinity, iteratee, callback);
}
function eachOf(coll, iteratee, callback) {
  var eachOfImplementation = isArrayLike(coll) ? eachOfArrayLike : eachOfGeneric;
  return eachOfImplementation(coll, wrapAsync(iteratee), callback);
}
var eachOf$1 = awaitify(eachOf, 3);
function map(coll, iteratee, callback) {
  return _asyncMap(eachOf$1, coll, iteratee, callback);
}
var map$1 = awaitify(map, 3);
function mapLimit(coll, limit, iteratee, callback) {
  return _asyncMap(eachOfLimit$2(limit), coll, iteratee, callback);
}
var mapLimit$1 = awaitify(mapLimit, 4);
function waterfall$1(tasks, callback) {
  callback = once(callback);
  if (!Array.isArray(tasks))
    return callback(new Error("First argument to waterfall must be an array of functions"));
  if (!tasks.length)
    return callback();
  var taskIndex = 0;
  function nextTask(args) {
    var task = wrapAsync(tasks[taskIndex++]);
    task(...args, onlyOnce(next));
  }
  function next(err, ...args) {
    if (err === false)
      return;
    if (err || taskIndex === tasks.length) {
      return callback(err, ...args);
    }
    nextTask(args);
  }
  nextTask([]);
}
var waterfall$2 = awaitify(waterfall$1);
const _hoisted_1$h = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$g = /* @__PURE__ */ createBaseVNode("g", {
  fill: "none",
  stroke: "currentColor",
  "stroke-width": "2"
}, [
  /* @__PURE__ */ createBaseVNode("path", { d: "M21 12a9 9 0 1 1-18 0a9 9 0 0 1 18 0Z" }),
  /* @__PURE__ */ createBaseVNode("path", {
    "stroke-linecap": "round",
    d: "m9 15l6-6m0 6L9 9"
  })
], -1);
const _hoisted_3$g = [
  _hoisted_2$g
];
function render$9(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$h, _hoisted_3$g);
}
var __unplugin_components_0$5 = { name: "humbleicons-times-circle", render: render$9 };
var contOverlay_vue_vue_type_style_index_0_lang = "";
const _sfc_main$8 = {
  name: "overlay",
  data() {
    return {
      showLogo: false,
      imageSources: {
        logo: chrome.runtime.getURL(
          "assets/images/audible-library-extractor-logo.svg"
        )
      }
    };
  },
  mounted: function() {
    this.showLogo = true;
    document.querySelector("html").classList.add("ale-overlay-open");
  },
  methods: {
    closeOverlay: function() {
      window.location.reload();
    }
  }
};
const _hoisted_1$g = { id: "audible-library-extractor" };
const _hoisted_2$f = { class: "inner-wrap" };
const _hoisted_3$f = ["src"];
function _sfc_render$8(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_humbleicons_times_circle = __unplugin_components_0$5;
  return openBlock(), createElementBlock("div", _hoisted_1$g, [
    createBaseVNode("div", _hoisted_2$f, [
      createBaseVNode("div", {
        class: "close-btn",
        onClick: _cache[0] || (_cache[0] = ($event) => $options.closeOverlay())
      }, [
        createVNode(_component_humbleicons_times_circle)
      ]),
      createBaseVNode("div", {
        id: "the-adbl-logo",
        class: normalizeClass({ "fade-in-fwd": $data.showLogo })
      }, [
        createBaseVNode("img", {
          src: $data.imageSources.logo,
          alt: ""
        }, null, 8, _hoisted_3$f)
      ], 2),
      renderSlot(_ctx.$slots, "default")
    ])
  ]);
}
var __unplugin_components_2$3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8]]);
var bulma_css_vue_type_style_index_0_src_5acf5ddb_scoped_true_lang = "";
var contScrapingProgress_vue_vue_type_style_index_1_scoped_true_lang = "";
const _sfc_main$7 = {
  name: "scrapingProgress",
  props: ["domainExtension"],
  data() {
    return {
      store: this.$store.state,
      imageSources: {
        logo: chrome.runtime.getURL("assets/images/audible-library-extractor-logo.svg"),
        loader: chrome.runtime.getURL("assets/images/loader-64px.gif")
      }
    };
  },
  computed: {
    steps: function() {
      return this.store.progress.step > 0 ? this.store.progress.step + " / " + this.store.progress.max : this.store.progress.max;
    },
    bigSteps: function() {
      return this.store.bigStep.step > 0 ? this.store.bigStep.step + " / " + this.store.bigStep.max : this.store.bigStep.max;
    },
    subSteps: function() {
      return this.store.subStep.step > 0 ? this.store.subStep.step + " / " + this.store.subStep.max : this.store.subStep.max;
    },
    progressWidth: function() {
      return { width: this.store.progress.step / this.store.progress.max * 100 + "%" };
    }
  },
  methods: {
    wishlistLinkClicked(e2) {
      this.$store.commit("update", { key: "sticky.openOnLoad", value: true });
      chrome.runtime.sendMessage({ action: "refresh", url: window.location.origin + window.location.pathname });
      chrome.runtime.sendMessage({ action: "newPage", url: e2.target.href });
    }
  }
};
const _withScopeId$3 = (n) => (pushScopeId("data-v-5acf5ddb"), n = n(), popScopeId(), n);
const _hoisted_1$f = { key: 0 };
const _hoisted_2$e = /* @__PURE__ */ _withScopeId$3(() => /* @__PURE__ */ createBaseVNode("div", { class: "progress-wrapper" }, [
  /* @__PURE__ */ createBaseVNode("progress", {
    class: "progress is-warning is-large",
    max: "100",
    style: { "min-width": "288px" }
  }, "75%"),
  /* @__PURE__ */ createBaseVNode("small", { style: { "font-size": "12px" } }, "Checking for wishlist access...")
], -1));
const _hoisted_3$e = [
  _hoisted_2$e
];
const _hoisted_4$4 = { key: 1 };
const _hoisted_5$3 = { class: "message is-warning wishlist-login-wrapper" };
const _hoisted_6$3 = { class: "message-body" };
const _hoisted_7$2 = /* @__PURE__ */ createTextVNode(" Try to open your ");
const _hoisted_8$2 = ["href"];
const _hoisted_9$1 = /* @__PURE__ */ createTextVNode(" and login when asked. ");
const _hoisted_10$1 = /* @__PURE__ */ _withScopeId$3(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_11$1 = /* @__PURE__ */ createTextVNode(" After that try to redo the extraction. ");
const _hoisted_12$1 = /* @__PURE__ */ _withScopeId$3(() => /* @__PURE__ */ createBaseVNode("strong", null, "The link will open in a new tab!", -1));
const _hoisted_13$1 = {
  key: 2,
  id: "ale-progress-wrap"
};
const _hoisted_14$1 = { class: "loader-image" };
const _hoisted_15$1 = ["src"];
const _hoisted_16$1 = {
  key: 0,
  class: "step"
};
const _hoisted_17$1 = { class: "ale-progress" };
const _hoisted_18$1 = { class: "ale-step-text" };
const _hoisted_19$1 = { class: "ale-step-additional-info" };
const _hoisted_20$1 = { style: { "text-align": "center", "margin-top": "20px", "height": "110px" } };
const _hoisted_21$1 = ["src"];
const _hoisted_22$1 = /* @__PURE__ */ _withScopeId$3(() => /* @__PURE__ */ createBaseVNode("div", { class: "footnote" }, " Keep this tab and the browser window on top until the extraction is completed. ", -1));
function _sfc_render$7(_ctx, _cache, $props, $setup, $data, $options) {
  const _directive_visible = resolveDirective("visible");
  return _ctx.$store.state.checkingWishlistAccess ? (openBlock(), createElementBlock("div", _hoisted_1$f, _hoisted_3$e)) : _ctx.$store.state.noWishlistAccess ? (openBlock(), createElementBlock("div", _hoisted_4$4, [
    createBaseVNode("article", _hoisted_5$3, [
      createBaseVNode("div", _hoisted_6$3, [
        _hoisted_7$2,
        createBaseVNode("a", {
          onClick: _cache[0] || (_cache[0] = withModifiers((...args) => $options.wishlistLinkClicked && $options.wishlistLinkClicked(...args), ["prevent"])),
          target: "_blank",
          rel: "noopener noreferrer",
          href: "https://audible" + $props.domainExtension + "/wishlist"
        }, "audible" + toDisplayString($props.domainExtension) + "/wishlist", 9, _hoisted_8$2),
        _hoisted_9$1,
        _hoisted_10$1,
        _hoisted_11$1,
        _hoisted_12$1
      ])
    ])
  ])) : (openBlock(), createElementBlock("div", _hoisted_13$1, [
    createVNode(Transition, { name: "fade" }, {
      default: withCtx(() => [
        createBaseVNode("div", _hoisted_14$1, [
          createBaseVNode("img", {
            height: "72",
            src: $data.imageSources.loader,
            alt: ""
          }, null, 8, _hoisted_15$1)
        ])
      ]),
      _: 1
    }),
    $data.store.bigStep.title ? (openBlock(), createElementBlock("div", {
      key: 0,
      class: normalizeClass(["ale-big-step", { "sub-step-exists": $data.store.subStep.max > 0 }])
    }, [
      createBaseVNode("h2", null, [
        createTextVNode(toDisplayString($data.store.bigStep.title) + "\xA0 ", 1),
        $data.store.subStep.max > 0 ? (openBlock(), createElementBlock("small", _hoisted_16$1, "(" + toDisplayString($options.subSteps) + ")", 1)) : createCommentVNode("", true)
      ])
    ], 2)) : createCommentVNode("", true),
    withDirectives((openBlock(), createElementBlock("div", _hoisted_17$1, [
      createBaseVNode("div", null, [
        createBaseVNode("div", _hoisted_18$1, [
          withDirectives((openBlock(), createElementBlock("div", _hoisted_19$1, [
            createTextVNode(toDisplayString($data.store.progress.text2), 1)
          ])), [
            [_directive_visible, $data.store.progress.text2]
          ]),
          createTextVNode(" " + toDisplayString($data.store.progress.text) + " ", 1),
          $options.steps ? (openBlock(), createBlock(Transition, {
            key: 0,
            name: "fade"
          }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString($options.steps), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true),
          createTextVNode(" " + toDisplayString($data.store.progress.textsuffix), 1)
        ])
      ])
    ])), [
      [_directive_visible, $data.store.progress.text]
    ]),
    withDirectives((openBlock(), createElementBlock("div", {
      class: normalizeClass(["ale-bar", { "scale-in-hor-center": $data.store.progress.bar }])
    }, [
      createBaseVNode("div", {
        class: "ale-step-line",
        style: normalizeStyle($options.progressWidth)
      }, null, 4)
    ], 2)), [
      [_directive_visible, $data.store.progress.bar && $data.store.progress.step && $data.store.progress.max]
    ]),
    withDirectives(createBaseVNode("div", _hoisted_20$1, [
      createBaseVNode("img", {
        src: $data.store.progress.thumbnail,
        alt: "",
        style: { "max-height": "110px" }
      }, null, 8, _hoisted_21$1)
    ], 512), [
      [vShow, $data.store.progress.thumbnail]
    ]),
    _hoisted_22$1
  ]));
}
var __unplugin_components_1$3 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7], ["__scopeId", "data-v-5acf5ddb"]]);
const _hoisted_1$e = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$d = /* @__PURE__ */ createBaseVNode("g", { fill: "currentColor" }, [
  /* @__PURE__ */ createBaseVNode("path", {
    "fill-rule": "evenodd",
    d: "M12 19a7 7 0 1 0 0-14a7 7 0 0 0 0 14Zm0 3c5.523 0 10-4.477 10-10S17.523 2 12 2S2 6.477 2 12s4.477 10 10 10Z",
    "clip-rule": "evenodd",
    opacity: ".2"
  }),
  /* @__PURE__ */ createBaseVNode("path", { d: "M2 12C2 6.477 6.477 2 12 2v3a7 7 0 0 0-7 7H2Z" })
], -1);
const _hoisted_3$d = [
  _hoisted_2$d
];
function render$8(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$e, _hoisted_3$d);
}
var __unplugin_components_4 = { name: "gg-spinner", render: render$8 };
const _hoisted_1$d = {
  viewBox: "0 0 256 256",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$c = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M71.7 97.2L34.8 128l36.9 30.8a12 12 0 1 1-15.4 18.4l-48-40a12 12 0 0 1 0-18.4l48-40a12 12 0 0 1 15.4 18.4Zm176 21.6l-48-40a12 12 0 0 0-15.4 18.4l37 30.8l-37 30.8a11.9 11.9 0 0 0-1.5 16.9a12.2 12.2 0 0 0 9.2 4.3a12 12 0 0 0 7.7-2.8l48-40a12 12 0 0 0 0-18.4Zm-83.6-90.1a12.1 12.1 0 0 0-15.4 7.2l-64 176a12.1 12.1 0 0 0 7.2 15.4a11.8 11.8 0 0 0 4.1.7a12 12 0 0 0 11.3-7.9l64-176a12.1 12.1 0 0 0-7.2-15.4Z"
}, null, -1);
const _hoisted_3$c = [
  _hoisted_2$c
];
function render$7(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$d, _hoisted_3$c);
}
var __unplugin_components_0$4 = { name: "ph-code-bold", render: render$7 };
let githubIssues = "https://github.com/joonaspaakko/audible-library-extractor/issues/";
var changelog = {
  data: function() {
    return {
      changeLog: [
        {
          version: "v.0.2.9",
          highlights: `Full extraction recommended.`,
          changes: [
            {
              description: `Up to this version the extension used to add global CSS styling that slightly modified the CSS in the library. It added very small unnoticable changes, like shifting text a little bit, but now it's fixed.`,
              class: "fixed"
            }
          ]
        },
        {
          version: "v.0.2.8",
          highlights: `The "Audible Library Extractor" button in Audible's website now looks like a button and was moved above the search input, because Audible continually made small changes and it could no longer fit where it used to be.`,
          changes: [
            {
              description: `Extraction comes up with 20 books (single page). Note: audible changed things`,
              class: "fixed",
              link: { text: "Fixed #72", href: githubIssues + "72" }
            },
            {
              description: `Wishlist extraction discards all data and the wishlist gallery page comes up empty. Note: audible changed things`,
              class: "fixed",
              link: { text: "Fixed #71", href: githubIssues + "71" }
            },
            {
              description: `Wallpaper creator showing a blank page (if used hadn't extracted collections).`,
              class: "fixed",
              link: { text: "Fixed #69", href: githubIssues + "69" }
            },
            {
              description: `Some "unavailable" books not marked properly. Note: this bug was introduced in v.0.2.7`,
              class: "fixed",
              link: { text: "Fixed #68", href: githubIssues + "68" }
            },
            {
              description: `Top menu disappears sometimes on certain pages bug`,
              class: "fixed",
              link: { text: "Fixed #67", href: githubIssues + "67" }
            }
          ]
        },
        {
          version: "v.0.2.7",
          highlights: `
            You should do a full extraction after updating to this version. There are a a few new data points that the partial extraction will not update to any old books.
            <br><br>
            I added global context menu items so you can easily open the gallery by right-clicking anywhere inside any tab and choose "Audible Library Extracor > Gallery page".
            <br><br>
            There's now a wallpaper creator in the extension gallery. Look for it in the top menu.
          `,
          changes: [
            {
              description: `Added import and export for raw data. Data is stored in your browser, but if you for example get a new computer you could export data on your current computer and import it on the new one and you don't have to do a full extraction.`,
              class: "added"
            },
            {
              description: `Added dropdown list type filters, which allow you to filter books by properties like the language or format etc...`,
              class: "added"
            },
            {
              description: `You can now collapse & expand book cover and information in the book details view.`,
              class: "improved"
            },
            {
              description: `"My books in the library" list now shows you if any books you don't own are available in the Plus Catalog. Also you can now open book links to a new tab, which wasn't possible before. `,
              class: "improved"
            },
            {
              description: "Added genre / theme tags. These are little pill shaped text btns you see below the summary on some store pages.",
              class: "added"
            },
            {
              description: "Added better Archive handling. Filters and sorting for archived books. Standalone gallery now has an option to exclude archived books / archived collection.",
              class: "added"
            },
            {
              description: "Added whispersync data: 1. Color dot on the covers if you own the Kindle version. 2. Whispersync filters 3. Whispersync sorters 4. Whispersync label inside the book details view",
              class: "added"
            },
            {
              link: { text: "Fixed #66", href: githubIssues + "66" },
              description: "Extraction can not complete: Cannot read properties of null (reading 'getAttribute').",
              class: "fixed"
            },
            {
              link: { text: "Added #62", href: githubIssues + "62" },
              description: "Image editor (wallpaper generator).",
              class: "added"
            },
            {
              link: { text: "Fixed #60", href: githubIssues + "60" },
              description: '"Audible Library Extractor" text button is cut off in Audible library page.',
              class: "fixed"
            },
            {
              link: { text: "Fixed #56", href: githubIssues + "56" },
              description: "Wishlist extraction stops right when it's about to start.",
              class: "fixed"
            },
            {
              link: { text: "Fixed #54", href: githubIssues + "54" },
              description: "Partial library update doesn't merge old series data with new series data properly.",
              class: "fixed"
            },
            {
              link: { text: "Fixed #50", href: githubIssues + "50" },
              description: "Collections larger than 20 titles are not getting extracted properly.",
              class: "fixed"
            },
            {
              link: { text: "Fixed #49", href: githubIssues + "49" },
              description: "Sub pages don't show up in the the stand-alone gallery if you saved it with wishlist and any sub pages while excluding library.",
              class: "fixed"
            },
            {
              link: { text: "Fixed #48", href: githubIssues + "48" },
              description: "My books in the series list: links lead to empty pages inside the gallery (sometimes). Related to sub page source.",
              class: "fixed"
            },
            {
              link: { text: "Improved #47", href: githubIssues + "47" },
              description: "Merged the library data update button with the full extraction button. Now wishlist has a partial extraction too!",
              class: "improved"
            },
            {
              link: { text: "Fixed #46", href: githubIssues + "46" },
              description: "After opening a link to the gallery on a page with book details open, the next chunk of books would not load when scrolling far enough down.",
              class: "fixed"
            }
          ]
        },
        {
          version: "v.0.2.6",
          highlights: "If you want to filter wishlist by Plus Catalog titles, you'll have to extract the <strong>wishlist</strong> again. The 'My books in the series' list can now show all books in the series, but this too requires a full extraction of the <strong>library</strong>. <br><br>Performance improvement <a href='https://github.com/joonaspaakko/audible-library-extractor/issues/41'>#41</a> changes the way the books are loaded in: they are loaded in chunks as you scroll down. This unfortunately makes it so you can't just jump to the beginning of your library at the bottom like you could before. If you must, you can get around this: in the address bar you should see a url parameter like this '?y=347'. The number keeps track of how far you're scrolled. Change that to and obnoxiously high number, like '?y=9999999' and press enter or refresh the page and it will load the entire library at once.",
          changes: [
            {
              link: { text: "New documentation", href: "https://joonaspaakko.gitbook.io/audible-library-extractor/" },
              description: '<a href="https://joonaspaakko.gitbook.io/audible-library-extractor/" target="_blank" rel="noopener noreferrer">https://joonaspaakko.gitbook.io/audible-library-extractor/</a>',
              highlight: true,
              class: "info"
            },
            {
              link: { text: "Improved #25", href: githubIssues + "25" },
              description: "Improved filters with range sliders and you can enable multiple filters at the same time",
              highlight: true,
              class: "improved"
            },
            {
              link: { text: "Added #30", href: githubIssues + "30" },
              description: "Stand-alone gallery save options that allow you to exclude pages",
              highlight: true,
              class: "added"
            },
            {
              link: { text: "Added #26", href: githubIssues + "26" },
              description: "CSV export (Importable: goodreads, googlesheets, excel, etc...)",
              highlight: true,
              class: "added"
            },
            {
              link: { text: "Fixed #35", href: githubIssues + "35" },
              description: "Firefox: ISBN+Wishlist extraction stops the entire extraction process",
              highlight: true,
              class: "fixed"
            },
            {
              link: { text: "Added #38", href: githubIssues + "38" },
              description: "Easier way to get back to the gallery (and Audible library) using the extension icon context menu",
              highlight: true,
              class: "added"
            },
            {
              link: { text: "Improved #41", href: githubIssues + "41" },
              description: "Improved gallery performance, especially on slightly older mobile devices.",
              highlight: true,
              class: "improved"
            },
            {
              link: { text: "Fixed #44", href: githubIssues + "44" },
              description: "Certain links to Audible not working due to missing encoding",
              class: "fixed"
            },
            {
              link: { text: "Fixed #43", href: githubIssues + "43" },
              description: "Wishlist series hyperlink doesn't lead anywhere",
              class: "fixed"
            },
            {
              link: { text: "Fixed #42", href: githubIssues + "42" },
              description: "Child category heading shows up in parent category page",
              class: "fixed"
            },
            {
              link: { text: "Fixed #40", href: githubIssues + "40" },
              description: "Missing cover images causing various issues in the gallery (mostly affects long time Audible users)",
              class: "fixed"
            },
            {
              link: { text: "Fixed #37", href: githubIssues + "37" },
              description: "Extension icon active state (color icon) is triggering whenever",
              class: "fixed"
            },
            {
              link: { text: "Fixed #36", href: githubIssues + "36" },
              description: "Release date sorter not working on mobile (ios)",
              class: "fixed"
            },
            {
              link: { text: "Fixed #34", href: githubIssues + "34" },
              description: "Wishlist extraction stops and halts the whole extraction part 2",
              class: "fixed"
            },
            {
              link: { text: "Fixed #33", href: githubIssues + "33" },
              description: "Book details open in the wrong position breaking the grid at certain browser widths",
              class: "fixed"
            },
            {
              link: { text: "Fixed #31", href: githubIssues + "31" },
              description: "Sorting is taken over by search order If you have an active search and then change filters or search scope",
              class: "fixed"
            }
          ]
        },
        {
          version: "v.0.2.5",
          changes: [
            {
              link: { text: "Fixed #28", href: githubIssues + "28" },
              description: "Series/sub page fails to show the right content",
              class: "fixed"
            },
            {
              link: { text: "Fixed #27", href: githubIssues + "27" },
              description: "The Great Courses (books) omitted",
              class: "fixed"
            },
            {
              link: { text: "Fixed #24", href: githubIssues + "24" },
              description: "Search overrides sorting URL parameter on page load",
              class: "fixed"
            },
            {
              link: { text: "Fixed #23", href: githubIssues + "23" },
              description: "Wishlist scraping errored out due to fetching second lvl domain names like \u201C.co.uk\u201D wrong",
              class: "fixed"
            },
            {
              link: { text: "Fixed #22", href: githubIssues + "22" },
              description: "Categories page empty (sometimes)",
              class: "fixed"
            },
            {
              link: { text: "Fixed #21", href: githubIssues + "21" },
              description: "View mode button showing up on pages it shouldn\u2019t",
              class: "fixed"
            },
            {
              link: { text: "Fixed #20", href: githubIssues + "20" },
              description: "Filter and sorter menu disappearing behing the bottom mobile nav",
              class: "fixed"
            },
            {
              link: { text: "Fixed #19", href: githubIssues + "19" },
              description: "Partial library scan breaking series",
              class: "fixed"
            }
          ]
        },
        {
          version: "v.0.2.4",
          changes: [
            { description: "First public beta version" }
          ]
        }
      ]
    };
  }
};
var bulma_css_vue_type_style_index_0_src_01506283_scoped_true_lang = "";
var contChangelog_vue_vue_type_style_index_1_lang = "";
const _sfc_main$6 = {
  mixins: [changelog],
  data: function() {
    return {};
  },
  methods: {
    getChangelog: function() {
      let changelogInnerHTML = "";
      _.each(this.changeLog, function(versionBlock) {
        changelogInnerHTML += '<strong style="display: inline-block; width: 100%; font-size: 16px;">' + versionBlock.version + "</strong>";
        changelogInnerHTML += versionBlock.highlights ? '<div style="padding: 6px; margin: 6px 0 7px; color: rgb(128 93 54); background: rgb(246, 153, 50, .06); border: 1px solid rgb(246, 153, 50, .2);">' + versionBlock.highlights + "</div>" : "";
        changelogInnerHTML += '<ul class="ale-changelog-list" style="display: inline-block; width: 100%; box-sizing: border-box;">';
        _.each(versionBlock.changes, function(change) {
          if (change.divider) {
            changelogInnerHTML += '<li style="height: 0px; border: 1px dashed #f1f1f1; margin: 5px 0; width: 100%;"></li>';
          } else {
            let linkText;
            if (change.link)
              linkText = change.highlight ? "<strong>" + change.link.text + "</strong>" : change.link.text;
            changelogInnerHTML += '<li class="' + (change.class || "") + '">' + (change.link ? '<a target="_blank" rel="noopener noreferrer" href="' + change.link.href + '">' + linkText + "</a>: " : "") + (change.description || "") + "</li>";
          }
        });
        changelogInnerHTML += "</ul>";
        changelogInnerHTML += "<br><br>";
      });
      let changelogHTML = '<div style="text-align: left; max-height: 350px; overflow: scroll; padding: 20px;">' + changelogInnerHTML + "</div>";
      return changelogHTML;
    }
  }
};
const _withScopeId$2 = (n) => (pushScopeId("data-v-01506283"), n = n(), popScopeId(), n);
const _hoisted_1$c = { id: "changelog" };
const _hoisted_2$b = ["content"];
const _hoisted_3$b = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("span", null, "Changelog", -1));
function _sfc_render$6(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_ph_code_bold = __unplugin_components_0$4;
  const _directive_tippy = resolveDirective("tippy");
  return openBlock(), createElementBlock("div", _hoisted_1$c, [
    withDirectives((openBlock(), createElementBlock("button", {
      class: "button is-small is-text settings-btn",
      content: $options.getChangelog()
    }, [
      createVNode(_component_ph_code_bold, { class: "icon" }),
      _hoisted_3$b
    ], 8, _hoisted_2$b)), [
      [_directive_tippy, {
        allowHTML: true,
        trigger: "click",
        interactive: true
      }]
    ])
  ]);
}
var __unplugin_components_3$1 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6], ["__scopeId", "data-v-01506283"]]);
const _hoisted_1$b = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$a = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M10 6v2H5v11h11v-5h2v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6zm11-3v8h-2V6.413l-7.793 7.794l-1.414-1.414L17.585 5H13V3h8z"
}, null, -1);
const _hoisted_3$a = [
  _hoisted_2$a
];
function render$6(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$b, _hoisted_3$a);
}
var __unplugin_components_2$2 = { name: "ri-external-link-line", render: render$6 };
const _hoisted_1$a = {
  viewBox: "0 0 256 256",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$9 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M128 20a108 108 0 1 0 108 108A108.1 108.1 0 0 0 128 20Zm0 192a84 84 0 1 1 84-84a84.1 84.1 0 0 1-84 84Zm48.5-92.5a12 12 0 0 1 0 17l-34 33.9a12 12 0 0 1-16.9 0a11.9 11.9 0 0 1 0-16.9L139 140H88a12 12 0 0 1 0-24h51l-13.4-13.5a12 12 0 0 1 16.9-16.9Z"
}, null, -1);
const _hoisted_3$9 = [
  _hoisted_2$9
];
function render$5(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$a, _hoisted_3$9);
}
var __unplugin_components_1$2 = { name: "ph-arrow-circle-right-bold", render: render$5 };
var bulma_css_vue_type_style_index_0_src_a4521cec_scoped_true_lang = "";
const _sfc_main$5 = {
  mixins: [helpers],
  data: function() {
    const vue = this;
    const store2 = this.$store.state;
    return {
      store: this.$store.state,
      exportRawDataDisabled: false,
      actions: [
        { key: "unselect all" },
        { key: "select all" },
        { key: "reset new books", disabled: function() {
          return !store2.storageHasData.books;
        }, tippy: '<strong>Removes the status &#34;new&#34; from all extracted books.</strong> <br><br>During a partial library or wishlist extraction newly added books are marked and you can filter and sort based on that status in the gallery. <br><br><div style="color: #f14668;">The new status is only ever reset automatically when you clear library data or press this button.</div>' },
        { key: "export raw data", disabled: function() {
          return !vue.rawDataExport;
        } },
        { key: "import raw data", inputEvent: true },
        { key: "remove all extracted data", extraClasses: "delete-btn" }
      ]
    };
  },
  computed: {
    rawDataExport() {
      return !this.exportRawDataDisabled && this.$store.getters.mainDataExists;
    }
  },
  methods: {
    clickEvent(action, e2) {
      const method = _.camelCase(action.key);
      this[method](e2);
    },
    unselectAll: function() {
      const vue = this;
      _.each(this.$store.getters.settings_mainSteps, function(setting, index) {
        vue.$store.commit("updateSetting", { item: setting, obj: { value: false, disabled: false } });
      });
      this.$store.commit("update", { key: "extractionButtonDisabled", value: true });
    },
    selectAll: function() {
      const vue = this;
      _.each(this.$store.getters.settings_mainSteps, function(setting) {
        vue.$store.commit("updateSetting", { item: setting, obj: { value: true, disabled: setting.name === "books" } });
      });
      this.$store.commit("update", { key: "extractionButtonDisabled", value: false });
    },
    resetNewBooks: function() {
      let confirmation = window.confirm("Are you sure you want to clear new book status?");
      if (confirmation) {
        let vue = this;
        let errorNotification = function() {
          vue.loading = false;
          vue.$toast.error({
            duration: 4e3,
            message: 'Failed to remove "new" status from books',
            type: "is-danger",
            position: "is-top",
            closable: false
          });
        };
        chrome.storage.local.get(null).then((data) => {
          _.each(_.range(0, data["books-chunk-length"]), function(index) {
            let booksChunk = data["books-chunk-" + index];
            _.each(booksChunk, function(book) {
              if (book.isNew)
                delete book.isNew;
            });
          });
          _.each(_.range(0, data["wishlist-chunk-length"]), function(index) {
            let wishlistChunk = data["wishlist-chunk-" + index];
            _.each(wishlistChunk, function(book) {
              if (book.isNew)
                delete book.isNew;
            });
          });
          chrome.storage.local.clear().then(() => {
            chrome.storage.local.set(data).then(() => {
              vue.$toast.success('All "new" books succesfully reset', vue.store.toastOpts);
            }).catch(errorNotification);
          }).catch(errorNotification);
        }).catch(errorNotification);
      }
    },
    exportRawData: function() {
      let vue = this;
      vue.exportRawDataDisabled = true;
      chrome.storage.local.get(null).then((data) => {
        if (data.chunks)
          vue.glueFriesBackTogether(data);
        delete data.imageEditorPageTitle;
        delete data.imageEditorPageSubTitle;
        delete data.imageEditorTimeCode;
        delete data.imageEditorChunksLength;
        delete data.imageEditorChunks;
        FileSaver_min.exports.saveAs(new Blob([JSON.stringify(data)], { type: "application/json;charset=utf-8" }), "Audible Library Extractor Data.json");
        vue.exportRawDataDisabled = false;
        vue.$toast.success("Data exported succesfully!", vue.store.toastOpts);
      }).catch(function(err) {
        vue.exportRawDataDisabled = false;
        vue.$toast.error("Data export failed. Reload the page and try again.", vue.store.toastOpts);
      });
    },
    importRawData: function(e2) {
      let vue = this;
      let file = e2.target.files;
      if (file)
        file = file[0];
      e2.target.value = null;
      if (file) {
        vue.loading = true;
        let errorNotification = function(e3) {
          vue.loading = false;
          vue.$toast.error("Data import failed: " + e3, vue.store.toastOpts);
        };
        let read = new FileReader();
        read.onload = function(e3) {
          let data = JSON.parse(e3.target.result);
          vue.makeFrenchFries(data);
          chrome.storage.local.clear().then(() => {
            chrome.storage.local.set(data).then(function() {
              vue.$toast.success("Data imported succesfully!", vue.store.toastOpts);
              vue.loading = false;
              vue.$dataChecker(data);
            }).catch(errorNotification);
          }).catch(errorNotification);
        };
        read.onerror = errorNotification;
        read.readAsText(file);
      }
    },
    removeAllExtractedData: function() {
      let vue = this;
      let confirmation = window.confirm("Are you sure you want to remove all extracted data?");
      if (confirmation) {
        let errorNotification = function(e2) {
          vue.loading = false;
          vue.$toast.error("Data clear failed: " + e2, vue.store.toastOpts);
        };
        chrome.storage.local.clear().then(function() {
          chrome.storage.local.get(null).then((data) => {
            vue.$dataChecker(data);
            vue.$toast.success("Data removed succesfully", vue.store.toastOpts);
          }).catch(errorNotification);
        }).catch(errorNotification);
      }
    }
  }
};
const _hoisted_1$9 = { class: "description" };
const _hoisted_2$8 = { class: "linky-links" };
const _hoisted_3$8 = ["onClick", "content", "disabled"];
const _hoisted_4$3 = ["onChange"];
function _sfc_render$5(_ctx, _cache, $props, $setup, $data, $options) {
  const _directive_tippy = resolveDirective("tippy");
  return openBlock(), createElementBlock("div", _hoisted_1$9, [
    createBaseVNode("div", _hoisted_2$8, [
      createBaseVNode("div", null, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.actions, (action) => {
          return withDirectives((openBlock(), createElementBlock("button", {
            key: action.key,
            class: normalizeClass(["button is-small", action.extraClasses]),
            onClick: ($event) => action.inputEvent ? null : $options.clickEvent(action, $event),
            content: action.tippy,
            disabled: action.disabled && action.disabled()
          }, [
            createBaseVNode("label", null, [
              createTextVNode(toDisplayString(action.key) + " ", 1),
              action.inputEvent ? (openBlock(), createElementBlock("input", {
                key: 0,
                accept: ".json",
                type: "file",
                onChange: ($event) => $options.clickEvent(action, $event),
                style: { "display": "none" }
              }, null, 40, _hoisted_4$3)) : createCommentVNode("", true)
            ])
          ], 10, _hoisted_3$8)), [
            [_directive_tippy, { maxWidth: 400 }]
          ]);
        }), 128))
      ])
    ])
  ]);
}
var __unplugin_components_3 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5], ["__scopeId", "data-v-a4521cec"]]);
const _hoisted_1$8 = {
  viewBox: "0 0 512 512",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$7 = /* @__PURE__ */ createBaseVNode("path", {
  d: "M405.333 106.667v298.666H106.667V106.667h298.666m0-42.667H106.667C83.198 64 64 83.198 64 106.667v298.666C64 428.802 83.198 448 106.667 448h298.666C428.802 448 448 428.802 448 405.333V106.667C448 83.198 428.802 64 405.333 64z",
  fill: "currentColor"
}, null, -1);
const _hoisted_3$7 = [
  _hoisted_2$7
];
function render$4(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$8, _hoisted_3$7);
}
var __unplugin_components_2$1 = { name: "ion-android-checkbox-outline-blank", render: render$4 };
const _hoisted_1$7 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$6 = /* @__PURE__ */ createBaseVNode("g", {
  fill: "none",
  stroke: "currentColor",
  "stroke-linecap": "round",
  "stroke-linejoin": "round",
  "stroke-width": "2"
}, [
  /* @__PURE__ */ createBaseVNode("path", { d: "m9 11l3 3l8-8" }),
  /* @__PURE__ */ createBaseVNode("path", { d: "M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9" })
], -1);
const _hoisted_3$6 = [
  _hoisted_2$6
];
function render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$7, _hoisted_3$6);
}
var __unplugin_components_1$1 = { name: "tabler-checkbox", render: render$3 };
const _hoisted_1$6 = {
  viewBox: "0 0 16 16",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$5 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1l-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z"
}, null, -1);
const _hoisted_3$5 = [
  _hoisted_2$5
];
function render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$6, _hoisted_3$5);
}
var __unplugin_components_2 = { name: "bi-trash3", render: render$2 };
const _hoisted_1$5 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10s10-4.47 10-10S17.53 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8s8 3.58 8 8s-3.58 8-8 8z"
}, null, -1);
const _hoisted_3$4 = [
  _hoisted_2$4
];
function render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$5, _hoisted_3$4);
}
var __unplugin_components_1 = { name: "ic-outline-circle", render: render$1 };
const _hoisted_1$4 = {
  viewBox: "0 0 20 20",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("path", {
  fill: "currentColor",
  d: "m0 11l2-2l5 5L18 3l2 2L7 18z"
}, null, -1);
const _hoisted_3$3 = [
  _hoisted_2$3
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$4, _hoisted_3$3);
}
var __unplugin_components_0$3 = { name: "zondicons-checkmark", render };
var bulma_css_vue_type_style_index_0_src_ec865996_scoped_true_lang = "";
var contExtractionSetting_vue_vue_type_style_index_1_scoped_true_lang = "";
const _sfc_main$4 = {
  props: ["index", "settings", "setting"],
  data: function() {
    return {
      store: this.$store.state
    };
  },
  computed: {
    settingHasData() {
      return _.get(this.$store.state.storageHasData, this.setting.name);
    },
    settingDisabled() {
      return this.setting.disabled === false ? null : true;
    }
  },
  methods: {
    settingChanged: function() {
      const setting = this.setting;
      const checked = !setting.value;
      const mainSteps = this.$store.getters.settings_mainSteps;
      const update = [];
      update.push({
        item: setting,
        obj: {
          value: checked
        }
      });
      if (setting.parent) {
        const parent = _.find(mainSteps, { name: setting.parent });
        const activeSibling = _.find(mainSteps, function(o) {
          return o.parent === setting.parent && o.value && o.name !== setting.name;
        });
        const parentObj = {
          disabled: !!(checked || activeSibling)
        };
        if (parentObj.disabled)
          parentObj.value = true;
        update.push({
          item: parent,
          obj: parentObj
        });
      }
      this.$store.commit("updateSetting", update);
    },
    deleteChunkData: function(deleteArray, onSuccess) {
      let vue = this;
      vue.loading = true;
      let confirmation = window.confirm('Delete "' + this.setting.label + '" data?');
      if (!confirmation)
        return;
      let keysString = deleteArray.join(", ").replace("books", "library");
      let errorMsg = "Failed to remove data for: <strong>" + keysString + "</strong>";
      let successMsg = "Successfully removed data for: <strong>" + keysString + "</strong>";
      let errorNotification = function(e2) {
        vue.loading = false;
        vue.$toast.error(errorMsg + " (" + e2 + ")", vue.toastOpts);
      };
      chrome.storage.local.get(null).then((data) => {
        _.each(deleteArray, function(deleteKey) {
          let realKey;
          if (deleteKey === "isbn") {
            deleteKey = "books";
            realKey = "isbn";
          }
          _.each(_.range(0, data[deleteKey + "-chunk-length"]), function(index) {
            if (realKey === "isbn") {
              _.each(data["books-chunk-" + index], function(book) {
                if (book.isbns)
                  delete book.isbns;
              });
            } else {
              delete data[deleteKey + "-chunk-" + index];
            }
          });
          if (deleteKey !== "books" || deleteKey === "books" && realKey !== "isbn") {
            delete data[deleteKey + "-chunk-length"];
            _.remove(data.chunks, function(value) {
              return value === deleteKey;
            });
          }
          if (deleteKey === "books") {
            _.remove(data.chunks, function(value) {
              return value === "isbn";
            });
          }
          delete data.version[deleteKey === "books" ? "library" : deleteKey];
          if (data.config && data.config.steps)
            delete data.config.steps;
        });
        if (data.chunks.length < 1)
          delete data.chunks;
        chrome.storage.local.clear().then(() => {
          chrome.storage.local.set(data).then(() => {
            if (onSuccess)
              onSuccess(data);
            vue.$toast.success(successMsg, vue.store.toastOpts);
            vue.$dataChecker(data);
          }).catch(errorNotification);
        }).catch(errorNotification);
      }).catch(errorNotification);
    }
  }
};
const _hoisted_1$3 = ["content"];
const _hoisted_2$2 = { class: "control pointer" };
const _hoisted_3$2 = ["disabled"];
const _hoisted_4$2 = ["content"];
const _hoisted_5$2 = ["disabled"];
const _hoisted_6$2 = { class: "checkbox" };
const _hoisted_7$1 = ["content"];
const _hoisted_8$1 = { class: "icon is-small" };
function _sfc_render$4(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_zondicons_checkmark = __unplugin_components_0$3;
  const _component_ic_outline_circle = __unplugin_components_1;
  const _component_bi_trash3 = __unplugin_components_2;
  const _directive_tippy = resolveDirective("tippy");
  return withDirectives((openBlock(), createElementBlock("div", {
    class: normalizeClass(["field has-addons", { disabled: $props.setting.disabled }]),
    style: { "margin": "5px" },
    content: $props.setting.cannotAccessTippy
  }, [
    createBaseVNode("p", _hoisted_2$2, [
      createBaseVNode("button", {
        class: "checbox-wrapper button is-small",
        onClick: _cache[0] || (_cache[0] = ($event) => $options.settingChanged()),
        disabled: $options.settingDisabled
      }, [
        createBaseVNode("div", {
          class: normalizeClass(["button", [$props.setting.value ? $props.setting.type : null]])
        }, [
          $props.setting.value ? (openBlock(), createBlock(_component_zondicons_checkmark, { key: 0 })) : (openBlock(), createBlock(_component_ic_outline_circle, {
            key: 1,
            style: { "opacity": ".7" }
          }))
        ], 2)
      ], 8, _hoisted_3$2)
    ]),
    withDirectives((openBlock(), createElementBlock("p", {
      class: "control full-width pointer",
      content: $props.setting.tippy
    }, [
      createBaseVNode("button", {
        class: "button checkbox-btn is-small",
        disabled: $options.settingDisabled,
        onClick: _cache[1] || (_cache[1] = ($event) => $options.settingChanged())
      }, [
        createBaseVNode("label", _hoisted_6$2, toDisplayString($props.setting.label), 1)
      ], 8, _hoisted_5$2)
    ], 8, _hoisted_4$2)), [
      [_directive_tippy]
    ]),
    $options.settingHasData ? withDirectives((openBlock(), createElementBlock("p", {
      key: 0,
      class: "control delete-btn",
      content: "Remove previously extracted data." + ($props.setting.trashTippy ? "<br>" + $props.setting.trashTippy : "")
    }, [
      createBaseVNode("button", {
        class: "button is-small remove-individual-sections-icon",
        onClick: _cache[2] || (_cache[2] = ($event) => $options.deleteChunkData($props.setting.deleteChunks || [$props.setting.name]))
      }, [
        createBaseVNode("span", _hoisted_8$1, [
          createVNode(_component_bi_trash3)
        ])
      ])
    ], 8, _hoisted_7$1)), [
      [_directive_tippy]
    ]) : createCommentVNode("", true)
  ], 10, _hoisted_1$3)), [
    [_directive_tippy, { allowHTML: true, interactive: true }]
  ]);
}
var __unplugin_components_0$2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4], ["__scopeId", "data-v-ec865996"]]);
var bulma_css_vue_type_style_index_0_src_1ea459cb_scoped_true_lang = "";
var contExtractionSettings_vue_vue_type_style_index_1_scoped_true_lang = "";
const _sfc_main$3 = {
  data: function() {
    return {
      store: this.$store.state
    };
  },
  computed: {
    saveStandaloneAfter: function() {
      return _.find(this.store.sticky.extractSettings, { name: "saveStandaloneAfter" });
    }
  },
  methods: {}
};
const _withScopeId$1 = (n) => (pushScopeId("data-v-1ea459cb"), n = n(), popScopeId(), n);
const _hoisted_1$2 = {
  class: "settings-wrapper box panel",
  animation: "slide"
};
const _hoisted_2$1 = { class: "extract-settings" };
const _hoisted_3$1 = /* @__PURE__ */ _withScopeId$1(() => /* @__PURE__ */ createBaseVNode("div", { class: "settings-heading" }, [
  /* @__PURE__ */ createBaseVNode("span", { class: "title is-4" }, "Extraction Settings")
], -1));
const _hoisted_4$1 = { class: "row is-0 setting-checkboxes" };
const _hoisted_5$1 = { class: "checkbox is-small is-dark no-selection" };
const _hoisted_6$1 = { style: { "vertical-align": "middle", "padding-right": "5px" } };
function _sfc_render$3(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_cont_extraction_setting = __unplugin_components_0$2;
  const _component_tabler_checkbox = __unplugin_components_1$1;
  const _component_ion_android_checkbox_outline_blank = __unplugin_components_2$1;
  const _component_cont_extraction_actions = __unplugin_components_3;
  return openBlock(), createElementBlock("div", _hoisted_1$2, [
    createBaseVNode("div", _hoisted_2$1, [
      _hoisted_3$1,
      createBaseVNode("div", _hoisted_4$1, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.$store.getters.settings_mainSteps, (setting, index) => {
          return openBlock(), createElementBlock("div", {
            key: setting.name,
            class: normalizeClass({
              checked: setting.value,
              unchecked: !setting.value
            })
          }, [
            createVNode(_component_cont_extraction_setting, {
              class: normalizeClass({
                "partial-extraction": _ctx.store.storageHasData[setting.name]
              }),
              index,
              settings: _ctx.$store.getters.settings_mainSteps,
              setting
            }, null, 8, ["class", "index", "settings", "setting"])
          ], 2);
        }), 128))
      ]),
      createBaseVNode("label", _hoisted_5$1, [
        withDirectives(createBaseVNode("input", {
          style: { "width": "0px", "height": "0px", "position": "absolute", "top": "-1px", "left": "-1px", "overflow": "hidden", "opacity": "0" },
          type: "checkbox",
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $options.saveStandaloneAfter.value = $event)
        }, null, 512), [
          [vModelCheckbox, $options.saveStandaloneAfter.value]
        ]),
        createBaseVNode("span", _hoisted_6$1, [
          $options.saveStandaloneAfter.value ? (openBlock(), createBlock(_component_tabler_checkbox, { key: 0 })) : (openBlock(), createBlock(_component_ion_android_checkbox_outline_blank, { key: 1 }))
        ]),
        createBaseVNode("span", null, toDisplayString($options.saveStandaloneAfter.label), 1)
      ]),
      createVNode(_component_cont_extraction_actions)
    ])
  ]);
}
var __unplugin_components_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3], ["__scopeId", "data-v-1ea459cb"]]);
var bulma_css_vue_type_style_index_0_src_1d6e160e_scoped_true_lang = "";
var contMenuScreen_vue_vue_type_style_index_1_lang = "";
const _sfc_main$2 = {
  name: "menuScreen",
  props: ["domainExtension", "wishlistUrl"],
  mixins: [helpers],
  data() {
    return {
      store: this.$store.state,
      hasData: null,
      hasConfig: null,
      settingsOpen: true,
      loading: true,
      isFirefox: false,
      isChrome: false,
      releaseURL: "",
      showDeleteBtns: false,
      showPartialExtraction: false,
      exportRawDataDisabled: false,
      cannotAccessWishlist: false
    };
  },
  computed: {
    dataVersionMismatch: function() {
      return [];
    }
  },
  created: function() {
    console.log("$store.getters.settings_mainSteps", this.$store.getters.settings_mainSteps);
    this.hasData = this.$store.state.storageHasData;
    this.hasConfig = this.$store.state.storageConfig;
    this.checkBrowser();
    this.makeReleaseURLs();
  },
  mounted: function() {
    this.$nextTick(function() {
      setTimeout(() => {
        this.loading = false;
      }, 300);
    });
  },
  methods: {
    checkAccess: function(config) {
      config = config || {};
      axios.get(config.to).then(function() {
        if (config.success)
          config.success();
      }).catch(function() {
        if (config.failed)
          config.failed();
      }).then(function() {
        if (config.finally)
          config.finally();
      });
    },
    checkBrowser: function() {
      this.isFirefox = chrome.runtime.getURL("").startsWith("moz-extension://");
      this.isChrome = chrome.runtime.getURL("").startsWith("chrome-extension://");
    },
    makeReleaseURLs: function() {
      this.releaseURL = this.isFirefox ? "https://chrome.google.com/webstore/detail/audible-library-extractor/deifcolkciolkllaikijldnjeloeaall" : "https://addons.mozilla.org/firefox/addon/audible-library-extractor/";
    },
    extract: function() {
      this.takeNextStep("extract");
    },
    takeNextStep: function(step, config) {
      if (!config) {
        config = {
          steps: _.map(_.filter(this.store.sticky.extractSettings, function(o) {
            return o.value && !o.extra;
          }), function(o) {
            return { name: o.name, value: o.value };
          })
        };
      }
      config.extraSettings = _.map(_.filter(this.store.sticky.extractSettings, "extra"), function(o) {
        return { name: o.name, value: o.value, deactivated: false };
      });
      this.$compEmitter.emit("start-extraction", {
        step,
        config
      });
    }
  }
};
const _withScopeId = (n) => (pushScopeId("data-v-1d6e160e"), n = n(), popScopeId(), n);
const _hoisted_1$1 = {
  key: 0,
  class: "message is-info"
};
const _hoisted_2 = { class: "message-body" };
const _hoisted_3 = /* @__PURE__ */ createTextVNode("Previously extracted data detected: ");
const _hoisted_4 = { style: { "color": "#f7991c" } };
const _hoisted_5 = /* @__PURE__ */ createTextVNode("a faster ");
const _hoisted_6 = {
  content: "<div style='display: block; text-align: left;'><ol style='margin-left: 15px;'><li>Updates stored data that is likely to change</li><li>Does a full extract on newly added books</li><li>Clears data of removed books</li></ol><span style='display: inline-block; margin-top: 6px; color: #157df0;'>In the case of ISBN extraction, books that already have ISBNs are ignored. A large amount of books (+100) without the numbers will still take quite a while to extract.</span></div>",
  style: { "cursor": "default", "text-decoration": "underline" }
};
const _hoisted_7 = /* @__PURE__ */ createTextVNode("partial extraction");
const _hoisted_8 = [
  _hoisted_7
];
const _hoisted_9 = /* @__PURE__ */ createTextVNode(" is used");
const _hoisted_10 = /* @__PURE__ */ createTextVNode();
const _hoisted_11 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_12 = /* @__PURE__ */ createTextVNode(" If you need to do a ");
const _hoisted_13 = {
  content: "The data structure may change from version to version, in which case a full extraction is needed or at least preferred. <br><br>You need to remove extracted data in order to do a full extraction.",
  style: { "cursor": "default", "text-decoration": "underline" }
};
const _hoisted_14 = /* @__PURE__ */ createTextVNode("full extraction");
const _hoisted_15 = [
  _hoisted_14
];
const _hoisted_16 = /* @__PURE__ */ createTextVNode(", you can remove stored data using ");
const _hoisted_17 = /* @__PURE__ */ createTextVNode(". ");
const _hoisted_18 = { class: "extract-wrapper" };
const _hoisted_19 = { class: "field has-addons extract-btn" };
const _hoisted_20 = { class: "control" };
const _hoisted_21 = { class: "control" };
const _hoisted_22 = { class: "field has-addons other-btns" };
const _hoisted_23 = {
  class: "button control is-small",
  tag: "a",
  href: "https://joonaspaakko.gitbook.io/audible-library-extractor/",
  target: "_blank"
};
const _hoisted_24 = /* @__PURE__ */ createTextVNode(" Documentation ");
const _hoisted_25 = ["disabled"];
const _hoisted_26 = /* @__PURE__ */ createTextVNode(" Open gallery ");
const _hoisted_27 = {
  id: "footer",
  class: "is-small has-text-grey-light"
};
const _hoisted_28 = /* @__PURE__ */ createTextVNode(" Project source files in ");
const _hoisted_29 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("a", { href: "https://github.com/joonaspaakko/audible-library-extractor" }, "Github", -1));
const _hoisted_30 = /* @__PURE__ */ createTextVNode(". ");
const _hoisted_31 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_32 = /* @__PURE__ */ createTextVNode(" Post issues, questions, and suggestions at: ");
const _hoisted_33 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("a", { href: "https://github.com/joonaspaakko/audible-library-extractor/issues" }, "Github issues", -1));
const _hoisted_34 = /* @__PURE__ */ createTextVNode(". ");
const _hoisted_35 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_36 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("br", null, null, -1));
const _hoisted_37 = {
  target: "_blank",
  rel: "noopener noreferrer",
  href: "https://github.com/joonaspaakko/audible-library-extractor/releases/latest",
  content: "It may take a few days for a new release to propagate from Github to Firefox and Chrome web store."
};
const _hoisted_38 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("img", {
  src: "https://img.shields.io/github/v/release/joonaspaakko/audible-library-extractor?include_prereleases&label=latest%20release (Github)&color=6e41bf",
  alt: ""
}, null, -1));
const _hoisted_39 = [
  _hoisted_38
];
const _hoisted_40 = /* @__PURE__ */ createStaticVNode('<a target="_blank" rel="noopener noreferrer" href="https://github.com/joonaspaakko/audible-library-extractor/releases/latest" data-v-1d6e160e><img src="https://img.shields.io/github/release-date/joonaspaakko/audible-library-extractor?label=latest%20release&amp;color=6e41bf" alt="" data-v-1d6e160e></a><a target="_blank" rel="noopener noreferrer" href="https://github.com/joonaspaakko/audible-library-extractor/labels/bug" data-v-1d6e160e><img src="https://img.shields.io/github/issues/joonaspaakko/audible-library-extractor/bug?label=known bugs&amp;color=6e41bf" alt="" data-v-1d6e160e></a><br data-v-1d6e160e><a target="_blank" rel="noopener noreferrer" href="https://chrome.google.com/webstore/detail/audible-library-extractor/deifcolkciolkllaikijldnjeloeaall" data-v-1d6e160e><img src="https://img.shields.io/chrome-web-store/v/deifcolkciolkllaikijldnjeloeaall?color=2acb41&amp;label=latest%20release (Chrome)" alt="" data-v-1d6e160e></a><a target="_blank" rel="noopener noreferrer" href="https://addons.mozilla.org/en-US/firefox/addon/audible-library-extractor/" data-v-1d6e160e><img src="https://img.shields.io/amo/v/audible-library-extractor?label=latest%20release (Firefox)" alt="" data-v-1d6e160e></a>', 5);
const _hoisted_45 = { style: { "margin-top": "10px" } };
const _hoisted_46 = { style: { "border": "1px dashed #e1e1e1", "padding": "10px 15px", "display": "inline-block" } };
const _hoisted_47 = /* @__PURE__ */ createTextVNode(" You're currently using ");
const _hoisted_48 = /* @__PURE__ */ createTextVNode(". ");
const _hoisted_49 = {
  key: 1,
  class: "extraction-loading"
};
function _sfc_render$2(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_cont_extraction_settings = __unplugin_components_0$1;
  const _component_ph_arrow_circle_right_bold = __unplugin_components_1$2;
  const _component_ri_external_link_line = __unplugin_components_2$2;
  const _component_cont_changelog = __unplugin_components_3$1;
  const _component_gg_spinner = __unplugin_components_4;
  const _directive_tippy = resolveDirective("tippy");
  return openBlock(), createElementBlock("div", null, [
    !$data.loading ? (openBlock(), createElementBlock("div", {
      key: 0,
      id: "ale-menu-screen",
      class: normalizeClass({ "show-delete-btns": $data.showDeleteBtns, "show-partial-extraction": $data.showPartialExtraction })
    }, [
      createVNode(_component_cont_extraction_settings),
      _ctx.$store.getters.partialDataSettings_any ? (openBlock(), createElementBlock("article", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("strong", null, [
            _hoisted_3,
            createBaseVNode("span", _hoisted_4, [
              _hoisted_5,
              withDirectives((openBlock(), createElementBlock("span", _hoisted_6, _hoisted_8)), [
                [_directive_tippy, { allowHTML: true }]
              ]),
              _hoisted_9
            ]),
            _hoisted_10,
            createBaseVNode("span", {
              class: "init-show-partial-extraction",
              style: { "color": "#f7991c" },
              onMouseover: _cache[0] || (_cache[0] = ($event) => $data.showPartialExtraction = true),
              onMouseleave: _cache[1] || (_cache[1] = ($event) => $data.showPartialExtraction = false)
            }, "where applicable.", 32)
          ]),
          _hoisted_11,
          _hoisted_12,
          withDirectives((openBlock(), createElementBlock("span", _hoisted_13, _hoisted_15)), [
            [_directive_tippy, { maxWidth: 310 }]
          ]),
          _hoisted_16,
          createBaseVNode("span", {
            class: "init-show-detele-btns",
            onMouseover: _cache[2] || (_cache[2] = ($event) => $data.showDeleteBtns = true),
            onMouseleave: _cache[3] || (_cache[3] = ($event) => $data.showDeleteBtns = false)
          }, "these buttons", 32),
          _hoisted_17
        ])
      ])) : createCommentVNode("", true),
      createBaseVNode("div", null, [
        createBaseVNode("div", _hoisted_18, [
          withDirectives(createBaseVNode("div", _hoisted_19, [
            createBaseVNode("p", _hoisted_20, [
              createBaseVNode("button", {
                class: "button is-info extract is-large",
                onClick: _cache[4] || (_cache[4] = (...args) => $options.extract && $options.extract(...args)),
                expanded: ""
              }, " Extract selected items ")
            ]),
            createBaseVNode("p", _hoisted_21, [
              createBaseVNode("button", {
                class: "button is-dark is-large",
                onClick: _cache[5] || (_cache[5] = (...args) => $options.extract && $options.extract(...args))
              }, [
                createVNode(_component_ph_arrow_circle_right_bold)
              ])
            ])
          ], 512), [
            [vShow, !$data.store.extractionButtonDisabled && !$data.loading]
          ]),
          createBaseVNode("div", _hoisted_22, [
            createBaseVNode("a", _hoisted_23, [
              _hoisted_24,
              createVNode(_component_ri_external_link_line)
            ]),
            createBaseVNode("a", {
              class: "button control is-small",
              disabled: !_ctx.$store.getters.mainDataExists ? true : null,
              onClick: _cache[6] || (_cache[6] = ($event) => $options.takeNextStep("output"))
            }, [
              _hoisted_26,
              createVNode(_component_ri_external_link_line)
            ], 8, _hoisted_25)
          ])
        ])
      ]),
      createVNode(_component_cont_changelog),
      createBaseVNode("div", _hoisted_27, [
        _hoisted_28,
        _hoisted_29,
        _hoisted_30,
        _hoisted_31,
        _hoisted_32,
        _hoisted_33,
        _hoisted_34,
        _hoisted_35,
        _hoisted_36,
        withDirectives((openBlock(), createElementBlock("a", _hoisted_37, _hoisted_39)), [
          [_directive_tippy]
        ]),
        _hoisted_40,
        createBaseVNode("div", _hoisted_45, [
          createBaseVNode("span", _hoisted_46, [
            _hoisted_47,
            createBaseVNode("strong", null, "version " + toDisplayString($data.store.appVersion), 1),
            _hoisted_48
          ])
        ])
      ])
    ], 2)) : (openBlock(), createElementBlock("div", _hoisted_49, [
      createVNode(_component_gg_spinner, { class: "spin" })
    ]))
  ]);
}
var __unplugin_components_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2], ["__scopeId", "data-v-1d6e160e"]]);
function AxiosRateLimit(axios2) {
  this.queue = [];
  this.timeslotRequests = 0;
  this.interceptors = {
    request: null,
    response: null
  };
  this.handleRequest = this.handleRequest.bind(this);
  this.handleResponse = this.handleResponse.bind(this);
  this.enable(axios2);
}
AxiosRateLimit.prototype.getMaxRPS = function() {
  var perSeconds = this.perMilliseconds / 1e3;
  return this.maxRequests / perSeconds;
};
AxiosRateLimit.prototype.setMaxRPS = function(rps) {
  this.setRateLimitOptions({
    maxRequests: rps,
    perMilliseconds: 1e3
  });
};
AxiosRateLimit.prototype.setRateLimitOptions = function(options) {
  if (options.maxRPS) {
    this.setMaxRPS(options.maxRPS);
  } else {
    this.perMilliseconds = options.perMilliseconds;
    this.maxRequests = options.maxRequests;
  }
};
AxiosRateLimit.prototype.enable = function(axios2) {
  function handleError(error) {
    return Promise.reject(error);
  }
  this.interceptors.request = axios2.interceptors.request.use(
    this.handleRequest,
    handleError
  );
  this.interceptors.response = axios2.interceptors.response.use(
    this.handleResponse,
    handleError
  );
};
AxiosRateLimit.prototype.handleRequest = function(request) {
  return new Promise(function(resolve) {
    this.push({ resolve: function() {
      resolve(request);
    } });
  }.bind(this));
};
AxiosRateLimit.prototype.handleResponse = function(response) {
  this.shift();
  return response;
};
AxiosRateLimit.prototype.push = function(requestHandler) {
  this.queue.push(requestHandler);
  this.shiftInitial();
};
AxiosRateLimit.prototype.shiftInitial = function() {
  setTimeout(function() {
    return this.shift();
  }.bind(this), 0);
};
AxiosRateLimit.prototype.shift = function() {
  if (!this.queue.length)
    return;
  if (this.timeslotRequests === this.maxRequests) {
    if (this.timeoutId && typeof this.timeoutId.ref === "function") {
      this.timeoutId.ref();
    }
    return;
  }
  var queued = this.queue.shift();
  queued.resolve();
  if (this.timeslotRequests === 0) {
    this.timeoutId = setTimeout(function() {
      this.timeslotRequests = 0;
      this.shift();
    }.bind(this), this.perMilliseconds);
    if (typeof this.timeoutId.unref === "function") {
      if (this.queue.length === 0)
        this.timeoutId.unref();
    }
  }
  this.timeslotRequests += 1;
};
function axiosRateLimit(axios2, options) {
  var rateLimitInstance = new AxiosRateLimit(axios2);
  rateLimitInstance.setRateLimitOptions(options);
  axios2.getMaxRPS = AxiosRateLimit.prototype.getMaxRPS.bind(rateLimitInstance);
  axios2.setMaxRPS = AxiosRateLimit.prototype.setMaxRPS.bind(rateLimitInstance);
  axios2.setRateLimitOptions = AxiosRateLimit.prototype.setRateLimitOptions.bind(rateLimitInstance);
  return axios2;
}
var src = axiosRateLimit;
var amapxios = {
  methods: {
    minutesToMilliseconds: function(minutes) {
      return minutes * 60 * 1e3;
    },
    secondsToMilliseconds: function(seconds) {
      return seconds * 1e3;
    },
    amapxios: function(options) {
      const vue = this;
      const limiter = options.rateLimit || this.$store.state.axiosRateLimit;
      const maxTimeout = this.minutesToMilliseconds(1);
      let cAxios = axios.create();
      cAxios = src(cAxios, limiter);
      const getRequestId = (inputUrl) => {
        let url = new Url(DOMPurify.sanitize(inputUrl));
        if (url.query.asin) {
          return url.query.asin;
        } else {
          const splitPath = url.path.split("/");
          return splitPath[splitPath.length - 1];
        }
      };
      asyncMapLimit(options.requests, limiter.maxRequests, function(request, stepCallback) {
        const axiosConfig = options.config || {};
        const requestURL2 = request.requestUrl || request.url || request;
        const requestId = request.requestId || request.asin || getRequestId(requestURL2);
        const controller = new AbortController();
        console.log("request", request);
        console.log("requestURL", requestURL2);
        console.log("requestId", requestId);
        const urlAlreadyFailed = _.includes(vue.$store.state.failedRequests, requestId);
        console.log("urlAlreadyFailed", urlAlreadyFailed, JSON.parse(JSON.stringify(vue.$store.state.failedRequests)), requestURL2);
        if (urlAlreadyFailed) {
          stepCallback(null, null);
          return;
        }
        axiosConfig.signal = controller.signal;
        axiosConfig.validateStatus = function(status) {
          return status >= 200 && status < 400;
        };
        let requestTimer = setTimeout(() => {
          controller.abort("Request took too long... (" + requestURL2 + ")");
        }, maxTimeout);
        let requestResult = null;
        cAxios.get(requestURL2, axiosConfig).then(function(response) {
          try {
            options.step(response, function(result) {
              requestResult = result;
            }, request);
          } catch (e2) {
            console.log("%caxios caught an error (step)", "background: #0082ab; color: #fff; padding: 2px 5px; border-radius: 8px;", e2);
          }
        }).catch(function(e2) {
          const status = _.get(e2, "response.status");
          vue.$store.commit("update", { key: "lastFailedRequestStatus", value: status });
          if (status == 404 || status == 503)
            vue.$store.commit("pushToFailedRequests", requestId);
          console.log("%caxios caught an error (step)", "background: #f41b1b; color: #fff; padding: 2px 5px; border-radius: 8px;", "\n\n", requestURL2, "\n\n", e2);
          if (_.get(e2, "message") === "canceled")
            vue.$store.commit("pushToCanceledRequests", requestURL2);
          try {
            if (options.returnCatch) {
              options.step(_.get(e2, "response", e2), function(result) {
                requestResult = result;
              }, request, "processingError");
            }
          } catch (e3) {
            console.log("%caxios caught an error (step)", "background: #0082ab; color: #fff; padding: 2px 5px; border-radius: 8px;", e3);
          }
        }).then(function() {
          clearTimeout(requestTimer);
          stepCallback(null, requestResult);
        });
      }, function(err, results) {
        if (!err) {
          results = options.flatten ? _.flatten(results) : results;
          results = _.compact(results);
          options.done(results);
        } else {
          console.log("%caxios caught an error (done)", "background: #f79a33; color: #fff; padding: 2px 5px; border-radius: 8px;", err);
          options.done(null, true);
        }
      });
    },
    chunkAmapxios: function(options) {
      const vue = this;
      const limiter = options.rateLimit || this.$store.state.axiosRateLimit;
      const maxTimeout = this.minutesToMilliseconds(1);
      let cAxios = axios.create();
      cAxios = src(cAxios, limiter);
      const getRequestId = (inputUrl) => {
        let url = new Url(DOMPurify.sanitize(inputUrl));
        if (url.query.asin) {
          return url.query.asin;
        } else {
          const splitPath = url.path.split("/");
          return splitPath[splitPath.length - 1];
        }
      };
      const break_threshold = 300;
      const break_time = 1e4;
      const requestChunks = _.chunk(options.requests, break_threshold);
      let chunkCounter = -1;
      asyncMapLimit(requestChunks, 1, function(requestChunk, eachCallback) {
        ++chunkCounter;
        vue.$store.commit("update", { key: "taking_a_break", value: true });
        setTimeout(() => {
          vue.$store.commit("update", { key: "taking_a_break", value: false });
          asyncMapLimit(requestChunk, limiter.maxRequests, function(request, stepCallback) {
            const axiosConfig = options.config || {};
            const requestURL2 = request.requestUrl || request.url || request;
            const requestId = request.requestId || request.asin || getRequestId(requestURL2);
            const controller = new AbortController();
            const urlAlreadyFailed = _.includes(vue.$store.state.failedRequests, requestId);
            if (urlAlreadyFailed) {
              stepCallback(null, null);
              return;
            }
            axiosConfig.signal = controller.signal;
            axiosConfig.validateStatus = function(status) {
              return status >= 200 && status < 400;
            };
            let requestTimer = setTimeout(() => {
              controller.abort("Request took too long... (" + requestURL2 + ")");
            }, maxTimeout);
            let requestResult = null;
            cAxios.get(requestURL2, axiosConfig).then(function(response) {
              try {
                options.step(response, function(result) {
                  requestResult = result;
                }, request);
              } catch (e2) {
                console.log("%caxios caught an error (step)", "background: #0082ab; color: #fff; padding: 2px 5px; border-radius: 8px;", e2);
              }
            }).catch(function(e2) {
              const status = _.get(e2, "response.status");
              vue.$store.commit("update", { key: "lastFailedRequestStatus", value: status });
              if (status == 404 || status == 503)
                vue.$store.commit("pushToFailedRequests", requestId);
              console.log("%caxios caught an error (step)", "background: #f41b1b; color: #fff; padding: 2px 5px; border-radius: 8px;", "\n\n", requestURL2, "\n\n", e2);
              if (_.get(e2, "message") === "canceled")
                vue.$store.commit("pushToCanceledRequests", requestURL2);
              try {
                if (options.returnCatch) {
                  options.step(_.get(e2, "response", e2), function(result) {
                    requestResult = result;
                  }, request, "processingError");
                }
              } catch (e3) {
                console.log("%caxios caught an error (step)", "background: #0082ab; color: #fff; padding: 2px 5px; border-radius: 8px;", e3);
              }
            }).then(function() {
              clearTimeout(requestTimer);
              stepCallback(null, requestResult);
            });
          }, function(err, results) {
            if (!err) {
              results = options.flatten ? _.flatten(results) : results;
              results = _.compact(results);
              eachCallback(null, results);
            } else {
              eachCallback(null, null);
            }
          });
        }, chunkCounter === 0 ? 0 : break_time);
      }, function(err, results) {
        console.log("231312313123132123123123:", err, results);
        if (!err) {
          results = options.flatten ? _.flatten(results) : results;
          results = _.compact(results);
          console.log("results each:", results);
          options.done(results);
        } else {
          console.log("%caxios caught an error (done)", "background: #f79a33; color: #fff; padding: 2px 5px; border-radius: 8px;", err);
          options.done(null, true);
        }
      });
    }
  }
};
var scrapingPrep = {
  methods: {
    scrapingPrep: function(config) {
      const vue = this;
      config = config || {};
      let url = new Url(DOMPurify.sanitize(config.url));
      const urlAlreadyFailed = _.includes(vue.$store.state.failedRequests, url);
      if (urlAlreadyFailed) {
        config.done({});
        return;
      }
      const letMeAxiosAQuestion = axios.create();
      const axiosLimited = src(letMeAxiosAQuestion, this.$store.state.axiosRateLimit);
      waterfall(
        [
          function(callback) {
            url.query.ale = true;
            url.query.bp_ua = "yes";
            let obj = {};
            obj.urlObj = url;
            let result = [null, {}];
            if (config.skipFirstCall) {
              result = vue.getMaxPageSize(obj, config, config.response, callback);
              callback(result[0], result[1]);
            } else {
              axiosLimited.get(url.toString()).then(function(response) {
                result = vue.getMaxPageSize(obj, config, response, callback);
              }).catch(function(e2) {
                const status = _.get(e2, "response.status");
                if (status == 404)
                  vue.$store.commit("pushToFailedRequests", requestURL);
                result = [true, {}];
              }).then(function() {
                callback(result[0], result[1]);
              });
            }
          },
          function(o, callback) {
            axiosLimited.get(o.urlObj.toString()).then(function(response) {
              const audible = $($.parseHTML(response.data)).find("div.adbl-main");
              const pagination = audible.find(".pagingElements");
              const pagesLength = pagination.length > 0 ? parseFloat(DOMPurify.sanitize(pagination.find(".pageNumberElement:last").text())) : 1;
              o.pageNumbers = _.range(1, pagesLength + 1);
              o.pageSize = o.urlObj.query.pageSize || null;
              callback(null, o);
            });
          }
        ],
        function(err, obj) {
          config.done(obj);
        }
      );
    },
    getMaxPageSize: function(obj, config, response, waterfallback) {
      const data = _.get(response, "data");
      if (!data)
        return [null, null];
      const audible = $($.parseHTML(data)).find("div.adbl-main");
      const pageSizeDropdown = audible.find('select[name="pageSize"]');
      const maxPageSize = pageSizeDropdown.length > 0 ? DOMPurify.sanitize(pageSizeDropdown.find("option:last").val()) : null;
      obj.urlObj.query.pageSize = config.maxSize || obj.urlObj.query.pageSize || maxPageSize;
      if (config.returnResponse)
        obj.response = response;
      const pagination = audible.find(".pagingElements").length;
      if (!pagination || !maxPageSize || maxPageSize < 50 || config.returnAfterFirstCall) {
        obj.pageNumbers = [1];
        obj.pageSize = obj.urlObj.query.pageSize;
        return [true, obj];
      } else {
        return [null, obj];
      }
    },
    getPageNumbers: function(response) {
      const audible = $($.parseHTML(response.data)).find("div.adbl-main");
      const pagination = audible.find(".pagingElements");
      const pagesLength = pagination.length > 0 ? parseFloat(DOMPurify.sanitize(pagination.find(".pageNumberElement:last").text())) : 1;
      return _.range(1, pagesLength + 1);
    }
  }
};
var getDataFromCarousel = {
  methods: {
    getDataFromCarousel: function(parentBook, audible, key, carouselID) {
      const carousel = audible.querySelector("#adbl-web-carousel-c" + carouselID);
      if (carousel) {
        const books = [];
        const flyouts = carousel.querySelectorAll(".carousel-product");
        _.each(flyouts, function(el) {
          const book = {};
          let image = el.querySelector('[id^="product-carousel-image"]');
          if (image)
            image = image.getAttribute("src") || image.getAttribute("data-lazy");
          if (!image)
            return false;
          let coverId = image.match(/\/images\/I\/(.*)._SL/);
          if (coverId && coverId[1])
            coverId = "" + DOMPurify.sanitize(coverId[1]);
          if (!coverId)
            return false;
          book.cover = coverId;
          let bookASIN = el.querySelector("[data-asin]");
          if (bookASIN)
            bookASIN = bookASIN.getAttribute("data-asin");
          if (bookASIN)
            bookASIN = "" + DOMPurify.sanitize(bookASIN);
          if (!bookASIN)
            return false;
          book.asin = bookASIN;
          const list = el.querySelector("[id^=product-list-flyout] ul");
          let listItems, subHeading;
          if (list) {
            listItems = list.querySelectorAll("li:not(.bc-size-base)");
            if (listItems) {
              subHeading = list.querySelector("li.bc-size-base:nth-child(2)");
              if (subHeading) {
                let shTrailingComma = subHeading.querySelector(".bc-pub-offscreen");
                if (shTrailingComma)
                  shTrailingComma.remove();
              }
              if (subHeading)
                subHeading = subHeading.textContent;
              if (subHeading)
                subHeading = DOMPurify.sanitize(subHeading.trim());
              if (subHeading)
                book.subHeading = subHeading;
            }
          }
          if (listItems) {
            _.each(listItems, function(el2, i2) {
              let trailingComma = el2.querySelector(".bc-pub-offscreen");
              if (trailingComma)
                trailingComma.remove();
              let text2 = el2.textContent;
              if (text2)
                text2 = DOMPurify.sanitize(text2.trimAll());
              if (text2 && !el2.querySelector("h2"))
                text2 = text2.trimToColon();
              if (!text2)
                return false;
              var line = i2 + 1;
              switch (line) {
                case 1:
                  book.title = text2;
                  break;
                case 2:
                  book.authors = text2;
                  break;
                case 3:
                  book.narrators = text2;
                  break;
                case 4:
                  book.length = text2;
                  break;
              }
            });
          }
          books.push(book);
        });
        if (books.length > 0)
          parentBook[key] = books;
      }
    }
  }
};
var getDataFromLibraryPages = {
  methods: {
    getDataFromLibraryPages: function(hotpotato, libraryPagesFetched) {
      const vue = this;
      if (_.find(hotpotato.config.steps, { name: "books" })) {
        this.$store.commit("update", [
          { key: "bigStep.step", value: 0 },
          { key: "subStep.step", value: 0 }
        ]);
        this.$store.commit("update", [
          { key: "bigStep.title", value: "Library" },
          { key: "bigStep.step", add: 1 },
          { key: "subStep.step", add: 1 },
          { key: "subStep.max", value: 5 },
          { key: "progress.step", value: 0 },
          { key: "progress.max", value: 0 },
          { key: "progress.text", value: this.$store.state.storageHasData.books ? "Updating old books and adding new books..." : "Scanning library for books..." }
        ]);
        vue.scrapingPrep({
          url: vue.libraryUrl,
          maxSize: 20,
          done: function(prep) {
            const requestURL2 = prep.urlObj.toString();
            vue.amapxios({
              requests: _.map(prep.pageNumbers, function(page) {
                return {
                  requestUrl: requestURL2 + "&page=" + page,
                  requestId: "library-page-" + page
                };
              }),
              step: function(response, stepCallback) {
                vue.processLibraryPage(response, hotpotato, stepCallback);
              },
              flatten: true,
              done: function(books) {
                vue.$nextTick(function() {
                  hotpotato.books = books;
                  if (hotpotato.books && hotpotato.books.length) {
                    const changedBooks = _.xorBy(hotpotato.books, books, "asin");
                    if (changedBooks.length > 0) {
                      let removedBooks = _.filter(changedBooks, function(book) {
                        return !book.isNewThisRound;
                      });
                      if (removedBooks.length > 0) {
                        vue.removeFromSeries(hotpotato.series, removedBooks);
                        vue.removeFromCollections(hotpotato.collections, removedBooks);
                      }
                    }
                    if (hotpotato.wishlist && hotpotato.wishlist.length > 0) {
                      let newBooks = _.filter(hotpotato.books, "isNewThisRound");
                      if (newBooks.length > 0) {
                        newBooks = _.map(newBooks, "asin");
                        _.remove(hotpotato.wishlist, function(wBook) {
                          return _.includes(newBooks, wBook.asin);
                        });
                      }
                    }
                  }
                  hotpotato.config.getStorePages = "books";
                  vue.$nextTick(function() {
                    libraryPagesFetched(null, hotpotato);
                  });
                });
              }
            });
          }
        });
      } else {
        vue.$store.commit("resetProgress");
        libraryPagesFetched(null, hotpotato);
      }
    },
    processLibraryPage: function(response, hotpotato, stepCallback) {
      let vue = this;
      const audible = $($.parseHTML(response.data)).find("div.adbl-main")[0];
      response.data = null;
      const books = [];
      const titleRows = audible.querySelectorAll("#adbl-library-content-main > .adbl-library-content-row");
      each(titleRows, function(_thisRow) {
        const rowItem = {
          is: {
            product: _thisRow.querySelector('[name="contentType"][value="Product"]'),
            performance: _thisRow.querySelector('[name="contentType"][value="Performance"]'),
            lecture: _thisRow.querySelector('[name="contentType"][value="Lecture"]'),
            podcast: _thisRow.querySelector('[name="contentType"][value="Podcast"]')
          }
        };
        let bookASIN = _thisRow.querySelector("[data-asin]");
        bookASIN = bookASIN.getAttribute("data-asin");
        bookASIN = DOMPurify.sanitize(bookASIN);
        const bookInMemory = _.find(hotpotato.books, ["asin", bookASIN]);
        const fullScan_ALL_partialScan_NEW = vue.$store.state.storageHasData.books && !bookInMemory || !vue.$store.state.storageHasData.books;
        let book = vue.$store.state.storageHasData.books && bookInMemory ? bookInMemory : {};
        if (bookInMemory && bookInMemory.isbns)
          book.isbns = bookInMemory.isbns;
        let storePageLink;
        if (rowItem.is.podcast)
          storePageLink = _thisRow.querySelector(".adbl-episodes-link > a");
        if (!storePageLink)
          storePageLink = _thisRow.querySelector(":scope > div > div > div > div > span > ul > li:nth-child(1) > a");
        if (storePageLink) {
          let storePageUrl = new Url(window.location.origin + DOMPurify.sanitize(storePageLink.getAttribute("href")));
          storePageUrl.clearQuery();
          book.storePageRequestUrl = storePageUrl.toString();
        }
        if (fullScan_ALL_partialScan_NEW) {
          book.asin = bookASIN;
          const coverImg = _thisRow.querySelector("a > img.bc-image-inset-border:first-of-type") || _thisRow.querySelector(":scope > div > div > div > a > img.bc-image-inset-border") || _thisRow.querySelector(":scope > div > div > div > img.bc-image-inset-border");
          if (coverImg) {
            let coverUrl = coverImg.getAttribute("src");
            coverUrl = DOMPurify.sanitize(coverUrl);
            if (coverUrl.lastIndexOf("img-coverart-prod-unavailable") < 0) {
              let coverId = coverUrl.match(/\/images\/I\/(.*)._SL/);
              coverId = _.get(coverId, "[1]");
              if (coverId)
                book.cover = coverId;
            }
          }
          book.title = DOMPurify.sanitize(_thisRow.querySelector(":scope > div > div > div > div > span > ul > li:nth-child(1)").textContent.trimAll());
          book.authors = vue.getArray(_thisRow.querySelectorAll(".authorLabel a"));
          book.narrators = vue.getArray(_thisRow.querySelectorAll(".narratorLabel a"));
          book.series = vue.getSeries(_thisRow.querySelector(".seriesLabel > span"));
          book.blurb = DOMPurify.sanitize(_thisRow.querySelector(".summaryLabel > span").textContent.trimAll());
          const fromPlusCatalog = _thisRow.querySelector('input[value="AudibleDiscovery"]');
          if (fromPlusCatalog)
            book.fromPlusCatalog = true;
        }
        const unavailableBtn = _thisRow.querySelector(".adbl-library-inaccessible-button");
        if (unavailableBtn) {
          book.unavailable = true;
        } else if (book.unavailable) {
          delete book.unavailable;
        }
        book.downloaded = _thisRow.querySelector(".adbl-library-action > div:nth-child(4) > span") ? true : null;
        const favorite = _thisRow.querySelector('[id^="remove-from-favorites-button"]:not(.bc-pub-hidden)');
        if (favorite)
          book.favorite = true;
        else if (book.favorite)
          delete book.favorite;
        const progressbar = _thisRow.querySelector('[id^="time-remaining-display"] [role="progressbar"]');
        const finished = _thisRow.querySelector('[id^="time-remaining-finished"]:not(.bc-pub-hidden)') ? true : false;
        let timeRemaining = _thisRow.querySelector('[id^="time-remaining"]:not(.bc-pub-hidden)');
        if (timeRemaining)
          timeRemaining = DOMPurify.sanitize(timeRemaining.textContent.trimAll());
        if (progressbar || finished) {
          book.progress = timeRemaining;
        } else {
          book.length = timeRemaining;
          book.progress = 0;
        }
        let collectionIds = _thisRow.querySelector('[id^="collectionIds-"]');
        if (collectionIds)
          delete book.collectionIds;
        console.log("collectionIds-1", collectionIds);
        if (collectionIds)
          collectionIds = collectionIds.getAttribute("value");
        if (collectionIds)
          collectionIds = collectionIds.replace(/^\[/, "").replace(/\]$/, "").trim();
        if (collectionIds)
          collectionIds = collectionIds.split(", ");
        console.log("collectionIds-2", collectionIds);
        if (collectionIds && collectionIds.length > 0) {
          const ignoreCollections = ["", "__PENDING", "__PURCHASE"];
          _.remove(collectionIds, function(value) {
            return _.includes(ignoreCollections, value.trim());
          });
          if (collectionIds.length > 0)
            book.collectionIds = collectionIds;
        }
        let myRating = _thisRow.querySelector("div.bc-rating-stars.adbl-prod-rate-review-bar.adbl-prod-rate-review-bar-overall");
        if (myRating)
          myRating = myRating.getAttribute("data-star-count");
        if (myRating > 0)
          book.myRating = DOMPurify.sanitize(myRating);
        book = _.omitBy(book, _.isNull);
        if (vue.$store.state.storageHasData.books) {
          let newAddition = !bookInMemory;
          let newFromStorage = bookInMemory && bookInMemory.isNew;
          if (newAddition || newFromStorage)
            book.isNew = true;
        }
        if (fullScan_ALL_partialScan_NEW) {
          book.isNewThisRound = true;
          vue.$store.commit("update", { key: "progress.max", add: 1 });
        }
        books.push(book);
      });
      vue.$nextTick(function() {
        stepCallback(books);
      });
    }
  }
};
var getDataFromStorePages = {
  methods: {
    getDataFromStorePages: function(hotpotato, storePagesFetched) {
      this.$store.commit("update", { key: "subStep.step", add: 1 });
      const vue = this;
      let requests = [];
      const processing = hotpotato.config.getStorePages;
      if (hotpotato.config.getStorePages) {
        requests = this.prepStorePages(hotpotato, hotpotato.config.getStorePages);
        hotpotato.config.getStorePages = false;
      }
      if (!requests.length) {
        moveOn();
      } else {
        if (!hotpotato.config.test)
          this.$store.commit("update", [
            { key: "progress.step", value: 0 },
            { key: "progress.bar", value: true },
            { key: "progress.text", value: "Fetching additional data from store pages..." }
          ]);
        console.log("requests 123", requests);
        vue.amapxios({
          requests,
          returnCatch: true,
          step: function(response, stepCallback, book, processingError) {
            if (_.get(book, "requestUrl"))
              delete book.requestUrl;
            if (!hotpotato.config.test)
              vue.$store.commit("update", { key: "progress.text2", value: _.get(book, "title") });
            if (response && response.status >= 200 && response.status < 400) {
              vue.getStorePageData(response, book, hotpotato.config.test);
            } else if (!!book) {
              book.storePageMissing = true;
            }
            if (!hotpotato.config.test)
              vue.$store.commit("update", { key: "progress.step", add: 1 });
            stepCallback(book);
          },
          flatten: true,
          done: moveOn
        });
      }
      function moveOn() {
        if (!hotpotato.config.test)
          vue.$store.commit("resetProgress");
        if (processing === "wishlist")
          vue.$store.commit("update", [
            { key: "subStep.step", value: 0 },
            { key: "subStep.max", value: 0 }
          ]);
        vue.$nextTick(function() {
          storePagesFetched(null, hotpotato);
        });
      }
    },
    prepStorePages: function(hotpotato, getStorePages) {
      let vue = this;
      _.each(hotpotato[getStorePages], function(book) {
        if (vue.$store.state.storageHasData[getStorePages] && !hotpotato.config.test) {
          if (book.isNewThisRound)
            book.requestUrl = book.storePageRequestUrl;
        } else {
          book.requestUrl = book.storePageRequestUrl;
        }
        let url = new Url(book.requestUrl);
        url.query.ipRedirectOverride = true;
        url.query.overrideBaseCountry = true;
        book.requestUrl = url.toString();
        delete book.storePageRequestUrl;
      });
      let result = [];
      if (vue.$store.state.storageHasData[getStorePages] && !hotpotato.config.test) {
        result = _.filter(hotpotato[getStorePages], "isNewThisRound");
      } else {
        result = hotpotato[getStorePages] || [];
      }
      return result;
    },
    getStorePageData: function(response, book, isTest) {
      let vue = this;
      var html2 = $($.parseHTML(response.data));
      const audible = html2.find("div.adbl-main")[0];
      let jsonData = html2.find("#bottom-0 > script:first")[0];
      if (jsonData)
        jsonData = JSON.parse(jsonData.textContent);
      const bookData = jsonData ? jsonData[0] : {};
      html2 = null;
      response.data = null;
      if (!isTest) {
        const storePageChanged = response.request.responseURL.lastIndexOf(book.asin) < 0;
        if (storePageChanged)
          book.storePageChanged = true;
      }
      const foundSample = audible && audible.querySelector("#sample-player-" + book.asin + " > button");
      const foundPlay = audible && audible.querySelector("#adbl-buy-box-play-now-button");
      if (isTest || foundSample || foundPlay) {
        book.storePageMissing = false;
        if (!book.cover) {
          const regularCover = audible.querySelector("#center-1 > div > div > div > div.bc-col-responsive > div > div:nth-child(1) > img");
          const heroPageCover = audible.querySelector("#center-1 > div > div.bc-container > div > div:nth-child(1) > img");
          let cover = regularCover || heroPageCover;
          if (cover) {
            cover = cover.getAttribute("src");
            cover = DOMPurify.sanitize(cover);
            if (cover.lastIndexOf("img-coverart-prod-unavailable") < 0) {
              let coverId = cover.match(/\/images\/I\/(.*)._SL/);
              coverId = _.get(coverId, "[1]");
              if (coverId)
                book.cover = coverId;
            }
          }
        }
        book.titleShort = DOMPurify.sanitize(bookData.name);
        const subtitle = audible.querySelector(".subtitle");
        if (subtitle)
          book.subtitle = DOMPurify.sanitize(subtitle.textContent.trimAll());
        const ratingsLink = audible.querySelector(".ratingsLabel > a");
        if (ratingsLink)
          book.ratings = parseFloat(DOMPurify.sanitize(ratingsLink.textContent.match(/\d/g).join("")));
        const ratingEl = audible.querySelector(".ratingsLabel > span:last-of-type");
        if (ratingEl)
          book.rating = Number(DOMPurify.sanitize(ratingEl.textContent.trimAll()));
        book.summary = DOMPurify.sanitize(bookData.description) || vue.getSummary(audible.querySelector(".productPublisherSummary > .bc-section > .bc-box:first-of-type") || audible.querySelector("#center-1 > div.bc-container > div > div.bc-col-responsive.bc-col-6"));
        book.releaseDate = DOMPurify.sanitize(bookData.datePublished) ? DOMPurify.sanitize(bookData.datePublished) : vue.fixDates(audible.querySelector(".releaseDateLabel"));
        book.publishers = vue.getArray(audible.querySelectorAll(".publisherLabel > a"));
        const length = audible.querySelector(".runtimeLabel");
        book.length = book.length || (length ? vue.shortenLength(length.textContent.trimToColon()) : 0);
        book.categories = vue.getArray(audible.querySelector(".categoriesLabel") ? audible.querySelectorAll(".categoriesLabel > a") : audible.querySelectorAll(".bc-breadcrumb > a"));
        book.sample = isTest || !foundSample ? null : DOMPurify.sanitize(foundSample.getAttribute("data-mp3"));
        book.language = bookData.inLanguage ? DOMPurify.sanitize(_.startCase(bookData.inLanguage)) : DOMPurify.sanitize(audible.querySelector(".languageLabel").textContent.trimToColon());
        book.format = DOMPurify.sanitize((audible.querySelector(".format") || "").textContent.trimAll());
        if (!book.series)
          book.series = vue.getSeries(audible.querySelector(".seriesLabel"));
        const whisperSyncLink = audible.querySelector(".ws4vLabel > a");
        if (whisperSyncLink) {
          const whisperSyncIcon = whisperSyncLink.querySelector("img");
          const whisperSyncText = whisperSyncIcon.getAttribute("alt");
          if (whisperSyncText.match(/Voice-enabled/))
            book.whispersync = "owned";
          else if (whisperSyncText.match(/Voice-ready/))
            book.whispersync = "available";
        }
        var tagWrapper = audible.querySelector(".product-topic-tags");
        if (tagWrapper) {
          var tagsArray = [];
          var tags = audible.querySelectorAll(".bc-chip-text");
          each(tags, function(tag) {
            var tagObj = {};
            var catUrl = tag.closest("a").getAttribute("href");
            if (catUrl) {
              catUrl = DOMPurify.sanitize(catUrl);
              catUrl = new Url(catUrl).path;
              catUrl = catUrl.split("/").pop();
              tagObj.url = DOMPurify.sanitize(catUrl);
            }
            var tagName = tag.getAttribute("data-text");
            if (tagName) {
              tagObj.name = DOMPurify.sanitize(tagName);
              tagsArray.push(tagObj);
            }
          });
          if (tagsArray.length > 0)
            book.tags = tagsArray;
        }
        vue.getDataFromCarousel(book, audible, "peopleAlsoBought", 5);
        vue.getDataFromCarousel(book, audible, "moreLikeThis", 6);
        book = _.omitBy(book, _.isNull);
      } else {
        book.storePageMissing = true;
      }
    }
  }
};
var getISBNsFromGoogleBooks = {
  methods: {
    getISBNsFromGoogleBooks: function(hotpotato, isbnsFetched) {
      if (!_.find(hotpotato.config.steps, { name: "isbn" })) {
        this.$store.commit("resetProgress");
        isbnsFetched(null, hotpotato);
      } else {
        this.$store.commit("update", [
          { key: "bigStep.step", value: 0 }
        ]);
        this.$store.commit("update", [
          { key: "bigStep.title", value: "International Standard Book Number (ISBN)" },
          { key: "bigStep.step", add: 1 },
          { key: "progress.text2", value: "(The matching process is relatively loose: beware of false matches)" },
          { key: "progress.text", value: "Fetching ISBNs from Google Books API..." },
          { key: "progress.step", value: 0 },
          { key: "progress.max", value: 0 },
          { key: "progress.bar", value: true }
        ]);
        const vue = this;
        fetchISBNs(vue, hotpotato, isbnsFetched);
      }
    }
  }
};
function fetchISBNs(vue, hotpotato, isbnsFetched) {
  const requestUrls = [];
  let booksOfInterest = _.filter(hotpotato.books, function(o) {
    return !o.isbns;
  });
  _.each(booksOfInterest, function(book) {
    if (book.title && book.authors) {
      const query = encodeURIComponent(book.title) + "+inauthor:" + encodeURIComponent(book.authors[0].name);
      const langrestrict = "";
      requestUrls.push({
        url: "https://www.googleapis.com/books/v1/volumes?" + langrestrict + "&maxResults=5&q=" + query,
        asin: book.asin,
        title: book.title
      });
    }
  });
  vue.$store.commit("update", { key: "progress.max", add: requestUrls.length });
  const letMeAxiosAQuestion = axios.create();
  axiosRetry(letMeAxiosAQuestion, {
    retries: 7,
    retryDelay: axiosRetry.exponentialDelay,
    retryCondition: function(error) {
      return axiosRetry.isNetworkOrIdempotentRequestError(error) || error && error.response && error.response.status == "429";
    }
  });
  const isbn = src(letMeAxiosAQuestion, {
    maxRequests: 6,
    perMilliseconds: 1100
  });
  asyncMapLimit(
    requestUrls,
    18,
    function(request, stepCallback) {
      isbn.get(request.url, {
        validateStatus: function(status) {
          return status >= 200 && status < 400;
        }
      }).then(function(response) {
        const book = _.find(hotpotato.books, { asin: request.asin });
        if (response && response.status >= 200 && response.status < 400 && response.data && response.data.totalItems) {
          let fuse = new Fuse(response.data.items, {
            keys: ["volumeInfo.title"]
          });
          const fuseresult = _.map(fuse.search(book.titleShort), "item");
          const api_book = _.find(fuseresult, function(item) {
            let foundIsbn = false;
            _.each(item.volumeInfo.industryIdentifiers, function(identifier) {
              if (identifier.type === "ISBN_10" || identifier.type === "ISBN_13")
                foundIsbn = true;
            });
            return foundIsbn;
          });
          if (api_book) {
            let isbns = [];
            _.each(api_book.volumeInfo.industryIdentifiers, function(identifier) {
              if (identifier.type === "ISBN_10" || identifier.type === "ISBN_13") {
                let obj = {
                  type: DOMPurify.sanitize(identifier.type),
                  identifier: DOMPurify.sanitize(identifier.identifier)
                };
                isbns.push(obj);
              }
            });
            if (isbns.length > 0) {
              book.isbns = isbns;
              if (_.get(api_book, "volumeInfo.imageLinks.smallThumbnail")) {
                const thumbnail = DOMPurify.sanitize(api_book.volumeInfo.imageLinks.smallThumbnail.replace("http://", "https://"));
                vue.$store.commit("update", { key: "progress.thumbnail", value: thumbnail });
              }
            }
          }
        }
        if (!book.isbns) {
          console.log(
            "%cCouldn't find ISBN(S): " + book.title,
            "background: #f41b1b; color: #fff; padding: 2px 5px; border-radius: 8px;",
            response
          );
        }
        vue.$store.commit("update", { key: "progress.step", add: 1 });
        stepCallback(null);
      }).catch((e2) => {
        console.log(
          "%cCouldn't find ISBN(S): " + request.title,
          "background: #f41b1b; color: #fff; padding: 2px 5px; border-radius: 8px;",
          e2.respone
        );
        vue.$store.commit("update", { key: "progress.step", add: 1 });
        stepCallback(null);
      });
    },
    function(err, result) {
      if (!err) {
        vue.$nextTick(function() {
          vue.$store.commit("resetProgress");
          isbnsFetched(null, hotpotato);
        });
      } else
        console.log(err);
    }
  );
}
var getDataFromSeriesPages = {
  methods: {
    filterBooksInSeries: function(hotpotato) {
      let booksInSeries = [];
      const config = _.get(hotpotato, "config");
      const step = {
        library: _.find(_.get(config, "steps"), { name: "books" }),
        test: _.get(config, "seriesTest")
      };
      const books = _.get(hotpotato, "books", []);
      if (step.library)
        booksInSeries = _.filter(books, function(o) {
          return o.isNewThisRound && o.series;
        });
      else if (step.test)
        booksInSeries = _.filter(books, function(o) {
          return o.series;
        });
      return booksInSeries;
    },
    getDataFromSeriesPages: function(hotpotato, seriesFetched) {
      const vue = this;
      let booksInSeries = this.filterBooksInSeries(hotpotato);
      if (!booksInSeries.length) {
        this.$store.commit("update", { key: "subStep.step", add: 3 });
        moveOn();
      } else {
        this.$store.commit("update", [
          { key: "progress.text", value: "Compiling a list of series pages..." },
          { key: "progress.step", value: 0 },
          { key: "progress.max", value: 0 },
          { key: "progress.bar", value: true }
        ]);
        let requests = [];
        _.each(booksInSeries, function(book) {
          _.each(book.series, function(series) {
            requests.push({
              url: vue.seriesUrl + "/" + series.asin + "?pageSize=50",
              asin: series.asin,
              books: [],
              allBooks: [],
              length: 0
            });
          });
        });
        requests = _.uniqBy(requests, "asin");
        waterfall(
          [
            function(waterfallback) {
              vue.getAllSeriesPages(requests, waterfallback);
            },
            function(requests2, waterfallback) {
              vue.getBooksFromSeries(hotpotato, requests2, waterfallback);
            },
            function(requests2, waterfallback) {
              vue.getMissingNumbers(hotpotato, requests2, waterfallback);
            }
          ],
          function(err, responses) {
            resetProgress();
            _.each(responses, function(series) {
              const targetSeries = _.find(requests, { asin: series.asin });
              if (targetSeries) {
                targetSeries.books = targetSeries.books.concat(series.books);
                targetSeries.allBooks = targetSeries.allBooks.concat(series.allBooks);
                targetSeries.length += series.length;
                delete targetSeries.pageNumbers;
                delete targetSeries.pageSize;
                delete targetSeries.url;
              }
            });
            const potatoSeries = _.get(hotpotato, "series", []);
            if (vue.$store.state.storageHasData.books && potatoSeries.length) {
              _.each(requests, function(series) {
                const seriesExists = _.find(potatoSeries, { asin: series.asin });
                if (seriesExists)
                  _.merge(seriesExists, series);
                else
                  hotpotato.series.push(series);
              });
            } else {
              hotpotato.series = requests;
            }
            if (err)
              console.error("%cerror", "background: #f41b1b; color: #fff; padding: 2px 5px; border-radius: 8px;", err);
            moveOn();
          }
        );
      }
      function resetProgress() {
        vue.$store.commit("update", [
          { key: "subStep.step", value: 0 },
          { key: "subStep.max", value: 0 }
        ]);
        vue.$store.commit("resetProgress");
      }
      function moveOn() {
        resetProgress();
        vue.$nextTick(function() {
          seriesFetched(null, hotpotato);
        });
      }
    },
    getAllSeriesPages: function(requests, waterfallback) {
      this.$store.commit("update", { key: "subStep.step", add: 1 });
      const vue = this;
      vue.amapxios({
        requests,
        step: function(response, stepCallback, request) {
          request.pageNumbers = vue.getPageNumbers(response);
          request.pageSize = "50";
          vue.$store.commit("update", { key: "progress.max", add: 1 });
          stepCallback(request);
        },
        flatten: true,
        done: function(responses, err) {
          let requestUrls = [];
          _.each(responses, function(request) {
            _.each(request.pageNumbers, function(page) {
              const requestDolly = JSON.parse(JSON.stringify(request));
              let url = new Url(DOMPurify.sanitize(requestDolly.url));
              url.query.page = page;
              url.query.pageSize = request.pageSize;
              requestDolly.url = url.toString();
              const splitPath = url.path.split("/");
              requestDolly.requestId = splitPath[splitPath.length - 1];
              requestUrls.push(requestDolly);
            });
          });
          waterfallback(null, requestUrls);
        }
      });
    },
    getBooksFromSeries(hotpotato, requestUrls, parentStepCallback) {
      const vue = this;
      this.$store.commit("update", [
        { key: "progress.text", value: "Fetching series order..." },
        { key: "progress.max", value: requestUrls.length },
        { key: "subStep.step", add: 1 }
      ]);
      vue.amapxios({
        requests: requestUrls,
        step: function(response, stepCallback, request) {
          const audible = $($.parseHTML(response.data)).find("div.adbl-main")[0];
          response.data = null;
          let series = null;
          const bookRows = audible.querySelectorAll(".adbl-impression-container li.productListItem");
          if (bookRows.length > 0) {
            series = {
              asin: request.asin,
              books: [],
              allBooks: [],
              length: bookRows.length
            };
            each(bookRows, function(row) {
              let inLibrary;
              const asinEl = row.querySelector("div[data-asin]");
              let titleShort = DOMPurify.sanitize(row.getAttribute("aria-label"));
              let title;
              let subtitle = row.querySelector(".subtitle");
              if (subtitle) {
                subtitle = DOMPurify.sanitize(subtitle.textContent.trimAll());
                title = titleShort + ": " + subtitle;
              } else {
                title = titleShort;
                titleShort = false;
              }
              if (title === titleShort)
                titleShort = false;
              if (asinEl) {
                const asin = asinEl.getAttribute("data-asin");
                if (row.querySelector(".adblBuyBoxInLibraryButton")) {
                  series.books.push(DOMPurify.sanitize(asin));
                }
              } else {
                const potatoBooks = _.get(hotpotato, "books", []);
                if (title)
                  inLibrary = _.find(potatoBooks, { "title": title });
                if (!inLibrary)
                  inLibrary = _.find(potatoBooks, { "titleShort": titleShort });
                if (inLibrary)
                  series.books.push(inLibrary.asin);
              }
              let aBook = {};
              if (asinEl)
                aBook.asin = DOMPurify.sanitize(asinEl.getAttribute("data-asin"));
              else if (inLibrary)
                aBook.asin = inLibrary.asin;
              if (title)
                aBook.title = title;
              if (titleShort)
                aBook.titleShort = titleShort;
              let numbers = row.querySelector(":scope > div:nth-child(1) > div > h2");
              if (numbers)
                numbers = numbers.textContent;
              if (numbers)
                aBook.bookNumbers = DOMPurify.sanitize(numbers.trimAll().replace(/[^\d]*/, "").split(",")[0]);
              if (!inLibrary && !row.querySelector(".adblBuyBoxInLibraryButton")) {
                aBook.notInLibrary = true;
              }
              if (row.querySelector('[name="discovery-add-to-library-form"]'))
                aBook.plus = true;
              if (row.querySelector(".buybox-regular-price")) {
                let price = row.querySelector(".buybox-regular-price").textContent.match(/\d/g);
                let priceArray = _.map(price, function(v) {
                  return parseFloat(v);
                });
                let sumOfPriceArray = priceArray.reduce((a3, b2) => a3 + b2, 0);
                if (sumOfPriceArray === 0)
                  aBook.free = true;
              }
              const coverImg = row.querySelector("img.bc-image-inset-border");
              if (coverImg) {
                let coverUrl = coverImg.getAttribute("src");
                coverUrl = DOMPurify.sanitize(coverUrl);
                if (coverUrl.lastIndexOf("img-coverart-prod-unavailable") < 0) {
                  let coverId = coverUrl.match(/\/images\/I\/(.*)._SL/);
                  coverId = _.get(coverId, "[1]");
                  if (coverId)
                    aBook.cover = coverId;
                }
              }
              if (!aBook.bookNumbers) {
                let findBookNumber;
                if (aBook.title)
                  findBookNumber = aBook.title.match(/(?:, Book.)(.+)/);
                if (findBookNumber)
                  findBookNumber = findBookNumber[1];
                if (findBookNumber)
                  aBook.bookNumbers = findBookNumber.replace(/\)$/, "");
              }
              if (!aBook.bookNumbers) {
                aBook.bookNumbers = function(books, seriesAsin, bookAsin) {
                  const book = _.find(books, { asin: bookAsin });
                  if (!book)
                    return;
                  const series2 = _.find(book.series, { asin: seriesAsin });
                  if (!series2)
                    return;
                  return _.isArray(series2.bookNumbers) ? series2.bookNumbers.join(",") : series2.bookNumbers;
                }(hotpotato.books, request.asin, aBook.asin);
              }
              if (!aBook.bookNumbers)
                aBook.bookNumbers = "\u221E";
              series.allBooks.push(aBook);
            });
          }
          vue.$store.commit("update", { key: "progress.step", add: 1 });
          stepCallback(series);
        },
        flatten: true,
        done: function(series) {
          parentStepCallback(null, series);
        }
      });
    },
    getMissingNumbers: function(hotpotato, series, waterfallback) {
      let booksWithMissingNumber = [];
      _.each(series, function(currentSeries) {
        let missing = _.filter(currentSeries.allBooks, { bookNumbers: "\u221E" });
        if (missing.length) {
          missing = _.map(missing, function(book) {
            return {
              requestUrl: window.location.origin + "/pd/" + book.asin,
              seriesAsin: currentSeries.asin,
              bookAsin: book.asin
            };
          });
          booksWithMissingNumber = booksWithMissingNumber.concat(missing);
        }
      });
      this.$store.commit("update", [
        { key: "progress.text", value: "Attempting to fetch missing numbers from store pages..." },
        { key: "progress.step", value: 0 },
        { key: "progress.max", value: booksWithMissingNumber.length },
        { key: "progress.bar", value: true },
        { key: "subStep.step", add: 1 }
      ]);
      let vue = this;
      vue.amapxios({
        requests: booksWithMissingNumber,
        returnCatch: true,
        step: function(response, stepCallback, request) {
          let seriesBook = null;
          const responseStatus = _.get(response, "status", 0);
          if (responseStatus >= 200 && responseStatus < 400) {
            let html2 = $($.parseHTML(response.data));
            let audible = html2.find("div.adbl-main")[0];
            html2 = null;
            if (audible && audible.querySelector('[id^="sample-player-"] > button')) {
              const serieslEl = audible.querySelector(".seriesLabel");
              let bookSeries = vue.getSeries(serieslEl);
              if (bookSeries)
                bookSeries = _.find(bookSeries, { asin: request.seriesAsin });
              const bookNumbers = _.get(bookSeries, "bookNumbers");
              if (bookNumbers) {
                seriesBook = {
                  seriesAsin: request.seriesAsin,
                  asin: request.bookAsin,
                  bookNumbers: _.isArray(bookNumbers) ? bookNumbers.join(",") : bookNumbers
                };
              }
            }
          }
          vue.$store.commit("update", { key: "progress.step", add: 1 });
          stepCallback(seriesBook);
        },
        flatten: true,
        done: function(newBooks) {
          newBooks = _.omitBy(newBooks, _.isNull);
          _.each(newBooks, function(newBook) {
            let targetSeries = _.find(series, { asin: newBook.seriesAsin });
            if (targetSeries) {
              let targetBook = _.find(targetSeries.allBooks, { asin: newBook.asin });
              if (targetBook)
                targetBook.bookNumbers = newBook.bookNumbers;
            }
          });
          waterfallback(null, series);
        }
      });
    },
    fetchMissingNumbers: function(missingNumbers, series, parentStepCallback) {
      let vue = this;
      vue.amapxios({
        requests: _.map(missingNumbers, function(book) {
          return {
            requestUrl: window.location.origin + "/pd/" + book.asin,
            seriesAsin: series.asin,
            bookAsin: book.asin
          };
        }),
        step: function(response, stepCallback, request) {
          let seriesBook = null;
          const responseStatus = _.get(response, "status", 0);
          if (responseStatus >= 200 && responseStatus < 400) {
            let html2 = $($.parseHTML(response.data));
            let audible = html2.find("div.adbl-main")[0];
            html2 = null;
            if (audible && audible.querySelector('[id^="sample-player-"] > button')) {
              const serieslEl = audible.querySelector(".seriesLabel");
              let bookSeries = vue.getSeries(serieslEl);
              if (bookSeries)
                bookSeries = _.find(bookSeries, { asin: request.seriesAsin });
              const bookNumbers = _.get(bookSeries, "bookNumbers");
              if (bookNumbers) {
                seriesBook = {
                  seriesAsin: request.seriesAsin,
                  asin: request.bookAsin,
                  bookNumbers: _.isArray(bookNumbers) ? bookNumbers.join(",") : bookNumbers
                };
              }
            }
          }
          console.log("missing numbers step done!");
          stepCallback(seriesBook);
        },
        flatten: true,
        done: function(newBooks) {
          _.each(newBooks, function(newBook) {
            let targetBook = _.find(series.allBooks, { asin: newBook.asin });
            if (targetBook)
              targetBook.bookNumbers = newBook.bookNumbers;
          });
          console.log("Fetched missing numbers!");
          vue.$store.commit("update", { key: "progress.step", add: 1 });
          parentStepCallback(series);
        }
      });
    }
  }
};
var getDataFromCollections = {
  methods: {
    getDataFromCollections: function(hotpotato, collectionsFetched) {
      if (!_.find(hotpotato.config.steps, { name: "collections" })) {
        this.$store.commit("resetProgress");
        collectionsFetched(null, hotpotato);
      } else {
        this.$store.commit("update", [
          { key: "bigStep.step", value: 0 }
        ]);
        this.$store.commit("update", [
          { key: "bigStep.title", value: "Collections" },
          { key: "bigStep.step", add: 1 },
          { key: "progress.text", value: "Fetching collections..." },
          { key: "progress.step", value: 0 },
          { key: "progress.max", value: 0 },
          { key: "progress.bar", value: true }
        ]);
        const vue = this;
        waterfall(
          [
            function(callback) {
              vue.uniteBooksInCollections(hotpotato, callback);
            },
            vue.fetchCollectionDetails
          ],
          function(err, responses) {
            hotpotato.collections = responses;
            vue.$store.commit("resetProgress");
            vue.$nextTick(function() {
              collectionsFetched(null, hotpotato);
            });
          }
        );
      }
    },
    uniteBooksInCollections: function(hotpotato, waterfallback) {
      const booksInCollections = _.filter(hotpotato.books, "collectionIds");
      const collections = [];
      const vue = this;
      _.each(booksInCollections, function(book) {
        _.each(book.collectionIds, function(collectionId) {
          let collection = _.find(collections, { id: collectionId });
          if (!collection) {
            collection = {
              id: collectionId,
              url: vue.collectionsUrl + "/" + collectionId,
              books: []
            };
            collections.push(collection);
            vue.$store.commit("update", { key: "progress.max", add: 1 });
          }
          if (collection)
            collection.books.push(book.asin);
        });
      });
      waterfallback(null, collections);
    },
    fetchCollectionDetails: function(collections, waterfallback) {
      const vue = this;
      this.amapxios({
        requests: collections,
        step: function(response, stepCallback, request) {
          const audible = $($.parseHTML(response.data)).find("div.adbl-main")[0];
          let title = audible.querySelector("#center-3 > div.bc-container > div > div > span > ul > li:nth-child(1) > span.bc-text.bc-size-headline2");
          if (title)
            title = title.textContent;
          if (title)
            request.title = title;
          let description = audible.querySelector("#center-3 > div.bc-container > div > div > span > ul > li.bc-list-item.summaryLabel.bc-spacing-s0_5 > span");
          if (description)
            description = description.textContent;
          if (description)
            request.description = description;
          vue.$store.commit("update", { key: "progress.step", add: 1 });
          stepCallback(request);
        },
        flatten: true,
        done: function(collections2) {
          _.each(collections2, function(collection) {
            if (collection.url)
              delete collection.url;
          });
          waterfallback(null, collections2);
        }
      });
    },
    getFirstLevelCollectionData: function(requests, callback) {
      const vue = this;
      vue.$store.commit("update", [
        { key: "progress.text", value: "Fetching collections..." },
        { key: "progress.step", value: 0 },
        { key: "progress.max", value: 0 },
        { key: "progress.bar", value: true }
      ]);
      vue.amapxios({
        requests,
        step: function(response, stepCallback) {
          vue.scrapeFirstLevelCollectionData(response, stepCallback);
        },
        flatten: true,
        done: function(collections) {
          callback(null, collections);
        }
      });
    },
    scrapeFirstLevelCollectionData: function(response, completeStep) {
      const vue = this;
      const audible = $($.parseHTML(response.data)).find("div.adbl-main")[0];
      response.data = null;
      const collections = [];
      const collectionRows = audible.querySelectorAll("#adbl-lib-col-main > .adbl-library-collection-row");
      each(collectionRows, function(_thisRow) {
        const previewGridHasItems = _thisRow.querySelector(".product-image-grid-container:not(.empty-product-image-grid)");
        if (previewGridHasItems) {
          let collection = {};
          const id = _thisRow.getAttribute("data-collection-id");
          collection.id = DOMPurify.sanitize(id);
          const title = _thisRow.querySelector(".bc-size-headline3");
          if (title)
            collection.title = DOMPurify.sanitize(title.textContent);
          const description = _thisRow.querySelector("ul .bc-text.bc-size-body.bc-color-secondary");
          if (description)
            collection.description = DOMPurify.sanitize(description.textContent);
          collection.books = [];
          collections.push(collection);
        }
        vue.$store.commit("update", { key: "progress.max", add: 1 });
      });
      completeStep(collections);
    },
    getAllCollectionBookPages: function(collections, waterfallback) {
      const vue = this;
      _.each(collections, function(collection) {
        collection.url = vue.collectionsUrl + "/" + collection.id + "?pageSize=50";
      });
      vue.amapxios({
        requests: collections,
        step: function(response, stepCallback, request) {
          vue.scrapingPrep({
            url: response.request.responseURL || request.url,
            skipFirstCall: true,
            response,
            done: function(prep) {
              vue.$store.commit("update", { key: "progress.max", add: 1 });
              request.pageNumbers = prep.pageNumbers;
              request.pageSize = prep.pageSize;
              request.url = prep.urlObj.toString();
              stepCallback(request);
            }
          });
        },
        flatten: true,
        done: function(responses, err) {
          let requestUrls = [];
          if (!err) {
            _.each(responses, function(request) {
              _.each(request.pageNumbers, function(page) {
                const requestDolly = JSON.parse(JSON.stringify(request));
                let url = new Url(DOMPurify.sanitize(requestDolly.url));
                url.query.page = page;
                url.query.pageSize = request.pageSize;
                requestDolly.url = url.toString();
                requestUrls.push(requestDolly);
              });
            });
          } else
            console.log(err);
          waterfallback(null, requestUrls, responses);
        }
      });
    },
    getFirstLevelCollectionPages: function(callback) {
      this.scrapingPrep({
        url: this.collectionsUrl,
        done: function(prep) {
          const requestURLS = _.map(prep.pageNumbers, function(page) {
            prep.urlObj.query.page = page;
            return prep.urlObj.toString();
          });
          callback(null, requestURLS);
        }
      });
    }
  }
};
var getDataFromWishlist = {
  methods: {
    getDataFromWishlist: function(hotpotato, wishlistFetched) {
      if (!_.find(hotpotato.config.steps, { name: "wishlist" })) {
        this.$store.commit("resetProgress");
        wishlistFetched(null, hotpotato);
      } else {
        this.$store.commit("update", [
          { key: "bigStep.step", value: 0 }
        ]);
        this.$store.commit("update", [
          { key: "bigStep.title", value: "Wishlist" },
          { key: "bigStep.step", add: 1 },
          { key: "subStep.step", value: 1 },
          { key: "subStep.max", value: 2 },
          { key: "progress.text", value: this.$store.state.storageHasData.wishlist ? "Updating old books and adding new books..." : "Scanning wishlist for books..." },
          { key: "progress.step", value: 0 },
          { key: "progress.max", value: 0 }
        ]);
        const vue = this;
        waterfall(
          [
            function(callback) {
              vue.scrapingPrep({
                url: vue.wishlistUrl,
                returnResponse: true,
                returnAfterFirstCall: true,
                done: function(prep) {
                  const html2 = _.get(prep, "response.data");
                  if (!html2)
                    callback(null, prep);
                  const audible = $($.parseHTML(html2)).find("div.adbl-main")[0];
                  const wishlistLengthEl = audible.querySelector(".adbl-library-refinement-section > div:nth-child(1) span");
                  let wishlistLength = wishlistLengthEl ? wishlistLengthEl.textContent : null;
                  if (wishlistLength)
                    wishlistLength = parseFloat(DOMPurify.sanitize(wishlistLength.match(/\d+/)[0]));
                  delete prep.response;
                  const pagesLength = prep.pageSize ? Math.ceil(wishlistLength / prep.pageSize) : 1;
                  prep.pageNumbers = _.range(1, pagesLength + 1);
                  callback(null, prep);
                }
              });
            },
            function(prep, callback) {
              vue.amapxios({
                requests: _.map(prep.pageNumbers, function(page) {
                  prep.urlObj.query.page = page;
                  return prep.urlObj.toString();
                }),
                step: function(response, stepCallback) {
                  vue.getBooksWishlist(response, hotpotato, stepCallback);
                },
                flatten: true,
                done: function(books) {
                  callback(null, books);
                }
              });
            }
          ],
          function(err, books) {
            if (books.length)
              hotpotato.wishlist = books;
            vue.$nextTick(function() {
              hotpotato.config.getStorePages = "wishlist";
              wishlistFetched(null, hotpotato);
            });
          }
        );
      }
    },
    getBooksWishlist: function(response, hotpotato, completeStep) {
      let vue = this;
      const audible = $($.parseHTML(response.data)).find("div.adbl-main")[0];
      response.data = null;
      const wishlist = [];
      const wishlistRows = audible.querySelectorAll("#adbl-library-content-main li.productListItem");
      $(wishlistRows).each(function() {
        const _thisRow = this;
        let asin = _thisRow.querySelector("[data-asin]");
        if (asin)
          asin = asin.getAttribute("data-asin");
        if (!asin) {
          asin = _thisRow.querySelector('[id^="product-list-flyout-"]');
          if (asin)
            asin = asin.getAttribute("id").replace("product-list-flyout-", "");
        }
        asin = DOMPurify.sanitize(asin);
        let carryOnMyWaywardPines = hotpotato.books ? !_.find(hotpotato.books, { asin }) : true;
        if (carryOnMyWaywardPines) {
          let bookInMemory = _.find(hotpotato.wishlist, ["asin", asin]);
          let fullScan_ALL_partialScan_NEW = vue.$store.state.storageHasData.wishlist && !bookInMemory || !vue.$store.state.storageHasData.wishlist;
          let book = vue.$store.state.storageHasData.wishlist && bookInMemory ? bookInMemory : {};
          book.asin = asin;
          let title = _thisRow.querySelector(":scope > div:nth-child(1) > div > div > div > div > div > span > ul > li:nth-child(1) > a");
          if (title) {
            let bookAddress = title.getAttribute("href");
            bookAddress = DOMPurify.sanitize(bookAddress);
            let storePageUrl = new Url(window.location.origin + bookAddress);
            storePageUrl.clearQuery();
            book.storePageRequestUrl = storePageUrl.toString();
          }
          if (fullScan_ALL_partialScan_NEW) {
            const subtitle = _thisRow.querySelector(":scope > div:nth-child(1) > div > div > div > div > div > span > ul > li:nth-child(2) > span.bc-color-secondary");
            if (subtitle)
              book.subtitle = DOMPurify.sanitize(subtitle.textContent.trimAll());
            if (title) {
              title = title.textContent.trimAll();
              book.titleShort = DOMPurify.sanitize(title);
              book.title = book.subtitle ? title + ": " + book.subtitle : title;
            }
            const coverWrapper = _thisRow.querySelector('[data-trigger^="product-list-flyout"]');
            if (coverWrapper) {
              const coverLink = coverWrapper.querySelector(":scope > a");
              if (coverLink) {
                let coverUrl = coverLink.getAttribute("src");
                coverUrl = DOMPurify.sanitize(coverUrl);
                if (coverUrl.lastIndexOf("img-coverart-prod-unavailable") < 0) {
                  let coverId = coverUrl.match(/\/images\/I\/(.*)._SL/);
                  coverId = _.get(coverId, "[1]");
                  if (coverId)
                    book.cover = coverId;
                }
              }
            }
            const sample = _thisRow.querySelector("[data-mp3]");
            if (sample)
              book.sample = DOMPurify.sanitize(sample.getAttribute("data-mp3"));
            const series = _thisRow.querySelector(".seriesLabel > span");
            if (series)
              book.series = vue.getSeries(series);
            const length = _thisRow.querySelector(".runtimeLabel > span");
            if (length)
              book.length = vue.shortenLength(length.textContent);
            const releaseDate = _thisRow.querySelector(".releaseDateLabel > span");
            if (releaseDate)
              book.releaseDate = vue.fixDates(releaseDate);
            const authors = _thisRow.querySelectorAll(".authorLabel > a");
            if (authors.length > 0)
              book.authors = vue.getArray(authors);
            const narrators = _thisRow.querySelectorAll(".narratorLabel > a");
            if (narrators.length > 0)
              book.narrators = vue.getArray(narrators);
            const language = _thisRow.querySelector(".languageLabel");
            if (language)
              book.language = DOMPurify.sanitize(language.textContent.trimToColon());
          }
          const ratingsWrappers = _thisRow.querySelector(".ratingsLabel");
          if (ratingsWrappers) {
            const starsWrapper = _thisRow.querySelector(".bc-review-stars");
            const ratingSpan = starsWrapper.nextElementSibling;
            const ratingsSpan = ratingSpan.nextElementSibling;
            book.rating = Number(DOMPurify.sanitize(ratingSpan.textContent.match(/^\d\.?(\d)?/g)));
            book.ratings = parseFloat(DOMPurify.sanitize(ratingsSpan.textContent.match(/\d/g).join("")));
          }
          const fromPlusCatalog = _thisRow.querySelector(".discovery-add-to-library-button");
          if (fromPlusCatalog)
            book.fromPlusCatalog = true;
          book = _.omitBy(book, _.isNull);
          if (vue.$store.state.storageHasData.books) {
            let newAddition = !bookInMemory;
            let newFromStorage = bookInMemory && bookInMemory.isNew;
            if (newAddition || newFromStorage)
              book.isNew = true;
          }
          if (fullScan_ALL_partialScan_NEW) {
            book.isNewThisRound = true;
            vue.$store.commit("update", { key: "progress.max", add: 1 });
          }
          wishlist.push(book);
        }
      });
      completeStep(wishlist);
    }
  }
};
var getDataFromPurchaseHistory = {
  methods: {
    getDataFromPurchaseHistory: function(hotpotato, libraryPagesFetched) {
      const vue = this;
      vue.scrapingPrep({
        url: vue.purchaseHistoryUrl,
        maxSize: 20,
        done: function(prep) {
          prep.urlObj.toString();
          console.log(prep);
        }
      });
    }
  }
};
const _sfc_main$1 = {
  mixins: [
    timeStringToSeconds,
    secondsToTimeString,
    amapxios,
    scrapingPrep,
    getDataFromLibraryPages,
    getDataFromStorePages,
    getISBNsFromGoogleBooks,
    getDataFromCarousel,
    getDataFromSeriesPages,
    getDataFromCollections,
    getDataFromWishlist,
    getDataFromPurchaseHistory,
    helpers
  ],
  data: function() {
    return {
      store: this.$store.state,
      libraryUrl: window.location.origin + "/library/titles",
      libraryUrlFin: window.location.origin + "/library/titles?isFinished=true",
      seriesUrl: window.location.origin + "/series",
      collectionsUrl: window.location.origin + "/library/collections",
      wishlistUrl: window.location.origin + "/library/wishlist",
      purchaseHistoryUrl: window.location.origin + "/account/purchase-history",
      domainExtension: window.location.hostname.replace("www.audible", ""),
      newBooks: [],
      library: {
        books: [],
        storePageMissing: []
      },
      ui: "menu-screen",
      doStorePageTest: [],
      doSeriesTest: []
    };
  },
  beforeMount: function() {
    this.$compEmitter.on("start-extraction", (o) => {
      this["init_step_" + o.step](o.config);
    });
    if (_.get(this.doStorePageTest, "length", 0) > 0)
      this.init_storePageTest();
    if (_.get(this.doSeriesTest, "length", 0) > 0)
      this.init_seriesPageTest();
  },
  methods: {
    init_step_extract: function(config) {
      const vue = this;
      chrome.storage.local.get(null).then((hotpotato) => {
        if (hotpotato.chunks && hotpotato.chunks.length)
          vue.glueFriesBackTogether(hotpotato);
        vue.ui = "scraping";
        vue.$nextTick(function() {
          hotpotato = hotpotato || {};
          if (hotpotato.books)
            config.oldBooksLength = hotpotato.books.length;
          hotpotato.config = config;
          const waterfallArray = [
            function(callback) {
              callback(null, hotpotato);
            },
            vue.getDataFromLibraryPages,
            vue.getDataFromStorePages,
            vue.getDataFromSeriesPages,
            vue.getDataFromCollections,
            function(hotpotato2, callback) {
              vue.saveExtractionSoFar(hotpotato2, (hotpotato3) => {
                vue.$store.commit("update", { key: "checkingWishlistAccess", value: true });
                vue.$store.commit("update", { key: "noWishlistAccess", value: false });
                vue.checkAccess({
                  to: vue.wishlistUrl,
                  success: function(e2) {
                    callback(null, hotpotato3);
                  },
                  failed: function(e2) {
                    console.log("wishlist error", _.get(e2, "response", e2));
                    vue.$store.commit("update", { key: "noWishlistAccess", value: true });
                  },
                  finally: function() {
                    vue.$store.commit("update", { key: "checkingWishlistAccess", value: false });
                  }
                });
              });
            },
            vue.getDataFromWishlist,
            vue.getDataFromStorePages,
            function(hotpotato2, callback) {
              vue.saveExtractionSoFar(hotpotato2, (hotpotato3) => {
                callback(null, hotpotato3);
              });
            },
            vue.getISBNsFromGoogleBooks
          ];
          const maxSteps = config.steps ? _.filter(config.steps, function(o) {
            return o.value;
          }).length : waterfallArray.length - 1;
          vue.$store.commit("update", { key: "bigStep.max", value: maxSteps });
          waterfall(waterfallArray, function(err, hotpotato2) {
            vue.$store.commit("resetProgress");
            vue.$store.commit("update", [
              { key: "bigStep.title", value: "Opening the gallery after packing up the data..." },
              { key: "bigStep.step", value: 0 },
              { key: "bigStep.max", value: 0 },
              { key: "subStep.step", value: 0 },
              { key: "subStep.max", value: 0 }
            ]);
            vue.goToOutputPage(hotpotato2);
          });
        });
      });
    },
    init_step_update: function(config) {
      config.partialScan = true;
      config.steps = [{ name: "library", value: true }];
      this.init_step_extract(config);
    },
    init_step_output: function(config) {
      let newData = { config, extras: { "domain-extension": this.domainExtension } };
      chrome.storage.local.set(newData).then(() => {
        this.goToOutputPage({ useStorageData: true });
      });
    },
    outputCleanup(hotpotato) {
      let collections = hotpotato.collections;
      let archive = collections ? _.find(collections, { id: "__ARCHIVE" }) : null;
      if (archive)
        archive.description = "";
      let removeStragglers = function(key) {
        if (hotpotato[key]) {
          _.each(hotpotato[key], function(book) {
            if (book.storePageRequestUrl)
              delete book.storePageRequestUrl;
            if (book.isNewThisRound)
              delete book.isNewThisRound;
            if (book.requestUrl)
              delete book.requestUrl;
            if (key === "books" && book.asin && _.get(archive, "books.0")) {
              let bookInArchive = _.includes(archive.books, book.asin);
              if (bookInArchive)
                book.archived = true;
            }
          });
        }
      };
      removeStragglers("books");
      removeStragglers("wishlist");
      if (_.get(hotpotato, "books.0") && _.get(hotpotato, "wishlist.0")) {
        _.remove(hotpotato.wishlist, function(book) {
          if (book.asin)
            return _.find(hotpotato.books, { asin: book.asin });
        });
      }
    },
    saveExtractionSoFar(hotpotato, callback) {
      let vue = this;
      this.outputCleanup(hotpotato);
      if (hotpotato.config) {
        if (hotpotato.config.steps || hotpotato.config.extraSettings) {
          let steps = hotpotato.config.steps;
          let extraSettings = hotpotato.config.extraSettings;
          hotpotato.config = {};
          if (steps)
            hotpotato.config.steps = steps;
          if (extraSettings)
            hotpotato.config.extraSettings = extraSettings;
        }
      }
      this.addDataVersions(hotpotato);
      if (!hotpotato.chunks) {
        if (hotpotato.books)
          this.addedOrder(hotpotato.books);
        if (hotpotato.wishlist)
          this.addedOrder(hotpotato.wishlist);
        this.makeFrenchFries(hotpotato);
      }
      chrome.storage.local.clear().then(() => {
        chrome.storage.local.set(hotpotato).then(() => {
          if (_.get(hotpotato, "chunks.0"))
            vue.glueFriesBackTogether(hotpotato);
          callback(hotpotato);
        });
      });
    },
    goToOutputPage: function(hotpotato) {
      const pageAddress = window.location.origin + window.location.pathname;
      this.$store.commit("update", { key: "sticky.openOnLoad", value: true });
      if (hotpotato.useStorageData) {
        chrome.runtime.sendMessage({ action: "openOutput", url: pageAddress });
      } else {
        this.saveExtractionSoFar(hotpotato, () => {
          chrome.runtime.sendMessage({ action: "openOutput", url: pageAddress });
        });
      }
    },
    addDataVersions: function(hotpotato) {
      if (!_.isObject(hotpotato.version))
        hotpotato.version = {};
      let hasData = this.store.storageHasData;
      let version = chrome.runtime.getManifest().version;
      if (_.find(_.get(hotpotato, "config.steps"), { name: "library", value: true }) && !hasData.books)
        hotpotato.version.library = version;
      if (_.find(_.get(hotpotato, "config.steps"), { name: "collections", value: true }) && !hasData.collections)
        hotpotato.version.collections = version;
      if (_.find(_.get(hotpotato, "config.steps"), { name: "wishlist", value: true }) && !hasData.wishlist)
        hotpotato.version.wishlist = version;
    },
    init_purchaseHistoryTest: function() {
      const hotpotato = {
        config: { test: true, getStorePages: "books" }
      };
      this.getDataFromPurchaseHistory(hotpotato, function(nullBoy, result) {
        console.log(
          "%cPurchase history test",
          "background: #00bb1e; color: #fff; padding: 2px 5px; border-radius: 8px;",
          result
        );
      });
    },
    init_storePageTest: function() {
      const vue = this;
      console.log("%casdfasdf", "background: green; color: #fff; padding: 2px 5px; border-radius: 8px;", this.doStorePageTest);
      const hotpotato = {
        config: { test: true, getStorePages: "books", seriesTest: true },
        books: this.doStorePageTest
      };
      console.log("%casdfasdf", "background: orange; color: #fff; padding: 2px 5px; border-radius: 8px;", hotpotato);
      const waterfallArray = [
        function(callback) {
          callback(null, hotpotato);
        },
        vue.getDataFromStorePages,
        vue.getDataFromSeriesPages
      ];
      console.log("waterfall", "waterfall");
      waterfall(waterfallArray, function(err, hotpotato2) {
        vue.$store.commit("resetProgress");
        vue.$store.commit("update", [
          { key: "bigStep.title", value: "Opening the gallery after packing up the data..." },
          { key: "bigStep.step", value: 0 },
          { key: "bigStep.max", value: 0 }
        ]);
        console.log(
          "%cStore page test",
          "background: #00bb1e; color: #fff; padding: 2px 5px; border-radius: 8px;",
          hotpotato2
        );
      });
    },
    init_seriesPageTest: function() {
      const vue = this;
      const hotpotato = {
        config: { seriesTest: true },
        books: this.doSeriesTest
      };
      vue.getDataFromSeriesPages(hotpotato, function(nullBoy, result) {
        console.log(
          "%cSeries page test",
          "background: #00bb1e; color: #fff; padding: 2px 5px; border-radius: 8px;",
          result.series
        );
      });
    },
    checkAccess: function(config) {
      config = config || {};
      axios.get(config.to).then(function() {
        if (config.success)
          config.success();
      }).catch(function(e2) {
        if (config.failed)
          config.failed(e2);
      }).then(function() {
        if (config.finally)
          config.finally();
      });
    }
  }
};
function _sfc_render$1(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_cont_menu_screen = __unplugin_components_0;
  const _component_cont_scraping_progress = __unplugin_components_1$3;
  const _component_cont_overlay = __unplugin_components_2$3;
  return openBlock(), createBlock(_component_cont_overlay, null, {
    default: withCtx(() => [
      _ctx.ui === "menu-screen" ? (openBlock(), createBlock(_component_cont_menu_screen, {
        key: 0,
        domainExtension: _ctx.domainExtension,
        wishlistUrl: _ctx.wishlistUrl
      }, null, 8, ["domainExtension", "wishlistUrl"])) : _ctx.ui === "scraping" ? (openBlock(), createBlock(_component_cont_scraping_progress, {
        key: 1,
        domainExtension: _ctx.domainExtension
      }, null, 8, ["domainExtension"])) : createCommentVNode("", true)
    ]),
    _: 1
  });
}
var App = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
var store = createStore({
  state: {
    appVersion: "0.2.9",
    localStorageName: "ale-content-script-settings",
    canceledRequests: [],
    progress: {
      text: null,
      textSuffix: null,
      text2: null,
      step: 0,
      max: 0,
      bar: false,
      thumbnail: null
    },
    bigStep: {
      title: "",
      step: 0,
      max: 0
    },
    subStep: {
      step: 0,
      max: 0
    },
    storageHasData: {
      books: null,
      isbn: null,
      wishlist: null,
      collections: null
    },
    toastOpts: {
      position: "top",
      duration: 4e3
    },
    storageConfig: {},
    dataVersion: null,
    extractBtnDisabled: false,
    extractionButtonDisabled: false,
    axiosRateLimit: {
      maxRequests: 10,
      perMilliseconds: 1e3
    },
    failedRequests: [],
    lastFailedRequestStatus: null,
    taking_a_break: false,
    noWishlistAccess: false,
    checkingWishlistAccess: false,
    sticky: {
      openOnLoad: false,
      extractSettings: [
        {
          label: "Library",
          name: "books",
          value: true,
          disabled: true,
          type: "is-success",
          tippy: "Library is required in order to extract collections and isbn.",
          trashTippy: "This will also remove Collections and ISBN data.",
          kind: "main",
          deleteChunks: ["books", "series", "collections"],
          partialData: true
        },
        {
          label: "Collections",
          name: "collections",
          parent: "books",
          value: true,
          disabled: false,
          type: "is-success",
          tippy: "Very quick extraction that just needs to check the first page of each collection to find out the title and description",
          kind: "main",
          partialData: true
        },
        {
          label: "Wishlist",
          name: "wishlist",
          value: false,
          disabled: false,
          type: "is-success",
          tippy: "Similar to library extraction but series order is not fetched. Books that also exist in your library are dropped off as long as you also extract library data.",
          kind: "main",
          partialData: true
        },
        {
          label: "ISBN",
          name: "isbn",
          parent: "books",
          value: false,
          disabled: false,
          type: "is-danger",
          tippy: "International Standard Book Numbers (ISBN) are required if you want to try importing your library to Goodreads. ISBNs are fetched for library books only. Very slow extraction time.",
          kind: "main",
          partialData: true
        },
        {
          name: "saveStandaloneAfter",
          value: false,
          label: "Start saving the standalone gallery immediately after extraction",
          kind: "extra"
        }
      ]
    }
  },
  mutations: {
    fromLocalStorage: function(state) {
      let lsState = localStorage.getItem(state.localStorageName);
      if (lsState && lsState != "undefined") {
        lsState = JSON.parse(lsState);
        const settings = _.map(lsState.extractSettings, function(o) {
          return {
            disabled: o.disabled,
            value: o.value
          };
        });
        lsState.extractSettings = [];
        _.merge(state.sticky, lsState);
        _.merge(state.sticky.extractSettings, settings);
      }
    },
    update(state, config) {
      let setValues = function(config2) {
        config2 = config2 || {};
        if (config2.key) {
          let newValue = config2.value;
          if (config2.add) {
            const oldValue = _.get(state, config2.key);
            newValue = (oldValue || 0) + config2.add;
          }
          newValue = config2.freeze ? Object.freeze(newValue) : newValue;
          _.set(state, config2.key, newValue);
        }
      };
      if (_.isArray(config)) {
        _.each(config, function(conf) {
          setValues(conf);
        });
      } else {
        setValues(config);
      }
    },
    resetProgress: function(state) {
      state.progress.text = null;
      state.progress.textSuffix = null;
      state.progress.text2 = null;
      state.progress.step = 0;
      state.progress.max = 0;
      state.progress.bar = false;
      state.progress.thumbnail = null;
    },
    pushToCanceledRequests: function(state, value) {
      state.canceledRequests.push(value);
    },
    updateSetting: function(state, o) {
      o = _.castArray(o);
      _.each(o, function(o2) {
        const setting = _.find(state.sticky.extractSettings, { name: o2.item.name });
        _.merge(setting, o2.obj);
      });
    },
    pushToFailedRequests(state, url) {
      state.failedRequests.push(url);
    }
  },
  getters: {
    settings_mainSteps: function(state) {
      return _.filter(state.sticky.extractSettings, { kind: "main" });
    },
    settings_extras: function(state) {
      return _.filter(state.sticky.extractSettings, { kind: "extra" });
    },
    mainDataExists: function(state) {
      return state.storageHasData.books || state.storageHasData.wishlist;
    },
    setting: (state) => (settingName) => {
      return _.find(state.sticky.extractSettings, { name: settingName });
    },
    partialDataSettings(state, getters) {
      const partalData_Settings = _.filter(getters.settings_mainSteps, { partialData: true });
      const keys = _.map(partalData_Settings, "name");
      const mainStepsData = _.map(keys, (settingKey) => {
        return _.get(state.storageHasData, settingKey);
      });
      return _.every(mainStepsData, true);
    },
    partialDataSettings(state, getters) {
      const partalData_Settings = _.filter(getters.settings_mainSteps, { partialData: true });
      const keys = _.map(partalData_Settings, "name");
      return _.map(keys, (settingKey) => {
        return _.get(state.storageHasData, settingKey);
      });
    },
    partialDataSettings_all(state, getters) {
      return _.every(getters.partialDataSettings, true);
    },
    partialDataSettings_any(state, getters) {
      return _.includes(getters.partialDataSettings, true);
    }
  }
});
const removeElement = (el) => {
  if (typeof el.remove !== "undefined") {
    el.remove();
  } else {
    el.parentNode.removeChild(el);
  }
};
class Timer {
  constructor(callback, delay) {
    this.startedAt = Date.now();
    this.callback = callback;
    this.delay = delay;
    this.timer = setTimeout(callback, delay);
  }
  pause() {
    this.stop();
    this.delay -= Date.now() - this.startedAt;
  }
  resume() {
    this.stop();
    this.startedAt = Date.now();
    this.timer = setTimeout(this.callback, this.delay);
  }
  stop() {
    clearTimeout(this.timer);
  }
}
const POSITIONS = {
  TOP_RIGHT: "top-right",
  TOP: "top",
  TOP_LEFT: "top-left",
  BOTTOM_RIGHT: "bottom-right",
  BOTTOM: "bottom",
  BOTTOM_LEFT: "bottom-left"
};
var Positions = Object.freeze(POSITIONS);
function definePosition(position, top, bottom) {
  let result = null;
  switch (position) {
    case POSITIONS.TOP:
    case POSITIONS.TOP_RIGHT:
    case POSITIONS.TOP_LEFT:
      result = top;
      break;
    case POSITIONS.BOTTOM:
    case POSITIONS.BOTTOM_RIGHT:
    case POSITIONS.BOTTOM_LEFT:
      result = bottom;
      break;
  }
  return result;
}
class Event {
  constructor() {
    this.queue = {};
  }
  $on(name, callback) {
    this.queue[name] = this.queue[name] || [];
    this.queue[name].push(callback);
  }
  $off(name, callback) {
    if (this.queue[name]) {
      for (var i2 = 0; i2 < this.queue[name].length; i2++) {
        if (this.queue[name][i2] === callback) {
          this.queue[name].splice(i2, 1);
          break;
        }
      }
    }
  }
  $emit(name, data) {
    if (this.queue[name]) {
      this.queue[name].forEach(function(callback) {
        callback(data);
      });
    }
  }
}
var eventBus = new Event();
var Toaster_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  name: "toast",
  props: {
    message: {
      type: String,
      required: true
    },
    type: {
      type: String,
      default: "default"
    },
    position: {
      type: String,
      default: Positions.BOTTOM_RIGHT,
      validator(value) {
        return Object.values(Positions).includes(value);
      }
    },
    maxToasts: {
      type: [Number, Boolean],
      default: false
    },
    duration: {
      type: [Number, Boolean],
      default: 4e3
    },
    dismissible: {
      type: Boolean,
      default: true
    },
    queue: {
      type: Boolean,
      default: false
    },
    pauseOnHover: {
      type: Boolean,
      default: true
    },
    useDefaultCss: {
      type: Boolean,
      default: true
    },
    onClose: {
      type: Function,
      default: () => {
      }
    },
    onClick: {
      type: Function,
      default: () => {
      }
    }
  },
  data() {
    return {
      isActive: false,
      parentTop: null,
      parentBottom: null,
      isHovered: false,
      timer: null
    };
  },
  beforeMount() {
    this.createParents();
    this.setDefaultCss();
    this.setupContainer();
  },
  mounted() {
    this.showNotice();
    eventBus.$on("toast-clear", this.close);
  },
  methods: {
    createParents() {
      this.parentTop = document.querySelector(".c-toast-container--top");
      this.parentBottom = document.querySelector(".c-toast-container--bottom");
      if (this.parentTop && this.parentBottom)
        return;
      if (!this.parentTop) {
        this.parentTop = document.createElement("div");
        this.parentTop.className = "c-toast-container c-toast-container--top";
      }
      if (!this.parentBottom) {
        this.parentBottom = document.createElement("div");
        this.parentBottom.className = "c-toast-container c-toast-container--bottom";
      }
    },
    setDefaultCss() {
      const type = this.useDefaultCss ? "add" : "remove";
      this.parentTop.classList[type]("v--default-css");
      this.parentBottom.classList[type]("v--default-css");
    },
    setupContainer() {
      const container = document.body;
      container.appendChild(this.parentTop);
      container.appendChild(this.parentBottom);
    },
    shouldQueue() {
      if (!this.queue && this.maxToasts === false) {
        return false;
      }
      if (this.maxToasts !== false) {
        return this.maxToasts <= this.parentTop.childElementCount + this.parentBottom.childElementCount;
      }
      return this.parentTop.childElementCount > 0 || this.parentBottom.childElementCount > 0;
    },
    showNotice() {
      if (this.shouldQueue()) {
        this.queueTimer = setTimeout(this.showNotice, 250);
        return;
      }
      this.correctParent.insertAdjacentElement("afterbegin", this.$el);
      this.isActive = true;
      this.timer = this.duration !== false ? new Timer(this.close, this.duration) : null;
    },
    click() {
      this.onClick.apply(null, arguments);
      if (this.dismissible) {
        this.close();
      }
    },
    toggleTimer(newVal) {
      if (this.timer && this.pauseOnHover) {
        newVal ? this.timer.pause() : this.timer.resume();
      }
    },
    stopTimer() {
      this.timer && this.timer.stop();
      clearTimeout(this.queueTimer);
    },
    close() {
      this.stopTimer();
      this.isActive = false;
      setTimeout(() => {
        this.onClose.apply(null, arguments);
        removeElement(this.$el);
      }, 150);
    }
  },
  computed: {
    correctParent() {
      return definePosition(this.position, this.parentTop, this.parentBottom);
    },
    transition() {
      return definePosition(
        this.position,
        {
          enter: "fadeInDown",
          leave: "fadeOut"
        },
        {
          enter: "fadeInUp",
          leave: "fadeOut"
        }
      );
    }
  },
  beforeUnmount() {
    eventBus.$off("toast-clear", this.close);
  }
};
const _hoisted_1 = ["innerHTML"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createBlock(Transition, {
    "enter-active-class": $options.transition.enter,
    "leave-active-class": $options.transition.leave
  }, {
    default: withCtx(() => [
      withDirectives(createBaseVNode("div", {
        class: normalizeClass(["c-toast", `c-toast--${$props.type}`, `c-toast--${$props.position}`]),
        onMouseover: _cache[0] || (_cache[0] = ($event) => $options.toggleTimer(true)),
        onMouseleave: _cache[1] || (_cache[1] = ($event) => $options.toggleTimer(false)),
        onClick: _cache[2] || (_cache[2] = (...args) => $options.click && $options.click(...args)),
        role: "alert",
        innerHTML: $props.message
      }, null, 42, _hoisted_1), [
        [vShow, $data.isActive]
      ])
    ]),
    _: 1
  }, 8, ["enter-active-class", "leave-active-class"]);
}
var Toaster = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const createElement = () => typeof document !== "undefined" && document.createElement("div");
const mount = (component, { props, children, element, app: app2 } = {}) => {
  let el = element ? element : createElement();
  let vNode = h(component, props, children);
  if (app2 && app2._context) {
    vNode.appContext = app2._context;
  }
  render$a(vNode, el);
  const destroy = () => {
    if (el) {
      render$a(null, el);
    }
    el = null;
    vNode = null;
  };
  return { vNode, destroy, el };
};
const Api = (globalOptions = {}) => {
  return {
    show(message, options = {}) {
      let localOptions = { message, ...options };
      const c2 = mount(Toaster, {
        props: { ...globalOptions, ...localOptions }
      });
      return c2;
    },
    clear() {
      eventBus.$emit("toast-clear");
    },
    success(message, options = {}) {
      options.type = "success";
      return this.show(message, options);
    },
    error(message, options = {}) {
      options.type = "error";
      return this.show(message, options);
    },
    info(message, options = {}) {
      options.type = "info";
      return this.show(message, options);
    },
    warning(message, options = {}) {
      options.type = "warning";
      return this.show(message, options);
    }
  };
};
const Plugin = (app2, options = {}) => {
  let methods = Api(options);
  app2.$toast = methods;
  app2.config.globalProperties.$toast = methods;
};
Toaster.install = Plugin;
chrome.runtime.sendMessage({ pageAction: true });
window.$ = $$1;
window._ = _$1;
window.axios = axios$2;
window.exponentialDelay = exponentialDelay;
window.isNetworkOrIdempotentRequestError = isNetworkOrIdempotentRequestError;
window.axiosRetry = axiosRetry$1;
window.dateFormat = format;
window.DOMPurify = purify;
window.asyncMap = map$1;
window.asyncMapLimit = mapLimit$1;
window.waterfall = waterfall$2;
window.Url = Url$1;
String.prototype.trimAll = function() {
  if (this) {
    return this.trim().replace(/\s+/g, " ");
  } else {
    return null;
  }
};
String.prototype.trimToColon = function() {
  if (this) {
    return this.substring(this.indexOf(":") + 1).trim();
  } else {
    return null;
  }
};
window.each = function(array, callback) {
  if (!array)
    return null;
  for (var i2 = 0; i2 < array.length; i2++) {
    callback(array[i2], i2);
  }
};
store.commit("fromLocalStorage");
store.subscribe(function(mutation, state) {
  let payload = _$1.get(mutation, "payload");
  payload = _$1.castArray(payload);
  if (mutation.type === "updateSetting") {
    localStorage.setItem(state.localStorageName, JSON.stringify(state.sticky));
    return;
  }
  const storingSticky = _$1.find(payload, (o) => _$1.get(o, "key", "").match(/^sticky./));
  if (storingSticky)
    localStorage.setItem(state.localStorageName, JSON.stringify(state.sticky));
});
const app = createApp(App);
app.config.globalProperties.$compEmitter = new mitt();
app.config.globalProperties.$dataChecker = function(data, store2) {
  store2 = this.$store || store2;
  const dataChunks = _$1.get(data, "chunks", []);
  dataChunks.length > 0;
  store2.commit("update", [
    { key: "storageHasData.books", value: dataChunks.indexOf("books") > -1 },
    { key: "storageHasData.isbn", value: dataChunks.indexOf("isbn") > -1 ? checkISBNs(data) : false },
    { key: "storageHasData.wishlist", value: dataChunks.indexOf("wishlist") > -1 },
    { key: "storageHasData.collections", value: dataChunks.indexOf("collections") > -1 },
    { key: "storageConfig", value: data.config || {} },
    { key: "dataVersion", value: data.version || null }
  ]);
  function checkISBNs(data2) {
    let foundISBNs = false;
    _$1.each(_$1.range(0, data2["books-chunk-length"]), function(index) {
      const booksChunk = data2["books-chunk-" + index];
      const isbns = _$1.find(booksChunk, "isbns");
      if (isbns) {
        foundISBNs = true;
        return false;
      }
    });
    return foundISBNs;
  }
};
app.use(Toaster);
app.use(VueTippy, {
  directive: "tippy",
  component: "tippy",
  componentSingleton: "tippy-singleton",
  defaultProps: {
    placement: "auto-end",
    allowHTML: true,
    arrow: true,
    placement: "top",
    trigger: "mouseenter focus",
    theme: "light-border",
    zIndex: 9999999991,
    delay: [500, 0],
    a11y: false,
    maxWidth: 670,
    onShow: (options) => {
      return !!options.props.content;
    },
    boundary: "viewport",
    flipDuration: 0
  }
});
app.config.productionTip = false;
app.config.devtools = false;
let overlayBtnLink = $$1("<a>", {
  id: "audible-library-extractor-btn",
  class: "bc-link bc-tab-heading bc-inline-block bc-tab-lens bc-size-title1 bc-color-secondary",
  tabindex: "0",
  role: "tab",
  "aria-selected": false,
  href: "#",
  text: "Audible Library Extractor",
  css: {
    height: "33px",
    lineHeight: "33px",
    fontSize: "14px",
    padding: "0 4px 0 15px",
    borderRadius: "4px",
    textDecoration: "none",
    background: "#f7991c",
    color: "#fff",
    boxShadow: "0 2px 4px rgb(0 0 0 / 10%), 0 2px 10px rgb(0 0 0 / 10%)",
    display: "inline-flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    fontWeight: "900",
    width: "232px",
    margin: "10px 0px -8px"
  }
});
let librarySpot = $$1(".library-header-divider").next().find("#lib-subheader-actions");
librarySpot.css({
  display: "flex",
  flexDirection: "column",
  alignItems: "stretch",
  justifyContent: "center"
});
overlayBtnLink.appendTo(librarySpot);
$$1("#center-2 > div > div").css({ marginTop: "10px" });
librarySpot.parent().css({
  display: "flex",
  flexDirection: "row",
  alignItems: "flex-end",
  justifyContent: "flex-start"
});
let chevronIcon = $$1("<i>", {
  class: "bc-icon bc-icon-fill-base bc-icon-chevron-right-s4 bc-icon-chevron-right bc-icon-size-large bc-color-base",
  ariaHidden: "true"
});
chevronIcon[0].setAttribute("style", "font-weight: 900 !important");
chevronIcon.css({
  verticalAlign: "center",
  color: "white",
  fontSize: "23px",
  width: "28px",
  height: "28px",
  display: "inline-flex",
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "center"
});
chevronIcon.appendTo(overlayBtnLink);
$$1("#audible-library-extractor-btn").on("click", function(e2) {
  e2.preventDefault();
  chrome.storage.local.get(null).then((data) => {
    audibleLibraryExtractor(data);
  });
});
console.log("store.state.sticky.openOnLoad", store.state.sticky.openOnLoad);
if (store.state.sticky.openOnLoad) {
  chrome.storage.local.get(null).then((data) => {
    store.commit("update", { key: "sticky.openOnLoad", value: false });
    audibleLibraryExtractor(data);
  });
}
chrome.runtime.onMessage.addListener((message) => {
  if (message.iconClicked) {
    chrome.storage.local.get(null).then((data) => {
      audibleLibraryExtractor(data);
    });
  }
});
function audibleLibraryExtractor(data) {
  $$1("<div>", { id: "audible-library-extractor" }).prependTo("body");
  app.config.globalProperties.$dataChecker(data, store);
  app.directive("visible", function(el, binding) {
    el.style.visibility = !!binding.value ? "visible" : "hidden";
  });
  app.use(store);
  app.mount("#audible-library-extractor");
}
//# sourceMappingURL=content-script.f585a343.js.map
