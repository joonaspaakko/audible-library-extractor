(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.b12f63d8.js")
    );
  })().catch(console.error);

})();
