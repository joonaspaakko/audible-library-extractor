import { z as _, _ as _export_sfc, o as openBlock, c as createElementBlock, n as normalizeStyle, e as createCommentVNode, i as createBlock, k as withCtx, x as createTextVNode, t as toDisplayString, m as resolveDynamicComponent, a as createBaseVNode, F as Fragment, j as renderList, g as normalizeClass } from "./lodash.1321b47a.js";
import { m as makeCoverUrl } from "./gallery-makeCoverUrl.8378190f.js";
var utilities = {
  methods: {
    loadImage: function(url, callback) {
      var img = new Image();
      img.onload = function() {
        callback(this);
      };
      img.src = url;
    },
    getRandomCovers: function(arr, n) {
      var result = new Array(n), len = arr.length, taken = new Array(len);
      if (n > len)
        throw new RangeError("getRandom: more elements taken than available");
      while (n--) {
        var x = Math.floor(Math.random() * len);
        result[n] = arr[x in taken ? taken[x] : x];
        taken[x] = --len in taken ? taken[len] : len;
      }
      return result;
    },
    splitUnevenly: function(number, parts, min) {
      var randombit = number - min * parts;
      var out = [];
      for (var i = 0; i < parts; i++) {
        out.push(Math.random());
      }
      var mult = randombit / out.reduce(function(a, b) {
        return a + b;
      });
      return out.map(function(el) {
        return el * mult + min;
      });
    },
    random: function(min, max) {
      min = Math.ceil(min);
      max = Math.floor(max);
      return Math.floor(Math.random() * (max - min + 1)) + min;
    },
    toMS: function(seconds) {
      return seconds * 1e3;
    },
    toSec: function(milliseconds) {
      return milliseconds / 1e3;
    },
    imageLoader: function(Images, Callback) {
      let vue = this;
      var allLoaded = 0;
      var _log = {
        success: [],
        error: []
      };
      var verifier = function() {
        allLoaded++;
        if (allLoaded == Images.length) {
          Callback.apply(vue, _log);
        }
      };
      for (var index = 0; index < Images.length; index++) {
        (function(i) {
          var imgSource = Images[i];
          var img = new Image();
          img.addEventListener("load", function() {
            _log.success.push(imgSource);
            verifier();
            img = null;
          }, { passive: true, once: true });
          img.addEventListener("error", function() {
            _log.error.push(imgSource);
            verifier();
            img = null;
          }, { passive: true, once: true });
          img.src = imgSource;
        })(index);
      }
    }
  }
};
var presets = {
  data: function() {
    return {
      presets: [
        {
          name: "all-animations-random",
          description: "...",
          onLoad: true,
          use: false,
          cycleDelay: 10,
          covers: 3,
          randomCovers: false,
          animationZone: 50,
          randomDelay: true,
          sequential: false
        },
        {
          name: "sliding-around-randomly",
          description: "Animates one cover at a time sequentially.",
          onLoad: false,
          use: ["push-left", "push-right", "push-up", "push-down", "squish-left", "squish-right", "squish-up", "squish-down"],
          covers: 3,
          randomCovers: false,
          cycleDelay: 7,
          animationZone: 60,
          randomDelay: true,
          sequential: false
        },
        {
          name: "piano-key-swipe",
          description: "Animates one row at a time time.",
          onLoad: true,
          use: ["fade-in"],
          covers: "one-row",
          randomCovers: false,
          cycleDelay: 11,
          animationZone: 8,
          randomDelay: false,
          sequential: true
        },
        {
          name: "row-switcheroo",
          description: "Animates one row at a time time.",
          onLoad: false,
          use: ["fade-in"],
          covers: "one-row",
          randomCovers: false,
          cycleDelay: 11,
          animationZone: 0,
          randomDelay: false,
          sequential: true
        },
        {
          name: "random-simple-flips",
          description: "Randomly animates 1-6 covers every 5 seconds.",
          onLoad: false,
          use: ["flip-2-hor-top-2", "flip-2-ver-right-2", "flip-2-hor-bottom-2", "flip-2-ver-left-2"],
          cycleDelay: 10,
          covers: 3,
          randomCovers: false,
          animationZone: 50,
          randomDelay: true,
          sequential: false
        },
        {
          name: "raindrops",
          description: "...",
          onLoad: true,
          use: ["fade-in-top"],
          cycleDelay: 20,
          covers: "all",
          randomCovers: false,
          animationZone: 30,
          randomDelay: true,
          sequential: false
        },
        {
          name: "clear-all",
          description: 'Animates all covers every 15 seconds using "fade-in" animation.',
          onLoad: false,
          use: ["fade-in"],
          cycleDelay: 15,
          covers: "all",
          randomCovers: false,
          animationZone: 20,
          randomDelay: false,
          sequential: true
        }
      ]
    };
  }
};
var fitCoversToViewport = {
  methods: {
    fitCoversToViewport: function() {
      let canvas = {};
      if (!this.editorCovers) {
        canvas.width = window.innerWidth - this.canvas.padding.left - this.canvas.padding.right;
        canvas.height = window.innerHeight - this.canvas.padding.top - this.canvas.padding.bottom;
      } else {
        canvas.width = this.canvas.width - this.canvas.padding.left - this.canvas.padding.right;
        canvas.height = this.canvas.height - this.canvas.padding.top - this.canvas.padding.bottom;
      }
      const coversPadding = this.covers.padding * 2;
      if (!this.editorCovers && !this.prioritizeCoversPerRow) {
        this.covers.perRow = Math.round(canvas.width / (this.covers.sizeOriginal + coversPadding));
        this.covers.size = canvas.width / this.covers.perRow - coversPadding;
      } else {
        this.covers.size = canvas.width / this.covers.perRow - coversPadding;
      }
      const roundBoe = this.covers.dropOverflowingRow ? "floor" : "ceil";
      this.covers.rows = Math[roundBoe](canvas.height / (this.covers.size + coversPadding));
      this.covers.total = this.covers.rows * this.covers.perRow;
      if (this.editorCovers)
        this.$store.commit("update", { key: "visibleAnimatedCovers", value: this.covers.total });
      if (this.covers.total > this.covers.allOriginal.length)
        this.addMoreCovers();
      this.covers.all = _.shuffle(this.covers.all);
      this.covers.visible = this.getRandomCovers(this.covers.all, this.covers.total);
    },
    addMoreCovers: function() {
      let vue = this;
      this.covers.total;
      const loopLength = Math.ceil(this.covers.total / vue.covers.allOriginal.length);
      const loopRange = _.range(0, loopLength);
      let covers = [];
      _.each(loopRange, function() {
        covers = covers.concat(vue.covers.allOriginal);
      });
      let difference = Math.abs(this.covers.total - covers.length);
      if (difference)
        covers = _.dropRight(covers, difference);
      this.covers.all = covers;
    }
  }
};
var getAnimations = {
  methods: {
    getAnimations: function() {
      let vue = this;
      let animations = !this.animation.use ? this.animations : this.animations.filter(function(filterAnimation) {
        let ping = false;
        vue.animation.use.forEach(function(usedAnimation) {
          if (usedAnimation === filterAnimation.class) {
            ping = true;
            return false;
          }
        });
        return ping;
      });
      let availableAnimations = animations.filter(function(animation) {
        return animation.in;
      });
      let inIndex = this.random(0, availableAnimations.length - 1);
      return availableAnimations[inIndex];
    }
  }
};
var pickCoversToAnimate = {
  methods: {
    pickCoversToAnimate: function(visibleCovers, cycleDelay) {
      let animationCovers = this.getCoverAmount();
      let randomCoversAmount = this.animation.randomCovers ? this.random(1, animationCovers) : animationCovers;
      if (this.editorCovers) {
        this.$store.commit("update", { key: "awpAnimatedCoversLength", value: randomCoversAmount });
      }
      let picked;
      if (this.animation.sequential) {
        picked = [];
        for (var i = 0; i < randomCoversAmount; i++) {
          picked.push(visibleCovers[this.sequentialCounter]);
          if (this.sequentialCounter >= this.covers.total - 1) {
            this.sequentialCounter = 0;
          } else {
            ++this.sequentialCounter;
          }
        }
      } else {
        picked = this.getRandomCovers(visibleCovers, randomCoversAmount);
      }
      return picked;
    },
    getCoverAmount: function() {
      if (_.isNumber(this.animation.covers)) {
        return this.animation.covers;
      } else {
        switch (this.animation.covers) {
          case "one-row":
            return this.covers.perRow;
          case "all":
            return this.covers.total;
        }
      }
    }
  }
};
var prepareData = {
  mixins: [
    makeCoverUrl
  ],
  props: [
    "editorCoverSize",
    "editorCoverPadding",
    "editorCanvasWidth",
    "editorCanvasHeight",
    "editorCovers",
    "editorCoversPerRow",
    "editorCanvasPaddingLeft",
    "editorCanvasPaddingTop",
    "editorCanvasPaddingRight",
    "editorCanvasPaddingBottom"
  ],
  created: function() {
    if (this.editorCovers) {
      this.$emitter.on("get-animation", this.sendAnimation);
    }
  },
  beforeUnmount: function() {
    if (this.editorCovers) {
      this.$emitter.off("get-animation", this.sendAnimation);
    }
  },
  watch: {
    "editorCoversPerRow": function(value) {
      this.covers.perRow = value;
      this.startAutoPlay();
    },
    "editorCoverPadding": function(value) {
      this.covers.padding = value;
      this.startAutoPlay();
    },
    "editorCanvasPaddingLeft": function(value) {
      this.canvas.padding.left = value;
      this.startAutoPlay();
    },
    "editorCanvasPaddingTop": function(value) {
      this.canvas.padding.top = value;
      this.startAutoPlay();
    },
    "editorCanvasPaddingRight": function(value) {
      this.canvas.padding.right = value;
      this.startAutoPlay();
    },
    "editorCanvasPaddingBottom": function(value) {
      this.canvas.padding.bottom = value;
      this.startAutoPlay();
    },
    "editorCanvasWidth": function(value) {
      this.canvas.width = value;
      this.startAutoPlay();
    },
    "editorCanvasHeight": function(value) {
      this.canvas.height = value;
      this.startAutoPlay();
    },
    "$store.state.awpGrayscale": function(value) {
      this.canvas.grayscale = value;
      this.startAutoPlay();
    },
    "$store.state.awpGrayscaleContrast": function(value) {
      this.canvas.grayscaleContrast = value;
      this.startAutoPlay();
    },
    "$store.state.excludeArchived": function(value) {
      this.covers.allOriginal = value ? _.filter(this.editorCovers, function(o) {
        return !o.inArchive;
      }) : this.editorCovers;
      this.covers.allOriginal = _.map(this.covers.allOriginal, "cover");
      this.covers.all = this.covers.allOriginal;
      this.startAutoPlay();
    },
    "$store.state.animationPreset": function(value) {
      this.loadAnimationPreset(this.$store.state.animationPreset);
      this.updateStoreAnimation();
      this.startAutoPlay();
    },
    "$store.state.background": function(value) {
      this.canvas.background = value;
      this.startAutoPlay();
    },
    "$store.state.awpDropOverflowingRow": function(value) {
      this.covers.dropOverflowingRow = value;
      this.startAutoPlay();
    },
    "$store.state.canvas.alignmentVertical": function(value) {
      this.canvas.alignmentVertical = value;
    },
    "$store.state.awpCycleDelay": function(value) {
      this.animation.cycleDelay = value;
      this.startAutoPlay();
    },
    "$store.state.awpAnimationZone": function(value) {
      this.animation.animationZone = value;
      this.startAutoPlay();
    },
    "$store.state.awpAnimateOnLoad": function(value) {
      this.animation.onLoad = value;
      this.startAutoPlay();
    },
    "$store.state.awpAnimation": function(value) {
      this.animation.use = value;
      this.startAutoPlay();
    },
    "$store.state.awpCoversPerCycle": function(value) {
      this.$store.commit("update", { key: "awpAnimatedCoversLength", value: null });
      this.animation.covers = value;
      this.startAutoPlay();
    },
    "$store.state.awpRandomCovers": function(value) {
      this.animation.randomCovers = value;
      this.startAutoPlay();
    },
    "$store.state.awpRandomDelay": function(value) {
      this.animation.randomDelay = value;
      this.startAutoPlay();
    },
    "$store.state.awpSequential": function(value) {
      this.animation.sequential = value;
      this.startAutoPlay();
    }
  },
  methods: {
    sendAnimation: function() {
      this.$store.commit("update", { key: "animation", value: this.animation });
    },
    prepareData: function(callback) {
      if (this.editorCovers) {
        let presetsArray = _.map(this.presets, function(p) {
          return { label: _.lowerCase(p.name), value: p.name, description: p.description };
        });
        if (this.$store.state.animationPresets && this.$store.state.animationPreset) {
          let lsAnimationPresetExists = _.find(this.presets, { name: this.$store.state.animationPreset });
          if (!lsAnimationPresetExists)
            this.$store.commit("update", { key: "animationPreset", value: presetsArray[0].value });
        } else {
          this.$store.commit("update", { key: "animationPreset", value: presetsArray[0].value });
        }
        this.$store.commit("update", { key: "animationPresets", value: presetsArray });
        this.loadAnimationPreset(this.$store.state.animationPreset);
        if (this.editorCoverSize > 0)
          this.covers.size = parseFloat(this.editorCoverSize);
        if (this.editorCoverSize > 0)
          this.covers.sizeOriginal = parseFloat(this.editorCoverSize);
        this.covers.perRow = this.editorCoversPerRow;
        this.covers.padding = this.editorCoverPadding > -1 ? parseFloat(this.editorCoverPadding) : 0;
        this.canvas.width = this.editorCanvasWidth;
        this.canvas.height = this.editorCanvasHeight;
        this.canvas.padding.left = this.editorCanvasPaddingLeft;
        this.canvas.padding.top = this.editorCanvasPaddingTop;
        this.canvas.padding.right = this.editorCanvasPaddingRight;
        this.canvas.padding.bottom = this.editorCanvasPaddingBottom;
        let covers = this.editorCovers;
        if (this.$store.state.excludeArchived)
          covers = _.filter(covers, function(o) {
            return !o.inArchive;
          });
        this.covers.all = this.mappy(covers);
        this.covers.allOriginal = JSON.parse(JSON.stringify(this.covers.all));
        this.canvas.overlayColor = this.$store.state.awpOverlayColor;
        this.prioritizeCoversPerRow = this.$store.state.prioritizeCoversPerRow;
        this.canvas.grayscale = this.$store.state.awpGrayscale;
        this.canvas.grayscaleContrast = this.$store.state.awpGrayscaleContrast;
        this.canvas.background = this.$store.state.canvas.background;
        this.canvas.alignmentVertical = this.$store.state.canvas.alignmentVertical;
        this.covers.dropOverflowingRow = this.$store.state.awpDropOverflowingRow;
        if (!localStorage.getItem("aleImageEditorSettings")) {
          this.updateStoreAnimation();
        } else {
          this.animation.animationZone = this.$store.state.awpAnimationZone;
          this.animation.cycleDelay = this.$store.state.awpCycleDelay;
          this.animation.use = this.$store.state.awpAnimation;
          this.animation.onLoad = this.$store.state.awpAnimateOnLoad;
          this.animation.covers = this.$store.state.awpCoversPerCycle;
          this.$store.commit("update", { key: "awpAnimatedCoversLength", value: null });
          this.animation.randomCovers = this.$store.state.awpRandomCovers;
          this.animation.randomDelay = this.$store.state.awpRandomDelay;
          this.animation.sequential = this.$store.state.awpSequential;
          let animationsArray = _.map(this.animations, "class");
          this.$store.commit("update", { key: "awpAnimations", value: animationsArray });
        }
        callback();
      } else {
        this.loadJSON((standaloneOpts) => {
          this.covers.size = standaloneOpts.covers.size;
          this.covers.sizeOriginal = standaloneOpts.covers.size;
          this.covers.perRow = standaloneOpts.covers.perRow;
          this.covers.padding = standaloneOpts.covers.padding;
          this.covers.dropOverflowingRow = standaloneOpts.covers.dropOverflowingRow;
          this.canvas.width = standaloneOpts.canvas.width;
          this.canvas.height = standaloneOpts.canvas.width;
          this.canvas.padding.left = standaloneOpts.canvas.padding.left;
          this.canvas.padding.top = standaloneOpts.canvas.padding.top;
          this.canvas.padding.right = standaloneOpts.canvas.padding.right;
          this.canvas.padding.bottom = standaloneOpts.canvas.padding.bottom;
          this.covers.all = standaloneOpts.covers.all;
          this.covers.allOriginal = JSON.parse(JSON.stringify(this.covers.all));
          this.canvas.overlayColor = standaloneOpts.canvas.overlayColor;
          this.canvas.grayscale = standaloneOpts.canvas.grayscale;
          this.canvas.grayscaleContrast = standaloneOpts.canvas.grayscaleContrast;
          this.canvas.background = standaloneOpts.canvas.background;
          this.canvas.alignmentVertical = standaloneOpts.canvas.alignmentVertical;
          this.prioritizeCoversPerRow = standaloneOpts.prioritizeCoversPerRow;
          this.awpOverlayColorEnabled = standaloneOpts.awpOverlayColorEnabled;
          this.awpBlendMode = standaloneOpts.awpBlendMode;
          this.awpOverlayColor = standaloneOpts.awpOverlayColor;
          this.animation = standaloneOpts.animation;
          if (callback)
            callback();
        });
      }
    },
    loadAnimationPreset: function(presetName) {
      this.animation = JSON.parse(JSON.stringify(_.find(this.presets, { name: presetName })));
    },
    mappy: function(array) {
      let vue = this;
      if (array && array.length > 0) {
        return _.map(array, function(book) {
          return book.cover.match("https://") ? book.cover : vue.makeCoverUrl(book.cover);
        });
      } else {
        return [];
      }
    },
    updateStoreAnimation: function() {
      let animationsArray = _.map(this.animations, "class");
      this.$store.commit("update", [
        { key: "awpAnimationZone", value: this.animation.animationZone },
        { key: "awpCycleDelay", value: this.animation.cycleDelay },
        { key: "awpAnimation", value: this.animation.use || animationsArray },
        { key: "awpAnimations", value: animationsArray },
        { key: "awpAnimateOnLoad", value: this.animation.onLoad },
        { key: "awpCoversPerCycle", value: this.animation.covers },
        { key: "awpRandomCovers", value: this.animation.randomCovers },
        { key: "awpRandomDelay", value: this.animation.randomDelay },
        { key: "awpSequential", value: this.animation.sequential }
      ]);
    },
    loadJSON: function(callback, afterError) {
      let scrpt = document.createElement("script");
      scrpt.src = "options.js";
      scrpt.type = "text/javascript";
      scrpt.onload = () => {
        const standaloneOpts = window.wallpaperOptions;
        window.wallpaperOptions = null;
        try {
          scrpt.remove();
        } catch (e) {
        }
        scrpt = null;
        if (callback)
          callback(standaloneOpts);
      };
      scrpt.onerror = () => {
        scrpt = null;
        setTimeout(() => {
          if (!afterError)
            this.loadJSON(callback, "afterError");
          else {
            try {
              scrpt.remove();
            } catch (e) {
            }
          }
        }, 1e3);
      };
      document.head.appendChild(scrpt);
    }
  }
};
var animatedWallpaperApp_vue_vue_type_style_index_0_scope_true_lang = "";
let debounceDelay = 400;
const _sfc_main = {
  name: "awp",
  mixins: [
    utilities,
    presets,
    fitCoversToViewport,
    getAnimations,
    pickCoversToAnimate,
    prepareData
  ],
  data: function() {
    return {
      loadPreset: "random-simple-flips",
      animation: null,
      sequentialCounter: 0,
      canvas: {
        background: null,
        grayscale: null,
        grayscaleContrast: null,
        overlayColor: null,
        style: null,
        padding: {
          left: 0,
          top: 0,
          right: 0,
          bottom: 0
        },
        width: 0,
        height: 0,
        alignmentVertical: null
      },
      covers: {
        style: null,
        all: [],
        allOriginal: [],
        total: 0,
        perRow: 10,
        rows: null,
        size: 160,
        sizeOriginal: 160,
        padding: 0,
        paddingStyle: null,
        visible: null,
        dropOverflowingRow: false
      },
      animationCounter: 0,
      mounted: false,
      afterMounted: false,
      showLoadInClass: false,
      cycleInterval: null,
      animations: [
        { in: true, class: "bounce-in-fwd" },
        { in: true, class: "fade-in" },
        { in: true, class: "fade-in-top" },
        { in: true, class: "fade-in-br" },
        { in: true, class: "fade-in-right" },
        { in: true, class: "fade-in-tr" },
        { in: true, class: "fade-in-bottom" },
        { in: true, class: "fade-in-tl" },
        { in: true, class: "fade-in-left" },
        { in: true, class: "fade-in-bl" },
        { in: true, class: "push-left" },
        { in: true, class: "push-right" },
        { in: true, class: "push-up" },
        { in: true, class: "push-down" },
        { in: true, class: "squish-left" },
        { in: true, class: "squish-right" },
        { in: true, class: "squish-up" },
        { in: true, class: "squish-down" },
        { in: true, out: true, swap: true, class: "flip-horizontal-bottom" },
        { in: true, out: true, swap: true, class: "flip-horizontal-top" },
        { in: true, out: true, swap: true, class: "flip-vertical-right" },
        { in: true, out: true, swap: true, class: "flip-vertical-left" },
        { in: true, out: true, swap: true, class: "flip-diagonal-2-tl" },
        { in: true, out: true, swap: true, class: "flip-diagonal-2-br" },
        { in: true, out: true, swap: true, class: "flip-diagonal-1-bl" },
        { in: true, out: true, swap: true, class: "flip-diagonal-1-tr" },
        { in: true, out: true, swap: true, class: "flip-2-hor-top-2" },
        { in: true, out: true, swap: true, class: "flip-2-ver-right-2" },
        { in: true, out: true, swap: true, class: "flip-2-hor-bottom-2" },
        { in: true, out: true, swap: true, class: "flip-2-ver-left-2" },
        { in: true, out: true, swap: true, class: "flip-scale-down-hor" },
        { in: true, out: true, swap: true, class: "flip-scale-down-ver" },
        { in: true, out: true, swap: true, class: "flip-scale-down-diag-1" },
        { in: true, out: true, swap: true, class: "flip-scale-down-diag-2" }
      ],
      cycleCounter: 0,
      cycleCounterTimer: null,
      shuffleCounter: 0,
      coverTimer: null,
      awpOverlayColorEnabled: false,
      awpBlendMode: "",
      awpOverlayColor: ""
    };
  },
  computed: {
    canvasStyle: function() {
      var style = {};
      style.paddingLeft = this.canvas.padding.left > -1 ? this.canvas.padding.left + "px" : 0 + "px";
      style.paddingTop = this.canvas.padding.top > -1 ? this.canvas.padding.top + "px" : 0 + "px";
      style.paddingRight = this.canvas.padding.right > -1 ? this.canvas.padding.right + "px" : 0 + "px";
      style.paddingBottom = this.canvas.padding.bottom > -1 ? this.canvas.padding.bottom + "px" : 0 + "px";
      return style;
    }
  },
  created: function() {
    this.prepareData(() => {
      debounceDelay = 0;
      this.startAutoPlay();
    });
    window.addEventListener("resize", this.windowResized);
  },
  beforeUnmount: function() {
    window.removeEventListener("resize", this.windowResized);
    clearInterval(this.cycleInterval);
    clearInterval(this.cycleCounterTimer);
    clearInterval(this.coverTimer);
  },
  methods: {
    windowResized: function() {
      this.startAutoPlay();
    },
    startAutoPlay: _.debounce(function() {
      debounceDelay = 400;
      var vue = this;
      this.showLoadInClass = false;
      this.afterMounted = false;
      clearInterval(this.cycleInterval);
      clearInterval(this.cycleCounterTimer);
      clearInterval(this.coverTimer);
      this.sequentialCounter = 0;
      this.cycleCounter = 0;
      this.shuffleCounter = 0;
      if (vue.editorCovers)
        vue.$store.commit("update", [
          { key: "awpAnimationStarted", value: false },
          { key: "awpShowAnimationZone", value: false }
        ]);
      this.$nextTick(function() {
        this.fitCoversToViewport();
        let cycleDelay = vue.toMS(vue.animation.cycleDelay);
        let animationZone = vue.animation.animationZone / 100 * cycleDelay;
        this.imageLoader(this.covers.visible, function() {
          vue.showLoadInClass = true;
          vue.afterMounted = true;
          vue.$nextTick(function() {
            let visibleCoverElements = vue.$refs.cover;
            visibleCoverElements = _.filter(visibleCoverElements, function(cover) {
              return !cover.classList.contains("animating-cover");
            });
            if (visibleCoverElements[0]) {
              let playOnce = function(onLoad) {
                if (vue.editorCovers)
                  vue.$store.commit("update", [
                    { key: "awpAnimationStarted", value: true },
                    { key: "awpShowAnimationZone", value: true }
                  ]);
                let pickedCoverElements = vue.pickCoversToAnimate(visibleCoverElements, cycleDelay);
                let animationDelay;
                if (pickedCoverElements[0]) {
                  let sequentialDelays = vue.splitUnevenly(animationZone, pickedCoverElements.length, 0);
                  let spreadCounter = 0;
                  let animateWithDelay = function() {
                    vue.coverTimer = setTimeout(function() {
                      animationDelay = vue.animation.randomDelay ? sequentialDelays[spreadCounter] : animationZone / pickedCoverElements.length;
                      let animatedEl = pickedCoverElements[spreadCounter];
                      if (animatedEl)
                        vue.animateCover(pickedCoverElements[spreadCounter]);
                      ++spreadCounter;
                      if (spreadCounter < pickedCoverElements.length)
                        animateWithDelay();
                    }, animationDelay);
                  };
                  animateWithDelay();
                }
              };
              if (vue.animation.onLoad) {
                playOnce();
              } else {
                if (vue.editorCovers)
                  vue.$store.commit("update", { key: "awpAnimationStarted", value: true });
              }
              vue.cycleInterval = setInterval(function() {
                playOnce();
              }, cycleDelay);
            }
          });
        });
      });
    }, debounceDelay, { leading: false, trailing: true }),
    animateCover: function(currentTarget) {
      ++this.animationCounter;
      let vue = this;
      let coverWrapper = currentTarget;
      coverWrapper.className = "cover";
      let imageOne = coverWrapper.querySelector(".cover-one");
      let imageTwo = coverWrapper.querySelector(".cover-two");
      if (imageOne && imageTwo) {
        if (this.shuffleCounter > this.covers.all.length - 1)
          this.shuffleCounter = 0;
        let newImageFromArray = this.covers.all[this.shuffleCounter];
        ++this.shuffleCounter;
        var top = this.covers.all.splice(0, 1);
        this.covers.all.push(top[0]);
        this.loadImage(newImageFromArray, function(loadedImage) {
          let imageOut = imageOne;
          let imageIn = imageTwo;
          coverWrapper.classList.add("animating-cover");
          coverWrapper.style.zIndex = vue.animationCounter;
          imageIn.classList.remove("hide");
          imageIn.src = loadedImage.src;
          loadedImage = null;
          let animation = vue.getAnimations();
          if (animation) {
            let endAnimation = function() {
              imageOut.src = imageIn.src;
              coverWrapper.style.zIndex = null;
              coverWrapper.removeAttribute("data-animation-class");
              imageIn.classList.remove(animation.class);
              coverWrapper.className = "cover";
            };
            if (animation.swap) {
              imageOut.classList.add("out");
              imageIn.classList.add("in");
              coverWrapper.classList.add(animation.class);
            } else {
              imageOut.classList.add("out");
              imageIn.classList.add("in", animation.class);
              coverWrapper.setAttribute("data-animation-class", animation.class);
            }
            coverWrapper.addEventListener("animationend", endAnimation, { passive: true, once: true });
          }
        });
      }
    }
  }
};
const _hoisted_1 = {
  key: 1,
  id: "awp-inner-wrap"
};
const _hoisted_2 = ["src"];
const _hoisted_3 = ["src"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", {
    id: "awp",
    class: normalizeClass({
      "loader-bg": !_ctx.afterMounted,
      "reveal-covers": _ctx.showLoadInClass,
      "dropped-overflowing-row": _ctx.covers.dropOverflowingRow,
      "in-editor": _ctx.editorCovers,
      "not-in-editor": !_ctx.editorCovers
    }),
    style: normalizeStyle(!_ctx.editorCovers ? $options.canvasStyle : null)
  }, [
    _ctx.awpOverlayColorEnabled && !_ctx.editorCovers ? (openBlock(), createElementBlock("div", {
      key: 0,
      id: "color-overlay",
      style: normalizeStyle({
        background: _ctx.awpOverlayColor,
        mixBlendMode: _ctx.awpBlendMode !== "normal" ? _ctx.awpBlendMode : null
      })
    }, null, 4)) : createCommentVNode("", true),
    _ctx.afterMounted ? (openBlock(), createElementBlock("div", _hoisted_1, [
      (openBlock(), createBlock(resolveDynamicComponent("style"), null, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.editorCovers ? "#awp" : "#awp-inner-wrap") + " { " + toDisplayString(_ctx.editorCovers ? "" : "display: flex;") + " align-items: " + toDisplayString(_ctx.canvas.alignmentVertical) + " !important; } #awp .cover { margin: " + toDisplayString(_ctx.covers.padding) + "px; width: " + toDisplayString(_ctx.covers.size) + "px; height: " + toDisplayString(_ctx.covers.size) + "px; } #awp .cover > img { background-color: " + toDisplayString(_ctx.canvas.background) + "; " + toDisplayString(_ctx.canvas.grayscale ? "filter: grayscale(1) contrast(" + _ctx.canvas.grayscaleContrast + ");" : "") + " } html, body, #awp { overscroll-behavior: " + toDisplayString(!_ctx.editorCovers ? "none" : "auto") + "; background-color: " + toDisplayString(!_ctx.editorCovers ? _ctx.canvas.background : "transparent") + "; } ", 1)
        ]),
        _: 1
      })),
      createBaseVNode("div", null, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.covers.visible, (cover, index) => {
          return openBlock(), createElementBlock("div", {
            class: "cover",
            ref_for: true,
            ref: "cover",
            key: index
          }, [
            createBaseVNode("img", {
              src: cover,
              alt: "",
              draggable: "false",
              class: "cover-one"
            }, null, 8, _hoisted_2),
            createBaseVNode("img", {
              src: cover,
              alt: "",
              draggable: "false",
              class: "cover-two hide"
            }, null, 8, _hoisted_3)
          ]);
        }), 128))
      ])
    ])) : createCommentVNode("", true)
  ], 6);
}
var App = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { App as A };
//# sourceMappingURL=animated-wallpaper-app.9ef53f4e.js.map
