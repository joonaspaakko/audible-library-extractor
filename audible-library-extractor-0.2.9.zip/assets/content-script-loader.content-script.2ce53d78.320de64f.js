(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.2ce53d78.js")
    );
  })().catch(console.error);

})();
