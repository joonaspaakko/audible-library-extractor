(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.3ae2587d.js")
    );
  })().catch(console.error);

})();
