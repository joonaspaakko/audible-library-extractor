import "./gallery-makeCoverUrl.8378190f.js";
import { M as createApp } from "./lodash.1321b47a.js";
import { A as App } from "./animated-wallpaper-app.9ef53f4e.js";
import "./jquery.050764e9.js";
const app = createApp(App);
app.config.productionTip = false;
app.mount("#animated-wallpaper");
//# sourceMappingURL=animated-wallpaper.65a8a274.js.map
