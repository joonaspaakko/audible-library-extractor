(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.5c83b78d.js")
    );
  })().catch(console.error);

})();
