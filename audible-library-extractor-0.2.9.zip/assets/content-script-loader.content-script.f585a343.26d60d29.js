(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.f585a343.js")
    );
  })().catch(console.error);

})();
