(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.f57a1837.js")
    );
  })().catch(console.error);

})();
