(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.03bb6cf1.js")
    );
  })().catch(console.error);

})();
