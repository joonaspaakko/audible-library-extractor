(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.b0dcd524.js")
    );
  })().catch(console.error);

})();
